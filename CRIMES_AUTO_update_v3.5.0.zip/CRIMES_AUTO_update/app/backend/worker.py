"""Background automation worker — drives Playwright, reports progress, logs to DB."""
import os
import random
import re
import shutil
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import engine  # noqa: E402  (เครื่องมือค้นอัตโนมัติ — เดิมชื่อ crimes_auto)
import db  # noqa: E402

from playwright.sync_api import sync_playwright  # noqa: E402


def downloads_dir():
    """หาโฟลเดอร์ Downloads ของผู้ใช้ (รองรับกรณีถูก redirect เช่น OneDrive)"""
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders")
        val, _ = winreg.QueryValueEx(key, "{374DE290-123F-4565-9164-39C4925E467B}")
        winreg.CloseKey(key)
        p = Path(os.path.expandvars(val))
        if p.exists():
            return p
    except Exception:
        pass
    p = Path.home() / "Downloads"
    try:
        p.mkdir(parents=True, exist_ok=True)
    except OSError:
        p = Path.home()
    return p


def _is_profile_locked(err):
    """ข้อผิดพลาดที่บอกว่าโปรไฟล์ Chrome ถูกใช้อยู่โดยหน้าต่างอื่น"""
    s = str(err).lower()
    return ("existing browser session" in s
            or "already in use" in s
            or "singletonlock" in s)


def detect_account(page):
    """อ่านชื่อ/บัญชีผู้ใช้ CRIMES จากมุมขวาบนของหน้า"""
    try:
        txt = page.evaluate(
            r"""
            () => {
              const t = document.body.innerText;
              const m = t.match(/ชื่อ\s*:\s*([^\n]+)/);
              return m ? m[1].trim().slice(0, 80) : '';
            }
            """
        )
        return txt or ""
    except Exception:
        return ""


class RunManager:
    # ---- กติกาการวนลองแถวที่ผิดพลาดซ้ำ (เพดานแข็ง — กันวนไม่รู้จบและกันเสียโควตา) ----
    # v3.5.0: เพดานนับ 'ต่อรอบการทำงาน' (เก็บในหน่วยความจำ) ไม่ใช่ตลอดอายุไฟล์อีกต่อไป
    # เดิมเลขครั้งที่ลองถูกฝังในเซลล์ (ERROR#3) แล้วใช้ตัดสินข้ามรอบ → แถวที่เคยผิดครบ 3 ครั้ง
    # (เช่นช่วงที่เว็บมีกล่อง 'มีอะไรใหม่' บัง) ถูกข้ามถาวร ไม่ถูกย้อนกลับไปค้นใหม่อีกเลย
    # ตอนนี้ทุกครั้งที่กดเริ่มรอบใหม่ แถว ERROR ทุกแถวจะถูกย้อนกลับไปค้นใหม่เสมอ
    RETRY_MAX_ATTEMPTS = 3        # ลองได้สูงสุดกี่ครั้งต่อ 1 แถว 'ในรอบนี้' (นับรวมครั้งแรก)
    RETRY_MAX_PASSES = 2          # วนกลับมากวาดแถวที่ผิดพลาดได้กี่รอบต่อ 1 ไฟล์
    RETRY_BACKOFF = (20, 60)      # หน่วงก่อนเริ่มรอบที่ 1/2 (วินาที) ให้เว็บมีเวลาฟื้น
    AUTOSTART_SEC = 10            # ตรวจพบว่าเข้าสู่ระบบแล้ว → เริ่มค้นเองหลังนับถอยหลังนี้

    def __init__(self):
        self.lock = threading.Lock()
        self.thread = None
        self.current_user_id = 0
        self.auto_retry = True    # วนลองแถวที่ผิดพลาดซ้ำอัตโนมัติเมื่อจบไฟล์
        self.reset()

    def reset(self):
        self.state = "idle"          # idle|launching|awaiting_login|running|paused|done|stopped|error
        self.message = "พร้อมใช้งาน"
        self.account = ""
        # คงระดับความเร็วที่ผู้ใช้ตั้งไว้ล่าสุด (ไม่รีเซ็ตกลับค่าเริ่มต้นทุกครั้งที่เริ่มรอบใหม่)
        self.speed = engine.CURRENT_SPEED
        self.jobs = []
        self.file_index = 0
        self.file_total = 0
        self.current_file = ""
        self.row = 0
        self.total_rows = 0
        self.processed = 0
        self.found = 0
        self.notfound = 0
        self.errors = 0
        self.log_lines = []
        self.save_warning = ""   # บันทึกไป backup แทน (ไฟล์ต้นฉบับถูกเปิดค้าง)
        self.save_error = ""     # บันทึกลงไฟล์ไม่ได้เลย — ผลที่ค้นได้เสี่ยงหาย
        self.step_mode = False       # โหมดทีละขั้น (หยุดรอผู้ใช้กดก่อนแต่ละสเต็ป)
        self.awaiting_step = False   # กำลังรอผู้ใช้กด 'ทำขั้นต่อไป'
        self.current_step = ""       # คำอธิบายขั้นที่กำลังจะทำ
        self.browser_open = False    # เบราว์เซอร์ยังเปิดค้างอยู่ (หลังเสร็จ ไม่ปิดจนกว่าจะสั่ง)
        self.record_steps = False    # บันทึกการทำงานแต่ละสเต็ป (เปิดอัตโนมัติในโหมดทีละขั้น)
        self.last_recording = ""     # ชื่อชุดบันทึกล่าสุดที่ปิดเซสชันแล้ว
        self._page = None            # หน้าเบราว์เซอร์ปัจจุบัน (ให้ตัวบันทึกเข้าถึงได้)
        self._recorder = None        # engine.ManualRecorder ของรอบนี้ (ถ้าเปิดบันทึก)
        # ---- พัก/ค้นต่อ + บันทึกระหว่างค้น (สำหรับเน็ตหลุด/แบตใกล้หมด — ไม่เสียโควตาค้นซ้ำ) ----
        self.pause_reason = ""       # เหตุที่พัก: network|manual|errors ("" = ไม่ได้พัก)
        self.paused_at = ""          # ตำแหน่งที่พักไว้ เช่น "ไฟล์.xlsx แถว 57"
        self.restored = 0            # จำนวนแถวที่กู้ผลจากประวัติ (ไม่ต้องค้นซ้ำ)
        self.save_seq = 0            # ตัวนับ 'บันทึกตามคำขอ' สำเร็จ (หน้าเว็บรอค่านี้ขยับก่อนดาวน์โหลด)
        self.current_path = ""       # path ไฟล์ที่กำลังค้น (ให้ปุ่มดาวน์โหลดระหว่างรันใช้)
        self._wb = None              # workbook ที่กำลังเขียนผล (ให้ _service_save เข้าถึงได้)
        self._xlsx = None            # path ของ workbook ข้างบน
        self._save_request = False   # ผู้ใช้ขอบันทึกไฟล์เดี๋ยวนี้ (บันทึกที่จุดปลอดภัยถัดไป)
        self._pause_request = False  # ผู้ใช้ขอพักชั่วคราว (พักเมื่อจบแถวปัจจุบัน)
        self._resume_event = threading.Event()
        self._login_event = threading.Event()
        self._step_event = threading.Event()
        self._close_event = threading.Event()
        self._stop = False
        self.run_id = None
        # ---- ตรวจข้อมูลไม่ครบ + วนลองแถวที่ผิดพลาดซ้ำ (v2.4.0) ----
        self.incomplete = 0          # จำนวนแถวที่พบคดีแต่ข้อมูลไม่ครบ (ถูกมาร์คแดงไว้)
        self.incomplete_rows = []    # เลขแถวที่ต้องตรวจสอบ (ให้ผู้ใช้ไล่ดูในไฟล์)
        self.retry_pass = 0          # กำลังอยู่รอบลองใหม่ที่เท่าไร (0 = ยังไม่ถึงรอบ retry)
        self.retry_pending = 0       # แถวที่ยังเป็น ERROR และรอลองใหม่ได้
        self.retry_fixed = 0         # แถวที่ลองใหม่แล้วสำเร็จในรอบงานนี้
        self.retry_only = False      # โหมดลองเฉพาะแถวที่ผิดพลาด (สั่งจากปุ่ม)
        # ---- v3.5.0 ----
        self._tries = {}             # (ไฟล์, แถว) -> จำนวนครั้งที่ผิดพลาดในรอบนี้ (เพดานต่อรอบ)
        self._errors_left = {}       # ไฟล์ -> แถว ERROR ที่ยังค้างหลังจบไฟล์ (ให้ปุ่มลองใหม่รู้)
        self.file_done = 0           # แถวที่มีผลแล้วของไฟล์ปัจจุบัน (รวมที่ค้นไว้ก่อนรอบนี้)
        self.padded = 0              # เลข 12 หลักที่เติม 0 ข้างหน้าให้ในรอบนี้
        self.invalid_ids = 0         # แถวที่เลขบัตรใช้ไม่ได้ (เขียนหมายเหตุลงช่องผลแล้ว)
        self.login_detected = False  # ตรวจพบว่าเข้าสู่ระบบ CRIMES แล้วระหว่างรอกดเริ่ม
        self.autostart_in = 0        # วินาทีที่เหลือก่อนเริ่มค้นเอง (0 = ไม่ได้นับถอยหลัง)
        self._browser_gone = False   # ผู้ใช้ปิดหน้าต่าง Chrome/Chrome แครชระหว่างรอบ
        self._net_force = False      # กดค้นต่อซ้ำขณะเช็คเน็ตไม่ผ่าน = ยืนยันให้ค้นต่อเลย

    # ---------- public API ----------
    def status(self):
        with self.lock:
            # v3.5.0: % ของ 'ไฟล์ปัจจุบัน' จากแถวที่มีผลแล้วจริง — เดิมใช้ processed (สะสมทั้งรอบ
            # หลายไฟล์ และไม่นับแถวที่ค้นไว้ก่อน) หารด้วยจำนวนแถวของไฟล์เดียว จึงเกิน 100%
            # ตอนรันหลายไฟล์ และค้างไม่ถึง 100% ตอนค้นต่อจากไฟล์ที่ค้างไว้
            pct = 0
            if self.total_rows:
                pct = min(100, round(100 * self.file_done / self.total_rows))
            return {
                "state": self.state,
                "message": self.message,
                "account": self.account,
                "file_index": self.file_index,
                "file_total": self.file_total,
                "current_file": self.current_file,
                "row": self.row,
                "total_rows": self.total_rows,
                "processed": self.processed,
                "found": self.found,
                "notfound": self.notfound,
                "errors": self.errors,
                "percent": pct,
                "save_warning": self.save_warning,
                "save_error": self.save_error,
                "step_mode": self.step_mode,
                "awaiting_step": self.awaiting_step,
                "current_step": self.current_step,
                "browser_open": self.browser_open,
                "recording": bool(self._recorder),
                "recording_steps": (self._recorder.n if self._recorder else 0),
                "last_recording": self.last_recording,
                "pause_reason": self.pause_reason,
                "paused_at": self.paused_at,
                "restored": self.restored,
                "incomplete": self.incomplete,
                "incomplete_rows": self.incomplete_rows[-50:],
                "retry_pass": self.retry_pass,
                "retry_pending": self.retry_pending,
                "retry_fixed": self.retry_fixed,
                "auto_retry": self.auto_retry,
                "save_seq": self.save_seq,
                "current_path": self.current_path,
                "file_done": self.file_done,
                "errors_left": sum(self._errors_left.values()),
                "padded": self.padded,
                "invalid_ids": self.invalid_ids,
                "login_detected": self.login_detected,
                "autostart_in": self.autostart_in,
                # ความเร็วอ่านจากเอนจินเสมอ (แหล่งความจริงเดียว) — ไม่ใช่จาก self.speed
                # ซึ่งเป็นแค่ 'ค่าเริ่มต้นของรอบถัดไป' และอาจไม่ตรงกับที่ใช้อยู่จริง
                **engine.get_speed(),
                "log": self.log_lines[-200:],
            }

    def is_busy(self):
        return self.state in ("launching", "awaiting_login", "running", "paused")

    def start(self, jobs, account="", speed=None, step_mode=False, record=None,
              user_id=None, retry_only=False):
        if self.is_busy():
            return False, "มีงานกำลังทำงานอยู่"
        # ปิดเบราว์เซอร์ของรอบก่อน (ถ้าเปิดค้าง) แล้วรอให้ 'ปล่อยโปรไฟล์' ก่อนเปิดใหม่
        # กันปัญหา 'profile already in use' เพราะ Chrome เก่ายังจับโปรไฟล์อยู่
        self._close_event.set()
        old = self.thread
        if old and old.is_alive():
            old.join(timeout=12)
        self.reset()
        # เจ้าของรอบตั้ง 'หลัง' ผ่านการตรวจ is_busy เท่านั้น — ห้ามให้ผู้เรียกตั้งเอง
        # ก่อนเรียก start (คนที่กดตอนรอบอื่นกำลังรันจะไปสลับเจ้าของ/การคิดเงินกลางคัน)
        if user_id is not None:
            self.current_user_id = int(user_id or 0)
        self.jobs = jobs
        self.account = account
        if speed is not None:
            self.speed = engine.clamp_speed(speed)
        self.step_mode = bool(step_mode)
        # บันทึกสเต็ป: ถ้าไม่ระบุ ให้เปิดอัตโนมัติเมื่ออยู่โหมดทีละขั้น (การทำงานแบบเมนนวล)
        self.record_steps = bool(record) if record is not None else bool(step_mode)
        # โหมด 'ลองเฉพาะแถวที่ผิดพลาด' — ข้ามลูปหลัก ไปทำรอบ retry อย่างเดียว
        # และบังคับลองแม้แถวที่ระบบเลิกลองเองแล้ว (ERROR ถาวร/ครบเพดาน)
        self.retry_only = bool(retry_only)
        self.file_total = len(jobs)
        self.state = "launching"
        self.message = "กำลังเปิดเบราว์เซอร์..."
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        return True, "เริ่มแล้ว"

    def confirm_login(self):
        self._login_event.set()

    def next_step(self):
        """โหมดทีละขั้น: สั่งให้ทำขั้นต่อไป"""
        self._step_event.set()

    def set_auto(self):
        """สลับจากโหมดทีละขั้นเป็นอัตโนมัติ (เดินต่อเองจนจบ)"""
        self.step_mode = False
        self._step_event.set()   # ปลดล็อกขั้นที่กำลังรออยู่
        self._log("สลับเป็นโหมดอัตโนมัติ — เดินต่อเองจนจบ")

    def close_browser(self):
        """สั่งปิดเบราว์เซอร์ที่เปิดค้างอยู่หลังทำงานเสร็จ"""
        self._close_event.set()

    def reset_round(self):
        """เริ่มรอบใหม่อย่างปลอดภัย — ปิดเบราว์เซอร์ที่เปิดค้าง + รอ thread เดิมจบ + รีเซ็ตสถานะ
        เรียกซ้ำหลายครั้งได้โดยไม่เกิดข้อผิดพลาด. คืน (ok: bool, message: str)"""
        if self.is_busy():
            return False, "มีงานกำลังทำงานอยู่ — โปรดหยุดก่อนเริ่มรอบใหม่"
        # ปิดเบราว์เซอร์ของรอบก่อน (ถ้ายังเปิดค้าง) แล้วรอเธรดเดิมปล่อยทรัพยากรก่อนรีเซ็ต
        self._close_event.set()
        t = self.thread
        if t and t.is_alive():
            t.join(timeout=10)
        self.reset()
        return True, "พร้อมรับไฟล์ใหม่"

    def stop(self):
        self._stop = True
        self._step_event.set()     # ปลดล็อกถ้ากำลังรอขั้นต่อไปอยู่
        self._resume_event.set()   # ปลดล็อกถ้ากำลังพักอยู่ (ให้เธรดออกจากลูปพักแล้วจบงาน)
        self.message = "กำลังหยุด..."

    def pause(self):
        """ขอพักชั่วคราว — มีผลเมื่อจบแถวที่กำลังค้นอยู่ (ระบบบันทึกไฟล์ให้ก่อนพัก)"""
        if self.state == "running" and not self._pause_request:
            self._pause_request = True
            self._log("⏸ ขอพักชั่วคราว — จะพักเมื่อจบแถวปัจจุบัน (บันทึกไฟล์ให้อัตโนมัติ)")

    def resume(self):
        """สั่งค้นต่อจากจุดที่พักไว้ (หลังพักด้วยมือ/เน็ตหลุด/ผิดพลาดติดกัน)"""
        self._resume_event.set()

    def set_speed(self, level=None, delta=None):
        """ปรับความเร็วการค้น — เรียกจากเธรด Flask ได้แม้ระหว่างรอบทำงาน

        level: ตั้งระดับตรง ๆ 1–5 · delta: บวก/ลบจากระดับปัจจุบัน (+1 / -1)
        มีผลกับจังหวะหน่วงถัดไป (ไม่ปลุกเธรดที่กำลัง sleep อยู่ — ดีเลย์ไม่กี่วินาที)
        คืน dict ของระดับก่อน/หลัง เพื่อให้ผู้เรียกรู้ว่าค่าเปลี่ยนจริงไหม"""
        prev = engine.CURRENT_SPEED
        if delta is not None:
            level = prev + int(delta)
        applied = engine.clamp_speed(level)
        engine.set_speed(applied)
        self.speed = applied          # ใช้เป็นค่าเริ่มต้นของรอบถัดไปด้วย
        return {"prev": prev, "changed": applied != prev, **engine.get_speed()}

    def request_save(self):
        """ขอบันทึกผลลงไฟล์เดี๋ยวนี้ (ดาวน์โหลดระหว่างที่ยังค้นไม่ครบ เช่นก่อนแบตหมด)
        คืน save_seq ปัจจุบัน — หน้าเว็บรอจนค่านี้ขยับจึงเริ่มดาวน์โหลด"""
        self._save_request = True
        return self.save_seq

    # ---------- internal ----------
    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)
            if len(self.log_lines) > 1000:
                self.log_lines = self.log_lines[-500:]

    def _service_save(self):
        """บันทึกไฟล์ตามคำขอของผู้ใช้ (เรียกจากเธรดงานที่จุดปลอดภัยเท่านั้น)
        เสร็จแล้วขยับ save_seq เพื่อบอกหน้าเว็บว่าเริ่มดาวน์โหลดได้"""
        if not self._save_request:
            return
        self._save_request = False
        if self._wb is not None and self._xlsx is not None:
            self._save_checked(self._wb, self._xlsx)
            self._log("💾 บันทึกผลลงไฟล์ตามคำขอแล้ว — ดาวน์โหลดได้เลย (ค้นต่อได้ตามปกติ)")
        self.save_seq += 1

    def _pause_wait(self, reason):
        """พักการทำงานโดยคงเบราว์เซอร์/ตำแหน่งงานไว้ รอผู้ใช้สั่ง 'ค้นต่อ ▶'
        คืน True = ค้นต่อจากแถวเดิม, False = ถูกสั่งหยุด
        ผู้เรียกต้องบันทึกไฟล์ให้เรียบร้อยก่อนเรียก (ผลที่ค้นแล้วไม่หาย)"""
        reasons = {
            "network": "📡 เน็ตหลุด/เข้าเว็บ CRIMES ไม่ได้ — พักอัตโนมัติเพื่อไม่ให้เสียโควตาค้นซ้ำ",
            "manual": "⏸ พักชั่วคราวตามคำขอ",
            "errors": "⚠ ผิดพลาดติดต่อกันหลายแถว — พักอัตโนมัติเพื่อไม่ให้เสียโควตา "
                      "(ตรวจหน้าเว็บในเบราว์เซอร์ หรือลองโหมดทีละขั้น)",
            # เดิมไม่มีข้อความของ 'auth' เลย ผู้ใช้เห็นแค่ 'พักชั่วคราว' โดยไม่รู้ว่าต้องทำอะไร
            "auth": "🔐 หลุดการเข้าสู่ระบบ CRIMES — เข้าสู่ระบบใหม่ในหน้าต่าง Chrome",
        }
        self.state = "paused"
        self.pause_reason = reason
        self.paused_at = f"{self.current_file} แถว {self.row}"
        self.message = (reasons.get(reason, "พักชั่วคราว")
                        + f" · ค้างที่ {self.paused_at} — ผลที่ค้นแล้วถูกบันทึกไว้ ดาวน์โหลดได้ "
                          "/ กด 'ค้นต่อ ▶' เมื่อพร้อม")
        self._log(self.message)
        self._resume_event.clear()
        while True:
            while not self._resume_event.is_set():
                if self._stop:
                    return False
                self._service_save()   # ไฟล์ถูกบันทึกก่อนพักแล้ว — ยืนยันให้ดาวน์โหลดได้ทันที
                time.sleep(0.3)
            self._resume_event.clear()
            if self._stop:
                return False
            # ก่อนกลับไปค้นต่อหลังเน็ตหลุด: เช็คให้แน่ว่าติดต่อเซิร์ฟเวอร์ได้แล้วจริง
            # แต่เครื่องที่ออกเน็ตผ่าน proxy จะเปิด TCP ตรงไม่ได้เลยแม้เน็ตปกติ (Chrome ใช้ proxy ได้)
            # เดิมจึงค้างพักถาวร — ตอนนี้กด 'ค้นต่อ' ซ้ำอีกครั้ง = ผู้ใช้ยืนยันเอง ให้ค้นต่อเลย
            if reason == "network" and not self._net_force and not engine.probe_online():
                self._net_force = True
                self.message = ("ยังติดต่อเซิร์ฟเวอร์ CRIMES ไม่ได้ — รอสัญญาณอินเทอร์เน็ตกลับมา "
                                "แล้วกด 'ค้นต่อ ▶' (ถ้าเปิดเว็บ CRIMES ใน Chrome ได้ปกติ "
                                "กด 'ค้นต่อ ▶' อีกครั้งเพื่อค้นต่อเลย)")
                self._log("📡 " + self.message)
                continue
            break
        self._net_force = False
        self.state = "running"
        self.pause_reason = ""
        self.paused_at = ""
        self.message = "ค้นต่อจากจุดที่พักไว้"
        self._log("▶ ค้นต่อจากจุดที่พักไว้ (" + f"{self.current_file} แถว {self.row})")
        return True

    def _pause_step(self, desc):
        """โหมดทีละขั้น: หยุดรอผู้ใช้กด 'ทำขั้นต่อไป' ก่อนทำ desc
        คืน True = ทำต่อได้, False = ถูกสั่งหยุด. โหมดอัตโนมัติจะคืน True ทันที"""
        self.current_step = desc
        # บันทึกสถานะหน้า (ภาพ+HTML) ของสเต็ปนี้ 'ก่อนลงมือทำ' — ข้อมูลไว้ปรับปรุงระบบ
        if self.record_steps and self._recorder is not None and self._page is not None:
            try:
                self._recorder.step(self._page, desc)
            except Exception:
                pass
        if not self.step_mode:
            return True
        self._log("⏸ ขั้นต่อไป: " + desc + "  — กด 'ทำขั้นต่อไป ▶'")
        self.awaiting_step = True
        self._step_event.clear()
        while not self._step_event.is_set():
            if self._stop:
                self.awaiting_step = False
                return False
            if not self.step_mode:      # ผู้ใช้สลับเป็นอัตโนมัติกลางคัน
                break
            self._service_save()        # ขอบันทึก·ดาวน์โหลดได้แม้กำลังรอขั้นต่อไป
            time.sleep(0.2)
        self.awaiting_step = False
        if self._stop:
            return False
        self._log("▶ กำลังทำ: " + desc)
        return True

    def _step_note(self, msg):
        """รายงานผลของแต่ละขั้น (แสดงเฉพาะในโหมดทีละขั้น เพื่อไม่รกในโหมดอัตโนมัติ)"""
        if self.step_mode:
            self._log("   → " + msg)
        # เก็บผลลงสเต็ปปัจจุบันของตัวบันทึก (ไว้ทบทวนว่าแต่ละขั้นได้ผลอะไร)
        if self.record_steps and self._recorder is not None:
            try:
                self._recorder.note(msg)
            except Exception:
                pass

    def _launch_with_retry(self, p, attempts=3):
        """เปิดเบราว์เซอร์ พร้อมลองใหม่ถ้าโปรไฟล์ยังถูกจับอยู่ (Chrome เก่าเพิ่งปิด)"""
        last = None
        for i in range(attempts):
            try:
                return engine.launch_browser(p)
            except Exception as e:
                last = e
                if _is_profile_locked(e) and i < attempts - 1:
                    killed = engine.kill_profile_browsers()
                    self._log(f"โปรไฟล์ Chrome ถูกใช้อยู่ — ปิดหน้าต่างเดิมของระบบ {killed} รายการ "
                              f"แล้วลองเปิดใหม่ (ครั้งที่ {i + 2})")
                    time.sleep(2.5)
                    continue
                raise
        raise last

    def _live_page(self, ctx, page):
        """คืนแท็บที่ยังเปิดอยู่ (เลือกแท็บเว็บ CRIMES ก่อน) — None ถ้าเบราว์เซอร์ถูกปิดไปแล้ว"""
        try:
            pages = [p for p in ctx.pages if not p.is_closed()]
        except Exception:
            return None
        if page is not None and not page.is_closed() and engine.SEARCH_HOST in (page.url or ""):
            return page
        crimes = [p for p in pages if engine.SEARCH_HOST in (p.url or "")]
        if crimes:
            return crimes[-1]
        if page is not None and not page.is_closed():
            return page
        return pages[-1] if pages else None

    def _await_login(self, ctx, page):
        """รอจนผู้ใช้กด 'เริ่มค้นหา' หรือระบบตรวจพบว่าเข้าสู่ระบบแล้ว (นับถอยหลังแล้วเริ่มเอง)

        v3.5.0 — ผู้ใช้รายงานซ้ำว่า "ไม่มีปุ่มกดเริ่ม": หน้าต่าง Chrome เปิดเต็มจอบังโปรแกรม
        ปุ่มอยู่อีกหน้าต่างหนึ่ง จึงเพิ่มการตรวจว่าเข้าสู่ระบบแล้ว (หน้าค้นหามีช่องกรอกเลขบัตร
        และไม่มีช่องรหัสผ่าน) แล้วเริ่มค้นเองหลังนับถอยหลัง — ไม่ต้องสลับหน้าต่างมากดอีก
        และตรวจว่าผู้ใช้ปิดหน้าต่าง Chrome ไปแล้วหรือยัง (เดิมค้างสถานะรอ login ตลอดไป)
        คืนแท็บที่ใช้ค้นต่อ หรือ None ถ้ายกเลิก/เบราว์เซอร์ถูกปิด (ตั้งสถานะให้แล้ว)"""
        last_probe = 0.0
        countdown_end = None
        while not self._login_event.is_set():
            if self._stop:
                self.state = "stopped"
                self.message = "ยกเลิกก่อนเริ่ม"
                self.autostart_in = 0
                try:
                    ctx.close()
                except Exception:
                    pass
                return None
            try:
                page.wait_for_timeout(300)      # ให้ Playwright รับเหตุการณ์ (ปิดแท็บ/เปลี่ยนหน้า)
            except Exception:
                time.sleep(0.3)
            page = self._live_page(ctx, page)
            if page is None:
                self.state = "error"
                self.browser_open = False
                self.autostart_in = 0
                self.message = ("หน้าต่าง Chrome ถูกปิดก่อนเริ่มค้น — "
                                "กด ▶ LOGIN CRIMES เพื่อเปิดใหม่ (แถวที่ค้นแล้วไม่ต้องค้นซ้ำ)")
                self._log(self.message)
                try:
                    ctx.close()
                except Exception:
                    pass
                return None
            now = time.time()
            if now - last_probe >= 1.5:
                last_probe = now
                logged_in = False
                try:
                    logged_in = (engine._find_id_input_selector(page) is not None
                                 and not engine.is_login_page(page))
                except Exception:
                    logged_in = False
                if logged_in and not self.login_detected:
                    self.login_detected = True
                    countdown_end = now + self.AUTOSTART_SEC
                    self._log(f"✓ ตรวจพบว่าเข้าสู่ระบบ CRIMES แล้ว — จะเริ่มค้นเองใน "
                              f"{self.AUTOSTART_SEC} วินาที (กด 'เริ่มค้นหา' เพื่อเริ่มทันที / 'หยุด' เพื่อยกเลิก)")
                elif not logged_in and self.login_detected:
                    # กลับไปหน้าเข้าสู่ระบบ/หน้าอื่น → ยกเลิกการนับถอยหลัง รอใหม่
                    self.login_detected = False
                    countdown_end = None
                    self.autostart_in = 0
            if countdown_end is not None:
                left = max(0, int(round(countdown_end - now)))
                self.autostart_in = left
                self.message = (f"เข้าสู่ระบบแล้ว — เริ่มค้นอัตโนมัติใน {left} วินาที "
                                "(กด 'เริ่มค้นหา' เพื่อเริ่มทันที)")
                if left <= 0:
                    self._log("▶ เริ่มค้นอัตโนมัติ")
                    break
        self.autostart_in = 0
        return page

    def _run(self):
        close_event = self._close_event   # จับ event ของรอบนี้ไว้ (กันถูก reset ทับ)
        close_event.clear()
        try:
            with sync_playwright() as p:
                try:
                    ctx = self._launch_with_retry(p)
                except Exception as e:
                    self.state = "error"
                    self.browser_open = False
                    if _is_profile_locked(e):
                        self.message = ("เปิดเบราว์เซอร์ไม่ได้ — มีหน้าต่าง Chrome ของระบบเปิดค้างอยู่ "
                                        "(โปรไฟล์กำลังถูกใช้งาน) โปรดปิดหน้าต่าง Chrome เดิมของระบบให้หมด "
                                        "แล้วกด 'เริ่มค้นหา' ใหม่")
                    else:
                        self.message = f"เปิดเบราว์เซอร์ไม่ได้: {str(e)[:200]}"
                    self._log(self.message)
                    return
                # เตือนผู้ใช้ให้เห็นชัดถ้าตกไปใช้ Chromium สำรอง (เนียนน้อยกว่า Chrome จริง)
                if getattr(engine, "LAST_LAUNCH_USED_FALLBACK", False):
                    self._log("⚠ ใช้ Chromium สำรอง (ไม่พบ/เปิด Chrome ของเครื่องไม่ได้) — "
                              "โหมดนี้ถูกตรวจจับว่าเป็นบอทง่ายกว่า Chrome จริง · "
                              "แนะนำติดตั้ง/เปิด Google Chrome เพื่อความปลอดภัยสูงสุด")

                page = ctx.pages[0] if ctx.pages else ctx.new_page()
                # v3.5.0: เปิดหน้าเว็บไม่สำเร็จต้อง 'ไม่' ทำให้ทั้งรอบล้มก่อนถึงขั้นรอ login
                # เดิม goto หมดเวลา (เว็บช้า/เน็ตช้า/เด้งหน้า SSO) = รอบจบเป็น 'ผิดพลาด' ทันที
                # ปุ่ม 'เริ่มค้นหา' จึงไม่เคยโผล่ — ตอนนี้เบราว์เซอร์เปิดค้างไว้ให้ผู้ใช้เข้าเว็บเอง
                try:
                    page.goto(engine.SEARCH_URL, wait_until="domcontentloaded", timeout=45000)
                except Exception as e:
                    if engine.is_browser_closed_error(e):
                        raise
                    self._log(f"⚠ เปิดหน้าเว็บ CRIMES ยังไม่สำเร็จ ({str(e)[:100]}) — "
                              "ตรวจอินเทอร์เน็ต หรือเข้าเว็บ CRIMES เองในหน้าต่าง Chrome ได้เลย")

                self.state = "awaiting_login"
                self.message = ("เข้าสู่ระบบ CRIMES ในหน้าต่าง Chrome — ระบบจะเริ่มค้นให้เองเมื่อเข้าสู่ระบบแล้ว "
                                "(หรือกด 'เริ่มค้นหา' ได้ทันที)")
                self._log("เปิดเบราว์เซอร์แล้ว — รอเข้าสู่ระบบ CRIMES")
                page = self._await_login(ctx, page)
                if page is None:
                    return

                # เว็บ CRIMES เด้งกล่อง 'มีอะไรใหม่' หลังขึ้นเวอร์ชันใหม่ — ครอบทับทั้งหน้า
                # ปิดก่อนเริ่มค้น (ผู้ใช้อาจปิดเองไปแล้วตอนล็อกอิน ก็ไม่เป็นไร ฟังก์ชันเงียบ)
                engine.dismiss_announcement(page, note=self._log)

                # auto-detect account ถ้าไม่ได้ระบุ
                detected = detect_account(page)
                if detected and not self.account:
                    self.account = detected
                self._log(f"บัญชีผู้ค้น: {self.account or '(ไม่ทราบ)'}")

                self.run_id = db.start_run(self.account, "; ".join(
                    Path(j["path"]).name for j in self.jobs),
                    user_id=self.current_user_id)

                applied = engine.set_speed(self.speed)
                self._log(f"ความเร็วการค้น: {engine.SPEED_LABELS.get(self.speed, '?')} "
                          f"(หน่วงเวลา ×{applied:g})")
                if self.step_mode:
                    self._log("🔎 โหมดทีละขั้น (Step-by-step) — ระบบจะหยุดรอให้กด 'ทำขั้นต่อไป ▶' "
                              "ในแต่ละสเต็ป เพื่อดูจุดที่ผิดพลาด")

                self.state = "running"
                # ล้างข้อความของขั้นรอเข้าสู่ระบบ (เดิมค้าง 'กด เริ่มค้นหา' ไว้บนแถบตลอดรอบค้น)
                self.message = "กำลังค้นหา — ดูรายละเอียดแต่ละแถวในบันทึกการทำงานด้านล่าง"
                for fi, job in enumerate(self.jobs, 1):
                    if self._stop:
                        break
                    self.file_index = fi
                    self._process_file(page, job)

                db.finish_run(self.run_id, self.processed, self.found,
                              self.notfound, self.errors,
                              "stopped" if self._stop else "done")

                # ปิดเซสชันบันทึกโหมดทีละขั้น (ถ้ามี) — ได้ชุดข้อมูลไว้ปรับปรุงระบบ
                if self._recorder is not None:
                    try:
                        summ = self._recorder.finish(page)
                        self.last_recording = self._recorder.name
                        self._log(f"📄 บันทึกโหมดทีละขั้นเสร็จ: {summ['steps']} สเต็ป "
                                  f"(ชุด {self._recorder.name}) — ดาวน์โหลดได้ในหน้าตั้งค่า")
                    except Exception:
                        pass
                    self._recorder = None

                self.state = "stopped" if self._stop else "done"
                self.pause_reason = ""
                left = sum(self._errors_left.values())
                if self._browser_gone:
                    head = "หยุดแล้ว — หน้าต่าง Chrome ถูกปิดระหว่างค้น"
                else:
                    head = "หยุดแล้ว" if self._stop else "เสร็จสมบูรณ์"
                self.message = head + \
                    f" — ค้น {self.processed}, พบ {self.found}, ไม่พบ {self.notfound}, ผิดพลาด {self.errors}"
                if self.restored:
                    self.message += f" (กู้จากประวัติ {self.restored} — ไม่เสียโควตา)"
                if self.padded:
                    self.message += f" · เติม 0 หน้าเลข 12 หลัก {self.padded} แถว"
                if self.invalid_ids:
                    self.message += f" · เลขบัตรใช้ไม่ได้ {self.invalid_ids} แถว (เขียนหมายเหตุในไฟล์)"
                if left:
                    self.message += (f" · ⚠ ยังมีแถวผิดพลาดค้าง {left} แถว — "
                                     "กด '🔁 ลองแถวที่ผิดพลาด' หรือ ▶ LOGIN CRIMES เพื่อค้นใหม่")
                if self._browser_gone:
                    self.message += " · กด ▶ LOGIN CRIMES เพื่อค้นต่อจากแถวเดิม"
                if self.save_error:
                    self.message += " · ⚠ บันทึกไฟล์ไม่สำเร็จ (ดูคำเตือนด้านบน)"
                elif self.save_warning:
                    self.message += " · ⚠ บันทึกไว้ที่ไฟล์สำรอง (ดูคำเตือนด้านบน)"
                self._log(self.message)
                if self._browser_gone:
                    self.browser_open = False
                    self.current_step = ""
                    self.awaiting_step = False
                    try:
                        ctx.close()
                    except Exception:
                        pass
                    return

                # ไม่ปิดเบราว์เซอร์ทันที — เปิดค้างไว้ให้ผู้ใช้ตรวจสอบ
                # จนกว่าจะกด 'ปิดเบราว์เซอร์' หรือเริ่มงานใหม่
                self.browser_open = True
                self.current_step = ""
                self.awaiting_step = False
                self._log("เบราว์เซอร์ยังเปิดค้างไว้ — กด 'ปิดเบราว์เซอร์' เมื่อต้องการปิด")
                while not close_event.is_set():
                    # ผู้ใช้ปิดหน้าต่าง Chrome เองแล้ว → ไม่ต้องค้างปุ่ม 'ปิดเบราว์เซอร์' ไว้หลอก ๆ
                    try:
                        page.wait_for_timeout(300)
                    except Exception:
                        time.sleep(0.3)
                        if self._live_page(ctx, None) is None:
                            break
                        page = self._live_page(ctx, None)
                self.browser_open = False
                self._log("ปิดเบราว์เซอร์แล้ว")
                try:
                    ctx.close()
                except Exception:
                    pass
        except Exception as e:
            # เก็บผลที่ค้นได้ของไฟล์ที่กำลังทำอยู่ก่อน (ไม่งั้นแถวหลังการบันทึกครั้งล่าสุดหาย)
            if self._wb is not None and self._xlsx is not None:
                try:
                    self._save_checked(self._wb, self._xlsx)
                except Exception:
                    pass
            if self.run_id:
                try:
                    db.finish_run(self.run_id, self.processed, self.found,
                                  self.notfound, self.errors, "error")
                except Exception:
                    pass
            self.state = "error"
            self.autostart_in = 0
            if engine.is_browser_closed_error(e):
                self.message = ("หน้าต่าง Chrome ถูกปิด — ผลที่ค้นแล้วถูกบันทึกไว้ "
                                "กด ▶ LOGIN CRIMES เพื่อค้นต่อจากแถวเดิม")
            else:
                self.message = f"ผิดพลาด: {e}"
            self.browser_open = False
            self._log(self.message)

    def _save_checked(self, wb, xlsx, found_pending=0):
        """บันทึกไฟล์ พร้อมตรวจว่าบันทึกสำเร็จจริงหรือไม่ แล้วแจ้งเตือนถ้ามีปัญหา

        found_pending = จำนวน 'พบคดี' ที่กำลังจะถูกเขียนลงไฟล์รอบนี้ (ใช้ในข้อความเตือน)
        คืน True ถ้าเขียนทับไฟล์ต้นฉบับสำเร็จ, False ถ้าไป backup หรือบันทึกไม่ได้
        """
        path, status, message = engine.save_workbook_report(wb, xlsx)
        if status == "ok":
            # บันทึกทับต้นฉบับได้ — เคลียร์คำเตือนเดิม (ผู้ใช้อาจปิดไฟล์แล้ว)
            if self.save_warning or self.save_error:
                self._log("บันทึกไฟล์ต้นฉบับได้ตามปกติแล้ว")
            self.save_warning = ""
            self.save_error = ""
            return True
        if status == "backup":
            # ข้อมูลถูกเขียนลงไฟล์สำรองแล้ว (ถือว่าบันทึกสำเร็จ แต่เตือนให้ปิดไฟล์ต้นฉบับ)
            self.save_warning = message
            self.save_error = ""
            self._log(f"[!] {message}")
            return True
        # failed — ข้อมูลที่ค้นได้ยังไม่ถูกเขียนลงไฟล์
        extra = f" (มีผล 'พบคดี' {found_pending} รายการที่ยังไม่ถูกบันทึก)" if found_pending else ""
        self.save_error = message + extra
        self._log(f"[!!] {message}{extra}")
        return False

    def _save_to_downloads(self, xlsx):
        """ก๊อปไฟล์ผลลัพธ์ไปที่โฟลเดอร์ Downloads อัตโนมัติเมื่อค้นครบทุกแถว
        ตั้งชื่อไฟล์ตามจำนวนรายชื่อที่ค้น เช่น  ชื่อไฟล์(120ชื่อ).xlsx"""
        try:
            xlsx = Path(xlsx)
            # เลือกไฟล์ที่มีข้อมูลล่าสุด (เผื่อกรณีบันทึกไปไฟล์สำรอง _backup เพราะไฟล์ต้นฉบับถูกล็อก)
            backup = xlsx.with_name(xlsx.stem + "_backup.xlsx")
            src = xlsx
            if backup.exists() and (not xlsx.exists()
                                    or backup.stat().st_mtime > xlsx.stat().st_mtime):
                src = backup
            if not src.exists():
                return None
            count = db.count_searched_ids(xlsx.name, user_id=self.current_user_id)
            name = f"{xlsx.stem}({count}ชื่อ){xlsx.suffix}" if count > 0 else xlsx.name
            dest = downloads_dir() / name
            shutil.copy2(src, dest)
            self._log(f"💾 บันทึกผลอัตโนมัติไปที่ Downloads: {dest.name}")
            return dest
        except Exception as e:
            self._log(f"[!] บันทึกไป Downloads ไม่ได้: {e}")
            return None

    def _count_rows(self, ws, id_col, start_row, end_row):
        n = 0
        r = start_row
        while True:
            if end_row is not None and r > end_row:
                break
            v = ws.cell(row=r, column=id_col).value
            if v is None or str(v).strip() == "":
                break
            n += 1
            r += 1
        return n

    # ==================== ค้น 1 แถว (ใช้ร่วมกันทั้งรอบหลักและรอบ retry) ====================
    def _search_row(self, page, wb, ws, xlsx, row, ctx, force=False):
        """ค้นเลขบัตรของแถวเดียว แล้วเขียนผล/ERROR ลงไฟล์

        คืนสถานะให้ผู้เรียกตัดสินใจเดินต่อ:
          'end'      เซลล์เลขบัตรว่าง = จบไฟล์
          'skip'     มีผลอยู่แล้ว/เลขไม่ถูกต้อง/ERROR ถาวร → ข้ามไปแถวถัดไป
          'done'     ค้นสำเร็จ หรือกู้ผลจากประวัติ → ไปแถวถัดไป
          'error'    เขียน ERROR ลงช่องผลแล้ว → ไปแถวถัดไป
          'same_row' ต้องลองแถวเดิมซ้ำ (เน็ตหลุด/หลุด login/ผิดพลาดติดกันแล้วพัก)
          'stop'     ถูกสั่งหยุด
        force=True (ปุ่ม 'ลองแถวที่ผิดพลาด') ลองได้โดยไม่ติดเพดานจำนวนครั้งของรอบนี้
        """
        id_col, out_col, no_year = ctx["id_col"], ctx["out_col"], ctx["no_year"]
        cell_b = ws.cell(row=row, column=id_col)
        raw = cell_b.value
        if raw is None or str(raw).strip() == "":
            return "end"
        self.row = row

        cell_f = ws.cell(row=row, column=out_col)
        f_val = str(cell_f.value).strip() if cell_f.value else ""
        prev_err = engine.parse_error_cell(cell_f.value)
        if f_val and prev_err is None:
            return "skip"                      # มีผลจริงอยู่แล้ว (รวมหมายเหตุเลขใช้ไม่ได้)
        key = (ctx["key"], row)
        attempt = 1
        if prev_err:
            # v3.5.0: ย้อนกลับไปค้นแถว ERROR ใหม่ทุกครั้ง — รวม ERROR! (ถาวร) และ ERROR#3 จากรอบก่อน
            # ที่เดิมถูกข้ามตลอดไป เพดานเหลือแค่ 'จำนวนครั้งที่ผิดในรอบนี้' กันวนเผาโควตา
            if self._tries.get(key, 0) >= self.RETRY_MAX_ATTEMPTS and not force:
                return "skip"
            attempt = prev_err["attempt"] + 1
            cell_f.value = None

        # เลขที่อ่านไว้ตอนเตรียมไฟล์ (ใช้ค่าที่คำนวณแล้วของสูตร Excel — ไม่ใช่ตัวสูตร)
        normalized = ctx["ids"].get(row)
        if normalized is None:
            normalized, padded, invalid = engine.normalize_id(raw)
            if invalid:
                cell_f.value = engine.invalid_id_note(raw)
                self._log(f"[{row}] ข้าม — เลขบัตรไม่ถูกต้อง ({engine.id_problem(raw)})")
                return "skip"
            if padded:
                cell_b.fill = engine.YELLOW
                cell_b.value = normalized

        # ♻ เคยค้นเลขนี้ในไฟล์นี้สำเร็จแล้ว (เช่นเครื่องดับ/แบตหมดก่อนไฟล์ถูกบันทึก)
        #   → กู้ผลจากประวัติในฐานข้อมูลลงช่องผลได้เลย ไม่ต้องค้นซ้ำ = ไม่เสียโควตา
        #   (ยกเว้นผล 'พบคดี' ที่ยาวจนใกล้เพดานที่เก็บไว้ — อาจถูกตัด ให้ค้นใหม่เพื่อความครบถ้วน)
        #   จำกัดเฉพาะผลของผู้ใช้คนเดียวกันและอายุไม่เกิน RESTORE_MAX_AGE_HOURS
        prev = db.find_prev_result(xlsx.name, normalized, row=row,
                                   user_id=self.current_user_id)
        if prev and not (prev["outcome"] == "found"
                         and len(prev.get("detail") or "") >= 490):
            if prev["outcome"] == "found":
                cell_f.value = prev["detail"]
                self.found += 1
                ctx["found_since_save"] += 1
                what = f"พบ {prev['case_count']} คดี"
                # ผลที่กู้มาเป็นข้อความล้วน ไม่มีอ็อบเจกต์คดีให้ตรวจความครบถ้วน
                # จึงใช้ธง incomplete ที่บันทึกไว้ตอนค้นครั้งแรกแทน (ไม่ parse ข้อความกลับ)
                if prev.get("incomplete"):
                    engine.mark_review_row(ws, row, out_col, on=True, skip_cols=(id_col,))
                    self.incomplete += 1
                    self._note_incomplete(row)
            else:
                cell_f.value = " - "
                self.notfound += 1
                what = "ไม่พบคดี"
            self.processed += 1
            self.restored += 1
            self.file_done += 1
            if attempt > 1:
                self.retry_fixed += 1
            self._log(f"[{row}] {db.mask_id(normalized)} → ♻ กู้ผลจากประวัติ ({what}) "
                      "— ไม่เสียโควตาค้นซ้ำ")
            self._bump_save(wb, xlsx, ctx)
            return "done"

        if self._recorder is not None:
            self._recorder.set_context(f"แถว {row} · เลขบัตร {db.mask_id(normalized)}")

        try:
            cases = engine.search_one_id(page, normalized,
                                         pause=self._pause_step, note=self._step_note,
                                         reason=ctx.get("reason"))
            if cases is None:
                return "stop"          # ถูกสั่งหยุดกลางขั้น (โหมดทีละขั้น)
            kept = [c for c in cases if not c.get("skip")]
            any_diff = any(
                c.get("table_id") and re.sub(r"\D", "", c["table_id"]) not in ("", normalized)
                for c in cases
            )
            if any_diff:
                cell_b.fill = engine.RED

            # ล้างมาร์ค 'ข้อมูลไม่ครบ' ของรอบก่อนเสมอ (เฉพาะเฉดของระบบ ไม่แตะสีของผู้ใช้)
            # เพื่อไม่ให้แถวที่รอบนี้ได้ข้อมูลครบแล้วยังค้างสีแดงจากรอบก่อน
            engine.mark_review_row(ws, row, out_col, on=False, skip_cols=(id_col,))

            if kept:
                text, review = engine.format_cases(kept, no_year)
                cell_f.value = text
                self.found += 1
                ctx["found_since_save"] += 1
                db.log_search(self.account, xlsx.name, row, normalized,
                              "found", len(kept), text, user_id=self.current_user_id,
                              incomplete=1 if review else 0)
                if review:
                    engine.mark_review_row(ws, row, out_col, on=True, skip_cols=(id_col,))
                    self.incomplete += 1
                    self._note_incomplete(row)
                    self._log(f"[{row}] {db.mask_id(normalized)} → พบ {len(kept)} คดี "
                              "⚠ ข้อมูลไม่ครบ (ไม่มีข้อหา/ปี) — มาร์คแดงไว้ให้ตรวจสอบ")
                else:
                    self._log(f"[{row}] {db.mask_id(normalized)} → พบ {len(kept)} คดี")
            else:
                cell_f.value = " - "
                self.notfound += 1
                db.log_search(self.account, xlsx.name, row, normalized,
                              "notfound", 0, "-", user_id=self.current_user_id)
                self._log(f"[{row}] {db.mask_id(normalized)} → ไม่พบคดี")
            self.processed += 1
            self.file_done += 1
            ctx["consec_err"] = 0
            if attempt > 1:
                self.retry_fixed += 1
                if self._tries.get(key):          # ผิดไปแล้วในรอบนี้ → หักออกจากยอดผิดพลาด
                    self.errors = max(0, self.errors - 1)
            self._bump_save(wb, xlsx, ctx, sleep=True)
            return "done"
        except Exception as e:
            err_text = str(e)
            # 🪟 ผู้ใช้ปิดหน้าต่าง Chrome/Chrome แครช → ค้นต่อไม่ได้แน่นอน
            # บันทึกไฟล์แล้วหยุดรอบอย่างสะอาด — ห้ามเขียน ERROR ไล่ทุกแถวที่เหลือ
            if engine.is_browser_closed_error(err_text):
                self._log(f"[{row}] 🪟 หน้าต่าง Chrome ถูกปิด — หยุดค้นและบันทึกผลที่ได้แล้ว")
                self._save_checked(wb, xlsx, ctx["found_since_save"])
                ctx["found_since_save"] = 0
                ctx["since_save"] = 0
                self._browser_gone = True
                self._stop = True
                return "stop"
            kind = engine.classify_error(err_text)
            # 📡 เน็ตหลุด/เข้าเว็บไม่ถึง → 'ไม่' เขียน ERROR ลงช่องผล (เว้นไว้ค้นใหม่ตอนกลับมา)
            # บันทึกไฟล์แล้วพักอัตโนมัติทันที — กันการไล่ค้นทุกแถวที่เหลือทั้งที่ไม่มีเน็ต
            if kind == "net" or engine.is_network_error(err_text) or not engine.probe_online():
                self._log(f"[{row}] 📡 เชื่อมต่อไม่ได้: {err_text[:80]}")
                if self._save_checked(wb, xlsx, ctx["found_since_save"]):
                    ctx["found_since_save"] = 0
                ctx["since_save"] = 0
                if not self._pause_wait("network"):
                    return "stop"
                return "same_row"
            # 🔐 หลุด login ที่ปลายทาง — ไล่ยิงต่อมีแต่เสียโควตาเปล่า ต้องให้คนมาล็อกอินก่อน
            if kind == "auth":
                self._log(f"[{row}] 🔐 ดูเหมือนหลุดการเข้าสู่ระบบ CRIMES: {err_text[:80]}")
                if self._save_checked(wb, xlsx, ctx["found_since_save"]):
                    ctx["found_since_save"] = 0
                ctx["since_save"] = 0
                if not self._pause_wait("auth"):
                    return "stop"
                return "same_row"

            permanent = (kind == "permanent")
            msg = engine.format_error_cell(err_text, attempt=attempt, permanent=permanent)
            cell_f.value = msg
            if not self._tries.get(key):
                self.errors += 1              # นับ 'แถว' ที่ผิดพลาด ไม่ใช่นับทุกครั้งที่ลอง
            self._tries[key] = self._tries.get(key, 0) + 1
            ctx["consec_err"] += 1
            db.log_search(self.account, xlsx.name, row, normalized, "error", 0, msg,
                          user_id=self.current_user_id, attempt=attempt)
            self._log(f"[{row}] {db.mask_id(normalized)} → {msg[:60]}")
            # เก็บหลักฐาน (ภาพ+HTML) ไว้ตรวจว่าเว็บ CRIMES เปลี่ยน DOM หรือไม่
            shot = engine.capture_diagnostics(page, f"row{row}")
            if shot:
                self._log(f"    (บันทึกหน้าจอ/HTML ไว้ที่ {shot})")
            # ⚠ ผิดพลาดติดกันหลายแถว = น่าจะมีปัญหาที่เว็บ/ระบบ ไม่ใช่ข้อมูลแถวเดียว
            if ctx["consec_err"] >= 3:
                if self._save_checked(wb, xlsx, ctx["found_since_save"]):
                    ctx["found_since_save"] = 0
                ctx["since_save"] = 0
                if not self._pause_wait("errors"):
                    return "stop"
                ctx["consec_err"] = 0
                return "same_row"     # ลองแถวเดิมอีกครั้งหลังกลับมา
            self._bump_save(wb, xlsx, ctx, sleep=True)
            return "error"

    def _bump_save(self, wb, xlsx, ctx, sleep=False):
        """นับแถวที่ประมวลผลแล้วบันทึกไฟล์ทุก 3 แถว (จังหวะเดิมของระบบ)"""
        ctx["since_save"] += 1
        if ctx["since_save"] >= 3:
            if self._save_checked(wb, xlsx, ctx["found_since_save"]):
                ctx["found_since_save"] = 0
            ctx["since_save"] = 0
        if sleep:
            engine.sleep_range(1.0, 2.5)

    def _note_incomplete(self, row):
        self.incomplete_rows.append(row)
        del self.incomplete_rows[:-200]      # เก็บท้าย ๆ ไว้พอให้ผู้ใช้ไล่ตรวจ

    # ==================== รอบที่ 2: ลองแถวที่เป็น ERROR ใหม่ ====================
    def _collect_error_rows(self, ws, ctx, start_row, end_row, force=False, all_rows=False):
        """กวาดหาแถวที่ช่องผลเป็น ERROR จากไฟล์ Excel จริง
        ลองใหม่ได้ = ยังไม่ครบเพดานจำนวนครั้งที่ผิด 'ในรอบนี้' (force = ไม่สนเพดาน)
        all_rows=True นับทุกแถวที่ยังเป็น ERROR (ใช้บอกผู้ใช้ว่ายังค้างกี่แถว)"""
        rows = []
        r = start_row
        while True:
            if end_row is not None and r > end_row:
                break
            v = ws.cell(row=r, column=ctx["id_col"]).value
            if v is None or str(v).strip() == "":
                break
            info = engine.parse_error_cell(ws.cell(row=r, column=ctx["out_col"]).value)
            if info and (all_rows or force
                         or self._tries.get((ctx["key"], r), 0) < self.RETRY_MAX_ATTEMPTS):
                rows.append(r)
            r += 1
        return rows

    def _sleep_interruptible(self, seconds):
        """หน่วงแบบกด 'หยุด' ได้ทันที และยังรับคำขอ 'บันทึก·ดาวน์โหลด' ระหว่างรอ
        (เดิมหน่วงก่อนรอบลองใหม่ 20–70 วินาทีแบบกดอะไรไม่ได้เลย)"""
        end = time.time() + max(0.0, seconds)
        while time.time() < end:
            if self._stop:
                return False
            self._service_save()
            time.sleep(min(0.3, max(0.0, end - time.time())))
        return not self._stop

    def _retry_error_rows(self, page, wb, ws, xlsx, ctx, start_row, end_row, force=False):
        """วนกลับมาลองแถวที่เป็น ERROR ซ้ำ สูงสุด RETRY_MAX_PASSES รอบต่อไฟล์

        หยุดเมื่อ: ไม่มีแถวเหลือ / รอบที่ผ่านมาแก้ไม่ได้สักแถว (กันวนไม่รู้จบตอนเว็บล่ม)
        / ถูกสั่งหยุด — และเคารพกลไกพักทุกจุดเหมือนรอบหลัก"""
        if not self.auto_retry and not force:
            return
        for p in range(1, self.RETRY_MAX_PASSES + 1):
            rows = self._collect_error_rows(ws, ctx, start_row, end_row, force=force)
            self.retry_pending = len(rows)
            if not rows or self._stop:
                break
            self.retry_pass = p
            self._log(f"🔁 รอบลองใหม่ที่ {p}: ย้อนกลับไปค้นแถวที่ผิดพลาด {len(rows)} แถว "
                      f"(แถว {', '.join(str(x) for x in rows[:15])}{' …' if len(rows) > 15 else ''})")
            # หน่วงก่อนเริ่มรอบใหม่ ให้เว็บ/เครือข่ายมีเวลาฟื้น (กดหยุดได้ระหว่างรอ)
            base = self.RETRY_BACKOFF[min(p - 1, len(self.RETRY_BACKOFF) - 1)]
            if not self._sleep_interruptible(random.uniform(base, base + 10) * engine.DELAY_FACTOR):
                return
            fixed_before = self.retry_fixed
            for r in rows:
                if self._stop:
                    break
                self._service_save()
                if self._pause_request:
                    self._pause_request = False
                    if self._save_checked(wb, xlsx, ctx["found_since_save"]):
                        ctx["found_since_save"] = 0
                    ctx["since_save"] = 0
                    if not self._pause_wait("manual"):
                        return
                st = self._search_row(page, wb, ws, xlsx, r, ctx, force=force)
                while st == "same_row" and not self._stop:
                    st = self._search_row(page, wb, ws, xlsx, r, ctx, force=force)
                if st == "stop":
                    return
            if self.retry_fixed == fixed_before:
                self._log("🔁 รอบลองใหม่ไม่สามารถแก้ได้เลย — หยุดลองเพื่อไม่ให้เสียโควตา "
                          "(กด ▶ LOGIN CRIMES รอบหน้า ระบบจะย้อนกลับมาค้นแถวเหล่านี้ใหม่)")
                break
        self.retry_pending = len(self._collect_error_rows(ws, ctx, start_row, end_row,
                                                          all_rows=True))
        if self.retry_fixed:
            self._log(f"🔁 ลองใหม่สำเร็จ {self.retry_fixed} แถว · ยังเหลือ {self.retry_pending} แถว")

    def _process_file(self, page, job):
        import openpyxl
        self._page = page
        # เปิดตัวบันทึกโหมดทีละขั้นครั้งแรกที่เริ่มประมวลผล (1 ตัวต่อ 1 รอบการทำงาน)
        if self.record_steps and self._recorder is None:
            try:
                self._recorder = engine.ManualRecorder(account=self.account)
                self._log("🔴 เริ่มบันทึกการทำงานโหมดทีละขั้น (เก็บภาพ/HTML แต่ละสเต็ป "
                          "ไว้เป็นข้อมูลปรับปรุงระบบเมื่อเว็บเปลี่ยน)")
            except Exception:
                self._recorder = None
        xlsx = Path(job["path"]).resolve()
        if not xlsx.exists():
            self._log(f"[!] ไม่พบไฟล์ {xlsx.name}")
            return
        id_col = engine.col_letter_to_num(job.get("id_col", "B"))
        out_col = engine.col_letter_to_num(job.get("out_col", "F"))
        no_year = bool(job.get("no_year", False))
        start_row = int(job.get("start_row", 2))
        end_row = job.get("end_row")
        end_row = int(end_row) if end_row else None
        sheet = job.get("sheet")

        try:
            wb = openpyxl.load_workbook(xlsx)
            ws = wb[sheet] if sheet else wb.active
        except Exception as e:
            # ไฟล์เสีย/ไม่ใช่ Excel จริง → ข้ามไฟล์นี้ ไปไฟล์ถัดไป (เดิมทั้งรอบล้มเป็น 'ผิดพลาด')
            self._log(f"[!] เปิดไฟล์ {xlsx.name} ไม่ได้ — ข้ามไฟล์นี้ ({str(e)[:120]})")
            return

        self.current_file = xlsx.name
        self.current_path = str(xlsx)
        # ให้ปุ่ม 'บันทึก·ดาวน์โหลด' ระหว่างค้นเข้าถึง workbook ได้ (บันทึกจากเธรดงานเท่านั้น)
        self._wb, self._xlsx = wb, xlsx
        self.total_rows = self._count_rows(ws, id_col, start_row, end_row)
        self.row = start_row
        self._log(f"=== {xlsx.name} ({self.total_rows} แถว) ===")

        reason = job.get("reason") or None
        ctx = {
            "id_col": id_col, "out_col": out_col, "no_year": no_year,
            "reason": reason,
            "since_save": 0, "found_since_save": 0,
            "consec_err": 0,
            "key": str(xlsx), "ids": {},
        }
        # เตรียมไฟล์ก่อนค้น: อ่านเลขบัตรทุกแถว เติม 0 หน้าเลข 12 หลักให้ครบทุกแถว
        # (รวมแถวที่มีผลอยู่แล้ว) และเขียนหมายเหตุแถวที่เลขใช้ไม่ได้ — แล้วบันทึกทันที
        self._prepare_rows(xlsx, wb, ws, ctx, start_row, end_row)
        row = start_row
        while not self.retry_only:      # โหมดลองเฉพาะแถวผิดพลาด = ข้ามลูปหลักไปเลย
            if self._stop:
                break
            # จุดปลอดภัยระหว่างแถว: บริการคำขอ 'บันทึกเดี๋ยวนี้' และ 'พักชั่วคราว'
            self._service_save()
            if self._pause_request:
                self._pause_request = False
                if self._save_checked(wb, xlsx, ctx["found_since_save"]):
                    ctx["found_since_save"] = 0
                ctx["since_save"] = 0
                if not self._pause_wait("manual"):
                    break
            if end_row is not None and row > end_row:
                break
            st = self._search_row(page, wb, ws, xlsx, row, ctx)
            if st in ("end", "stop"):
                break
            if st == "same_row":
                continue          # ลองแถวเดิมอีกครั้ง (row ยังไม่ขยับ)
            row += 1

        # ---- รอบที่ 2: วนกลับมาลองแถวที่เป็น ERROR อีกครั้ง ----
        # ต้องอยู่ตรงนี้ (ก่อนบันทึกปิดท้ายและก่อนล้าง self._wb) เพราะ workbook ยังเปิดอยู่
        # ปุ่ม 'บันทึก·ดาวน์โหลด' ระหว่างรันจึงยังใช้ได้ตลอดรอบ retry
        if not self._stop:
            self._retry_error_rows(page, wb, ws, xlsx, ctx, start_row, end_row,
                                   force=self.retry_only)

        found_since_save = ctx["found_since_save"]
        if self._save_checked(wb, xlsx, found_since_save):
            found_since_save = 0
            self._log(f"บันทึก {xlsx.name} แล้ว")

        # แถวที่ยังเป็น ERROR หลังจบไฟล์ — ให้หน้าเว็บรู้ว่าต้องโชว์ปุ่ม 'ลองแถวที่ผิดพลาด'
        left = len(self._collect_error_rows(ws, ctx, start_row, end_row, all_rows=True))
        self._errors_left[str(xlsx)] = left
        if left and not self._stop:
            self._log(f"⚠ {xlsx.name}: ยังมีแถวผิดพลาดค้าง {left} แถว — "
                      "กด ▶ LOGIN CRIMES อีกครั้ง ระบบจะย้อนกลับไปค้นแถวเหล่านี้ใหม่")

        # จบไฟล์นี้แล้ว — ตัดช่องทาง 'บันทึกตามคำขอ' ไม่ให้ชี้ workbook เก่า
        self._wb = None
        self._xlsx = None

        # ค้นครบทุกแถวแล้ว (ไม่ได้ถูกสั่งหยุดกลางคัน) → เซฟผลอัตโนมัติไปที่ Downloads
        if not self._stop:
            self._save_to_downloads(xlsx)

    def _prepare_rows(self, xlsx, wb, ws, ctx, start_row, end_row):
        """ขั้นเตรียมไฟล์ (v3.5.0) — ทำครั้งเดียวตอนเปิดไฟล์ ก่อนค้นแถวแรก

        • อ่านเลขบัตรทุกแถวด้วยตัวอ่านใหม่ (ทศนิยม/เลขไทย/สูตร Excel) เก็บไว้ใน ctx['ids']
        • เลข 12 หลัก (Excel ตัดศูนย์หน้าทิ้ง) → เติม '0' ข้างหน้าให้ 'ทุกแถว' ทันที + มาร์คเหลือง
          เดิมเติมเฉพาะแถวที่กำลังจะค้น แถวที่มีผลแล้ว/ถูกข้าม/ค้นไม่ถึงจึงยังเหลือ 12 หลัก
        • เลขที่ใช้ไม่ได้ → เขียนหมายเหตุลงช่องผล (เดิมข้ามเงียบ ๆ ไฟล์จึงไม่มีวันครบ)
        • นับแถวที่มีผลแล้ว เป็นจุดเริ่มของแถบความคืบหน้า"""
        import openpyxl
        id_col, out_col = ctx["id_col"], ctx["out_col"]
        rows = []
        formula_rows = []
        r = start_row
        while end_row is None or r <= end_row:
            cell = ws.cell(row=r, column=id_col)
            v = cell.value
            if v is None or str(v).strip() == "":
                break
            rows.append(r)
            if cell.data_type == "f" or (isinstance(v, str) and v.startswith("=")):
                formula_rows.append(r)
            r += 1
        # เซลล์เลขบัตรที่เป็นสูตร (เช่น =TEXT(A2,"0000000000000")) ต้องใช้ 'ค่าที่คำนวณแล้ว'
        # เดิมอ่านได้ตัวสูตรเป็นข้อความ แล้วดึงตัวเลขจากสูตรไปค้น = เลขมั่ว/ถูกข้าม
        cached = {}
        if formula_rows:
            try:
                wbv = openpyxl.load_workbook(xlsx, data_only=True, read_only=True)
                try:
                    wsv = wbv[ws.title]
                    lo, hi = min(formula_rows), max(formula_rows)
                    for i, vals in enumerate(wsv.iter_rows(min_row=lo, max_row=hi,
                                                           min_col=id_col, max_col=id_col,
                                                           values_only=True)):
                        cached[lo + i] = vals[0] if vals else None
                finally:
                    wbv.close()
            except Exception:
                cached = {}
        changed = False
        padded = invalid = settled = 0
        for r in rows:
            cell = ws.cell(row=r, column=id_col)
            is_formula = r in formula_rows
            raw = cached.get(r) if is_formula else cell.value
            res = ws.cell(row=r, column=out_col)
            res_empty = res.value is None or str(res.value).strip() == ""
            if is_formula and raw is None:
                # ไฟล์ไม่เคยถูกคำนวณสูตร (สร้างจากโปรแกรมอื่น) — ไม่มีค่าให้ค้น
                if res_empty:
                    res.value = engine.INVALID_ID_NOTE.format(
                        why="เซลล์เป็นสูตรที่ยังไม่ถูกคำนวณ — เปิดไฟล์ใน Excel แล้วบันทึกใหม่")
                    invalid += 1
                    changed = True
                settled += 1
                continue
            normalized, was_padded, bad = engine.normalize_id(raw)
            if bad:
                if res_empty:
                    res.value = engine.invalid_id_note(raw)
                    invalid += 1
                    changed = True
                    if invalid <= 10:        # กันบันทึกรกถ้าไฟล์มีแถวขยะเยอะ (สรุปยอดท้ายขั้นตอน)
                        self._log(f"[{r}] ⚠ เลขบัตรไม่ถูกต้อง ({engine.id_problem(raw)}) — ไม่ค้น")
                settled += 1
                continue
            ctx["ids"][r] = normalized
            if is_formula:
                # openpyxl บันทึกไฟล์แล้ว 'ค่าที่คำนวณไว้ของสูตรหายหมด' (มันคำนวณสูตรเองไม่ได้)
                # ถ้าคงสูตรไว้ รอบหน้าจะอ่านเลขบัตรไม่ได้ทั้งคอลัมน์ → แปลงเป็นค่าเลขบัตรเลย
                # (ไฟล์นี้เป็นสำเนาที่อัปโหลดเข้าโปรแกรม ไม่ใช่ไฟล์ต้นฉบับของผู้ใช้)
                cell.value = normalized
                changed = True
            if was_padded:
                cell.fill = engine.YELLOW
                cell.value = normalized
                padded += 1
                changed = True
            if not res_empty and not engine.is_error_cell(res.value):
                settled += 1
        self.file_done = settled
        if formula_rows:
            self._log(f"แปลงสูตรในคอลัมน์เลขบัตรเป็นค่าเลขบัตร {len(formula_rows)} แถว "
                      "(กันรอบหน้าอ่านเลขไม่ได้)")
        if padded:
            self.padded += padded
            self._log(f"🟨 เติม 0 หน้าเลขบัตร 12 หลักให้ครบ 13 หลักแล้ว {padded} แถว (มาร์คสีเหลือง)")
        if invalid:
            self.invalid_ids += invalid
            self._log(f"⚠ เลขบัตรใช้ไม่ได้ {invalid} แถว — เขียนหมายเหตุไว้ในช่องผลแล้ว ไม่เสียโควตาค้น")
        if changed:
            self._save_checked(wb, xlsx)


# singleton
manager = RunManager()
