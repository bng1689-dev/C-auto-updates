"""SQLite storage for CRIMES web app — history + monthly summaries + users + billing."""
import hashlib
import json
import re
import secrets
import sqlite3
import threading
from datetime import datetime, timedelta


def mask_id(nid):
    """ปิดข้อมูลเลขบัตรประชาชน — แสดงประมาณ 30% (ตัวหน้า) ปิดที่เหลือ ~70% ด้วย X
    เช่น 3101501909804 -> 3101XXXXXXXXX (13 หลัก แสดง 4 ปิด 9)"""
    s = str(nid or "").strip()
    digits = re.sub(r"\D", "", s)
    if not digits:
        return s
    show = max(1, round(len(digits) * 0.3))
    if show >= len(digits):
        return digits
    return digits[:show] + "X" * (len(digits) - show)


_ID_SALT_CACHE = ""


def _id_salt():
    """secret ประจำเครื่อง (จาก config.json ซึ่งเป็นคนละไฟล์กับ data.db) ใช้ salt แฮชเลขบัตร
    ป้องกันการถอดกลับด้วย brute-force กรณี data.db หลุดแต่ไม่ได้ config.json"""
    global _ID_SALT_CACHE
    if _ID_SALT_CACHE:
        return _ID_SALT_CACHE
    try:
        import json
        from config import CONFIG_PATH
        cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        _ID_SALT_CACHE = str(cfg.get("secret_key", "") or "")
    except Exception:
        _ID_SALT_CACHE = ""
    return _ID_SALT_CACHE


def _hash_id(full_digits):
    """แฮชเลขบัตร (salted) สำหรับนับจำนวนไม่ซ้ำ — ไม่เก็บเลขเต็ม และถอดกลับไม่ได้ง่าย"""
    if not full_digits:
        return ""
    return hashlib.sha256((_id_salt() + "|" + full_digits).encode("utf-8")).hexdigest()

from config import DB_PATH  # ฐานข้อมูล SQLite ที่จัดเก็บเอง (กำหนดที่ backend/config.py)

_lock = threading.Lock()
_ITERATIONS = 200_000


def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def backup_db(keep=14):
    """สำรอง data.db อัตโนมัติ (วันละครั้ง เก็บย้อนหลัง keep ไฟล์ล่าสุด)

    ไฟล์นี้คือสำเนาเดียวของผู้ใช้/ประวัติ/ฐานคิดเงินทั้งหมด และตัวอัปเดตออนไลน์
    ตั้งใจ 'ไม่แตะ' โฟลเดอร์ data — จึงต้องสำรองเองก่อนเปิดใช้/ก่อน migration ทุกครั้ง
    ใช้ sqlite backup API เพื่อได้สำเนา consistent แม้มีการเขียนค้างอยู่
    คืน path ของไฟล์สำรอง หรือ None (วันนี้สำรองแล้ว / ฐานข้อมูลยังไม่มี / พลาด)"""
    try:
        from pathlib import Path
        dbp = Path(DB_PATH)
        if not dbp.exists() or dbp.stat().st_size == 0:
            return None
        bdir = dbp.parent / "backups"
        bdir.mkdir(parents=True, exist_ok=True)
        dest = bdir / f"data-{datetime.now().strftime('%Y%m%d')}.db"
        if dest.exists():
            return None          # วันนี้สำรองไปแล้ว
        src = sqlite3.connect(str(dbp))
        try:
            dst = sqlite3.connect(str(dest))
            try:
                with dst:
                    src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
        # เก็บเฉพาะ keep ไฟล์ล่าสุด (ชื่อไฟล์เรียงตามวันที่ได้เลย)
        for f in sorted(bdir.glob("data-*.db"))[:-keep]:
            try:
                f.unlink()
            except OSError:
                pass
        return dest
    except Exception:
        return None              # การสำรองพลาดต้องไม่ทำให้โปรแกรมเปิดไม่ขึ้น


def init_db():
    backup_db()   # สำรองก่อนแตะ schema เสมอ — กันเหนียวทั้ง migration และการใช้งานประจำวัน
    with get_conn() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS searches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                ym TEXT NOT NULL,
                account TEXT,
                file TEXT,
                row INTEGER,
                national_id TEXT,
                outcome TEXT,
                case_count INTEGER DEFAULT 0,
                detail TEXT,
                user_id INTEGER DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_searches_ym ON searches(ym);
            CREATE INDEX IF NOT EXISTS idx_searches_account ON searches(account);

            CREATE TABLE IF NOT EXISTS runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started TEXT,
                ended TEXT,
                account TEXT,
                files TEXT,
                total INTEGER DEFAULT 0,
                found INTEGER DEFAULT 0,
                notfound INTEGER DEFAULT 0,
                errors INTEGER DEFAULT 0,
                status TEXT,
                user_id INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                display_name TEXT DEFAULT '',
                role TEXT DEFAULT 'member',
                permissions TEXT DEFAULT '{}',
                active INTEGER DEFAULT 1,
                created_at TEXT
            );

            CREATE TABLE IF NOT EXISTS billing_config (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                rate_per_name REAL DEFAULT 0.0
            );
            INSERT OR IGNORE INTO billing_config(id, rate_per_name) VALUES(1, 0.0);

            CREATE TABLE IF NOT EXISTS meta (
                k TEXT PRIMARY KEY,
                v TEXT
            );

            CREATE TABLE IF NOT EXISTS teams (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                rate_per_name REAL,
                created_at TEXT
            );

            CREATE TABLE IF NOT EXISTS team_members (
                team_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                PRIMARY KEY (team_id, user_id),
                FOREIGN KEY (team_id) REFERENCES teams(id),
                FOREIGN KEY (user_id) REFERENCES users(id)
            );

            CREATE TABLE IF NOT EXISTS billing_adjust (
                user_id INTEGER NOT NULL,
                ym TEXT NOT NULL,
                adj_count INTEGER,
                adj_amount REAL,
                note TEXT,
                updated_at TEXT,
                PRIMARY KEY (user_id, ym)
            );

            CREATE TABLE IF NOT EXISTS secure_config (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                code_hash TEXT,
                code_salt TEXT,
                updated_at TEXT
            );
            INSERT OR IGNORE INTO secure_config(id) VALUES(1);

            CREATE TABLE IF NOT EXISTS file_formats (
                sig TEXT PRIMARY KEY,
                id_col TEXT,
                out_col TEXT,
                start_row INTEGER,
                headers TEXT,
                hits INTEGER DEFAULT 1,
                updated_at TEXT
            );

            CREATE TABLE IF NOT EXISTS summary_adjust (
                ym TEXT PRIMARY KEY,
                total INTEGER,
                found INTEGER,
                notfound INTEGER,
                error INTEGER,
                cases INTEGER,
                note TEXT,
                updated_at TEXT
            );

            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                user_id INTEGER DEFAULT 0,
                username TEXT,
                action TEXT NOT NULL,
                detail TEXT,
                ip TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts);
            """
        )
        _maybe_add_column(c, "searches", "user_id", "INTEGER DEFAULT 0")
        _maybe_add_column(c, "runs", "user_id", "INTEGER DEFAULT 0")
        _maybe_add_column(c, "users", "rate_per_name", "REAL")
        _maybe_add_column(c, "teams", "rate_per_name", "REAL")
        # ครั้งเดียว: ย้ายอัตราค่าบริการเริ่มต้นเดิม (7.0) → ค่าเริ่มต้นใหม่ 0 บาท
        # เฉพาะเครื่องที่ยังไม่เคยตั้งเอง (ยังเป็น 7.0 พอดี) · ตั้งเองไว้แล้วไม่แตะ
        done = c.execute("SELECT v FROM meta WHERE k='rate_default_zero'").fetchone()
        if not done:
            c.execute("UPDATE billing_config SET rate_per_name=0 WHERE id=1 AND rate_per_name=7.0")
            c.execute("INSERT OR REPLACE INTO meta(k, v) VALUES('rate_default_zero', '1')")
        # ---- ปิดข้อมูลเลขบัตร: เก็บ hash ไว้นับจำนวน + ปิดบังเลขที่เก็บ (ไม่เก็บเลขเต็ม) ----
        _maybe_add_column(c, "searches", "id_hash", "TEXT")
        # ---- v2.4.0: ธง 'ข้อมูลคดีไม่ครบ' + ครั้งที่ลองค้น (เพิ่มคอลัมน์ล้วน ย้อนรุ่นได้) ----
        _maybe_add_column(c, "searches", "incomplete", "INTEGER DEFAULT 0")
        _maybe_add_column(c, "searches", "attempt", "INTEGER DEFAULT 1")
        # แถวเก่าที่ยังไม่ปิดบัง (id_hash ว่าง) → คำนวณ hash จากเลขเต็มเดิม แล้วปิดบังเลขทันที
        for r in c.execute("SELECT id, national_id FROM searches WHERE id_hash IS NULL").fetchall():
            full = re.sub(r"\D", "", str(r["national_id"] or ""))
            c.execute("UPDATE searches SET id_hash=?, national_id=? WHERE id=?",
                      (_hash_id(full), mask_id(r["national_id"]), r["id"]))


def _maybe_add_column(conn, table, col, typedef):
    cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
    if col not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typedef}")


# ──────────────── audit log (เหตุการณ์สำคัญด้านความปลอดภัย/การจัดการ) ────────────────

def log_audit(action, detail="", user_id=0, username="", ip=""):
    """บันทึกเหตุการณ์สำคัญ (ล็อกอิน/ออก, อัปเดตโปรแกรม, ล้างข้อมูล, จัดการสมาชิก, ตั้งรหัสยืนยัน)

    best-effort — ห้าม throw ออกไปทำให้การกระทำหลักล้ม
    """
    now = datetime.now().isoformat(timespec="seconds")
    try:
        with _lock, get_conn() as c:
            c.execute(
                "INSERT INTO audit_log(ts,user_id,username,action,detail,ip) VALUES(?,?,?,?,?,?)",
                (now, int(user_id or 0), username or "", str(action),
                 str(detail or "")[:500], str(ip or "")[:64]),
            )
    except Exception:
        pass


def get_audit_log(limit=200, offset=0):
    """ดึงรายการ audit ล่าสุดก่อน (ใหม่→เก่า)"""
    with get_conn() as c:
        rows = c.execute(
            "SELECT id,ts,user_id,username,action,detail,ip FROM audit_log "
            "ORDER BY id DESC LIMIT ? OFFSET ?",
            (int(limit), int(offset)),
        ).fetchall()
    return [dict(r) for r in rows]


# ──────────────── สิทธิ์ย่อยรายผู้ใช้ ────────────────
# เดิมมีแค่ 2 ระดับ (Super Admin เห็น/ทำได้ทุกอย่าง กับสมาชิกที่ทำได้เฉพาะของตัวเอง)
# ตารางนี้ให้มอบสิทธิ์เฉพาะเรื่องแก่สมาชิกได้ โดยไม่ต้องยกระดับเป็น Super Admin
# (Super Admin ได้ครบทุกข้อโดยอัตโนมัติ — ไม่ต้องติ๊ก)
PERMISSION_KEYS = {
    "view_team": "ดูข้อมูลและยอดของทีมตัวเอง",
    "manage_members": "จัดการสมาชิก",
    "manage_teams": "จัดการทีม",
    "manage_billing": "ตั้งอัตราค่าบริการและปรับยอด",
    "view_audit": "ดูบันทึกเหตุการณ์",
}


def parse_permissions(raw):
    """แปลงค่าที่เก็บใน users.permissions เป็น dict ครบทุกคีย์ — ข้อมูลเสีย/ว่าง = ไม่มีสิทธิ์"""
    try:
        data = json.loads(raw) if isinstance(raw, str) else raw
    except (ValueError, TypeError):
        data = None
    if not isinstance(data, dict):
        data = {}
    return {k: bool(data.get(k)) for k in PERMISSION_KEYS}


def get_permissions(user_id):
    """สิทธิ์ที่ใช้จริง — Super Admin ได้ครบ, ผู้ใช้ที่ถูกปิดใช้งานไม่ได้สิทธิ์ใดเลย"""
    user = get_user(user_id) if user_id else None
    if not user or not user.get("active"):
        return {k: False for k in PERMISSION_KEYS}
    if user.get("role") == "super_admin":
        return {k: True for k in PERMISSION_KEYS}
    return parse_permissions(user.get("permissions"))


def set_permissions(user_id, perms):
    """บันทึกสิทธิ์ — เก็บเฉพาะคีย์ที่เปิดไว้ และตัดคีย์แปลกปลอมทิ้ง"""
    clean = {k: True for k in PERMISSION_KEYS if (perms or {}).get(k)}
    update_user(user_id, permissions=json.dumps(clean, ensure_ascii=False))
    return {k: k in clean for k in PERMISSION_KEYS}


def team_member_ids(user_id):
    """user_id ทุกคนที่อยู่ทีมเดียวกับคนนี้ (รวมตัวเอง) — ใช้กับสิทธิ์ view_team
    ไม่ได้สังกัดทีมไหนเลย = เห็นแค่ของตัวเอง"""
    with get_conn() as c:
        rows = c.execute(
            "SELECT DISTINCT tm2.user_id FROM team_members tm1"
            " JOIN team_members tm2 ON tm2.team_id=tm1.team_id"
            " WHERE tm1.user_id=?", (user_id,)
        ).fetchall()
    return sorted({r["user_id"] for r in rows} | {user_id})


# ──────────────── user management ────────────────

def _hash_pw(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                               bytes.fromhex(salt), _ITERATIONS).hex()


def create_user(username, password, display_name="", role="member"):
    salt = secrets.token_hex(16)
    pw_hash = _hash_pw(password, salt)
    now = datetime.now().isoformat(timespec="seconds")
    with _lock, get_conn() as c:
        c.execute(
            "INSERT INTO users(username,password_hash,salt,display_name,role,created_at)"
            " VALUES(?,?,?,?,?,?)",
            (username, pw_hash, salt, display_name, role, now),
        )
        return c.execute("SELECT last_insert_rowid()").fetchone()[0]


def verify_user(username, password):
    with get_conn() as c:
        row = c.execute(
            "SELECT * FROM users WHERE username=? AND active=1", (username,)
        ).fetchone()
    if not row:
        return None
    expected = row["password_hash"]
    got = _hash_pw(password, row["salt"])
    if secrets.compare_digest(expected, got):
        return dict(row)
    return None


def get_user(user_id):
    with get_conn() as c:
        row = c.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    return dict(row) if row else None


def list_users():
    with get_conn() as c:
        rows = c.execute(
            "SELECT id,username,display_name,role,permissions,active,created_at,rate_per_name"
            " FROM users ORDER BY id"
        ).fetchall()
    out = []
    for r in rows:
        u = dict(r)
        # ส่งเป็น dict ที่มีครบทุกคีย์เสมอ — หน้าจอจะได้ผูกเช็คบ็อกซ์ได้ตรง ๆ
        u["permissions"] = ({k: True for k in PERMISSION_KEYS}
                            if u["role"] == "super_admin"
                            else parse_permissions(u["permissions"]))
        out.append(u)
    return out


def update_user(user_id, **fields):
    allowed = {"display_name", "role", "active", "permissions", "rate_per_name"}
    sets = []
    vals = []
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=?")
            vals.append(v)
    if not sets:
        return
    vals.append(user_id)
    with _lock, get_conn() as c:
        c.execute(f"UPDATE users SET {','.join(sets)} WHERE id=?", vals)


def change_user_password(user_id, new_password):
    salt = secrets.token_hex(16)
    pw_hash = _hash_pw(new_password, salt)
    with _lock, get_conn() as c:
        c.execute("UPDATE users SET password_hash=?,salt=? WHERE id=?",
                  (pw_hash, salt, user_id))


def delete_user(user_id):
    """ลบสมาชิกออกจากระบบจริง พร้อมถอดออกจากทุกทีม"""
    with _lock, get_conn() as c:
        c.execute("DELETE FROM team_members WHERE user_id=?", (user_id,))
        c.execute("DELETE FROM users WHERE id=?", (user_id,))


def count_super_admins(exclude_id=None):
    q = "SELECT COUNT(*) n FROM users WHERE role='super_admin' AND active=1"
    args = ()
    if exclude_id is not None:
        q += " AND id<>?"
        args = (exclude_id,)
    with get_conn() as c:
        r = c.execute(q, args).fetchone()
    return r["n"]


def has_any_user():
    with get_conn() as c:
        r = c.execute("SELECT COUNT(*) n FROM users").fetchone()
    return r["n"] > 0


# ──────────────── รหัสยืนยัน (สำหรับล้างทั้งหมด/แก้ไขจำนวน) ────────────────

def set_action_code(code):
    """ตั้ง/ลบรหัสยืนยัน (code ว่าง = ลบรหัส)"""
    now = datetime.now().isoformat(timespec="seconds")
    with _lock, get_conn() as c:
        if not code:
            c.execute("UPDATE secure_config SET code_hash=NULL, code_salt=NULL, updated_at=? WHERE id=1", (now,))
        else:
            salt = secrets.token_hex(16)
            c.execute("UPDATE secure_config SET code_hash=?, code_salt=?, updated_at=? WHERE id=1",
                      (_hash_pw(code, salt), salt, now))


def has_action_code():
    with get_conn() as c:
        r = c.execute("SELECT code_hash FROM secure_config WHERE id=1").fetchone()
    return bool(r and r["code_hash"])


def verify_action_code(code):
    if not code:
        return False
    with get_conn() as c:
        r = c.execute("SELECT code_hash, code_salt FROM secure_config WHERE id=1").fetchone()
    if not r or not r["code_hash"]:
        return False
    return secrets.compare_digest(r["code_hash"], _hash_pw(code, r["code_salt"]))


# ──────────────── ล้างข้อมูล ────────────────

def clear_search_history(user_id=None):
    """ล้างประวัติการค้น — ถ้าระบุ user_id ลบเฉพาะของคนนั้น, ไม่ระบุ=ลบทั้งหมด"""
    with _lock, get_conn() as c:
        if user_id:
            c.execute("DELETE FROM searches WHERE user_id=?", (user_id,))
            c.execute("DELETE FROM runs WHERE user_id=?", (user_id,))
            c.execute("DELETE FROM billing_adjust WHERE user_id=?", (user_id,))
        else:
            c.execute("DELETE FROM searches")
            c.execute("DELETE FROM runs")
            c.execute("DELETE FROM billing_adjust")
            c.execute("DELETE FROM summary_adjust")
            c.execute("DELETE FROM sqlite_sequence WHERE name IN ('searches','runs')")


def clear_all_data():
    """ล้างข้อมูลการค้นทั้งระบบ (เก็บ users/teams/config/รหัส)"""
    clear_search_history(user_id=None)


# ──────────────── billing ────────────────

def get_billing_rate():
    with get_conn() as c:
        r = c.execute("SELECT rate_per_name FROM billing_config WHERE id=1").fetchone()
    return r["rate_per_name"] if r else 0.0


def set_billing_rate(rate):
    with _lock, get_conn() as c:
        c.execute("UPDATE billing_config SET rate_per_name=? WHERE id=1", (rate,))


def get_adjust(user_id, ym):
    with get_conn() as c:
        r = c.execute(
            "SELECT adj_count, adj_amount, note FROM billing_adjust WHERE user_id=? AND ym=?",
            (user_id, ym),
        ).fetchone()
    return dict(r) if r else None


def set_adjust(user_id, ym, adj_count=None, adj_amount=None, note=""):
    """ตั้ง/ลบค่าแก้ไขจำนวนค้น & ยอดเงิน รายคนต่อเดือน (None = ใช้ค่าคำนวณจริง)"""
    now = datetime.now().isoformat(timespec="seconds")
    with _lock, get_conn() as c:
        if adj_count is None and adj_amount is None and not note:
            c.execute("DELETE FROM billing_adjust WHERE user_id=? AND ym=?", (user_id, ym))
        else:
            c.execute(
                "INSERT INTO billing_adjust(user_id,ym,adj_count,adj_amount,note,updated_at)"
                " VALUES(?,?,?,?,?,?)"
                " ON CONFLICT(user_id,ym) DO UPDATE SET"
                " adj_count=excluded.adj_count, adj_amount=excluded.adj_amount,"
                " note=excluded.note, updated_at=excluded.updated_at",
                (user_id, ym, adj_count, adj_amount, note, now),
            )


def _apply_adjust(user_id, ym, raw_count, rate):
    """คืน (count, amount, adjusted_bool, note) หลังใช้ override ถ้ามี"""
    adj = get_adjust(user_id, ym)
    count = raw_count
    amount = round(raw_count * rate, 2)
    adjusted = False
    note = ""
    if adj:
        note = adj.get("note") or ""
        if adj.get("adj_count") is not None:
            count = adj["adj_count"]
            amount = round(count * rate, 2)
            adjusted = True
        if adj.get("adj_amount") is not None:
            amount = round(adj["adj_amount"], 2)
            adjusted = True
    return count, amount, adjusted, note


def effective_rate_for_user(user_id, team_rate=None):
    """อัตราที่ใช้จริง: เฉพาะคน > เฉพาะทีม > ทั่วไป"""
    user = get_user(user_id) if user_id else None
    if user and user.get("rate_per_name") is not None:
        return user["rate_per_name"]
    if team_rate is not None:
        return team_rate
    return get_billing_rate()


def billing_daily(ym, user_id=None, rate_override=None):
    rate = rate_override if rate_override is not None else effective_rate_for_user(user_id)
    with get_conn() as c:
        if user_id:
            rows = c.execute(
                "SELECT substr(ts,1,10) d, COUNT(*) cnt"
                " FROM searches WHERE ym=? AND user_id=? GROUP BY d ORDER BY d",
                (ym, user_id),
            ).fetchall()
        else:
            rows = c.execute(
                "SELECT substr(ts,1,10) d, COUNT(*) cnt"
                " FROM searches WHERE ym=? GROUP BY d ORDER BY d", (ym,),
            ).fetchall()
    return [{"date": r["d"], "count": r["cnt"], "amount": round(r["cnt"] * rate, 2)} for r in rows]


def billing_monthly_summary(ym):
    with get_conn() as c:
        rows = c.execute(
            "SELECT user_id, COUNT(*) cnt FROM searches WHERE ym=? GROUP BY user_id",
            (ym,),
        ).fetchall()
        # รวม user ที่ถูกตั้ง override สำหรับเดือนนี้ แม้ไม่มีการค้นจริง
        adj_ids = [r["user_id"] for r in c.execute(
            "SELECT user_id FROM billing_adjust WHERE ym=?", (ym,)).fetchall()]
    raw = {r["user_id"]: r["cnt"] for r in rows}
    for uid in adj_ids:
        raw.setdefault(uid, 0)
    global_rate = get_billing_rate()
    result = []
    for user_id, cnt in sorted(raw.items(), key=lambda x: x[0] or 0):
        user = get_user(user_id) if user_id else None
        rate = effective_rate_for_user(user_id)
        count, amount, adjusted, note = _apply_adjust(user_id, ym, cnt, rate)
        result.append({
            "user_id": user_id,
            "username": user["username"] if user else "(ระบบ)",
            "display_name": user["display_name"] if user else "",
            "count": count,
            "raw_count": cnt,
            "rate": rate,
            "global_rate": global_rate,
            "amount": amount,
            "adjusted": adjusted,
            "note": note,
        })
    return result


def billing_user_monthly(ym, user_id):
    rate = effective_rate_for_user(user_id)
    daily = billing_daily(ym, user_id, rate_override=rate)
    raw_count = sum(d["count"] for d in daily)
    total_count, total_amount, adjusted, note = _apply_adjust(user_id, ym, raw_count, rate)
    return {
        "daily": daily,
        "total_count": total_count,
        "raw_count": raw_count,
        "total_amount": total_amount,
        "rate": rate,
        "adjusted": adjusted,
        "note": note,
    }


# ──────────────── teams ────────────────

def create_team(name, rate_per_name=None):
    now = datetime.now().isoformat(timespec="seconds")
    with _lock, get_conn() as c:
        c.execute("INSERT INTO teams(name, rate_per_name, created_at) VALUES(?,?,?)",
                  (name, rate_per_name, now))
        return c.execute("SELECT last_insert_rowid()").fetchone()[0]


def get_team(team_id):
    with get_conn() as c:
        row = c.execute("SELECT * FROM teams WHERE id=?", (team_id,)).fetchone()
    return dict(row) if row else None


def list_teams():
    with get_conn() as c:
        teams = c.execute("SELECT * FROM teams ORDER BY id").fetchall()
    result = []
    for t in teams:
        members = _team_members(t["id"])
        result.append({
            "id": t["id"], "name": t["name"],
            "rate_per_name": t["rate_per_name"],
            "created_at": t["created_at"], "members": members,
        })
    return result


def teams_for_user(user_id):
    """คืนรายการทีมที่ผู้ใช้คนนี้เป็นสมาชิก"""
    with get_conn() as c:
        rows = c.execute(
            "SELECT t.id FROM team_members tm"
            " JOIN teams t ON t.id=tm.team_id WHERE tm.user_id=? ORDER BY t.id",
            (user_id,),
        ).fetchall()
    return [r["id"] for r in rows]


def _team_members(team_id):
    with get_conn() as c:
        rows = c.execute(
            "SELECT u.id, u.username, u.display_name, u.rate_per_name"
            " FROM team_members tm"
            " JOIN users u ON u.id=tm.user_id WHERE tm.team_id=?", (team_id,)
        ).fetchall()
    return [dict(r) for r in rows]


def update_team(team_id, name=None, rate_per_name="__skip__"):
    sets, vals = [], []
    if name is not None:
        sets.append("name=?"); vals.append(name)
    if rate_per_name != "__skip__":
        sets.append("rate_per_name=?"); vals.append(rate_per_name)
    if not sets:
        return
    vals.append(team_id)
    with _lock, get_conn() as c:
        c.execute(f"UPDATE teams SET {','.join(sets)} WHERE id=?", vals)


def delete_team(team_id):
    with _lock, get_conn() as c:
        c.execute("DELETE FROM team_members WHERE team_id=?", (team_id,))
        c.execute("DELETE FROM teams WHERE id=?", (team_id,))


def set_team_members(team_id, user_ids):
    with _lock, get_conn() as c:
        c.execute("DELETE FROM team_members WHERE team_id=?", (team_id,))
        for uid in user_ids:
            c.execute("INSERT OR IGNORE INTO team_members(team_id, user_id) VALUES(?,?)",
                      (team_id, uid))


def team_billing(team_id, ym):
    team = get_team(team_id)
    members = _team_members(team_id)
    if not members or not team:
        return {"members": [], "daily_all": [], "total_count": 0, "total_amount": 0,
                "per_person": 0, "rate": get_billing_rate(), "team_rate": None}
    team_rate = team.get("rate_per_name")
    global_rate = get_billing_rate()
    member_data = []
    total_amount = 0
    total_count = 0
    for m in members:
        rate = effective_rate_for_user(m["id"], team_rate)
        with get_conn() as c:
            days = c.execute(
                "SELECT substr(ts,1,10) d, COUNT(*) cnt"
                " FROM searches WHERE ym=? AND user_id=? GROUP BY d ORDER BY d",
                (ym, m["id"]),
            ).fetchall()
        daily = [{"date": r["d"], "count": r["cnt"], "amount": round(r["cnt"] * rate, 2)}
                 for r in days]
        raw_cnt = sum(d["count"] for d in daily)
        cnt, amt, adjusted, note = _apply_adjust(m["id"], ym, raw_cnt, rate)
        total_count += cnt
        total_amount += amt
        member_data.append({
            "user_id": m["id"],
            "username": m["username"],
            "display_name": m["display_name"],
            "rate": rate,
            "count": cnt,
            "raw_count": raw_cnt,
            "amount": round(amt, 2),
            "adjusted": adjusted,
            "note": note,
            "daily": daily,
        })
    total_amount = round(total_amount, 2)
    n = len(members)
    per_person = round(total_amount / n, 2) if n else 0
    return {
        "members": member_data,
        "total_count": total_count,
        "total_amount": total_amount,
        "per_person": per_person,
        "member_count": n,
        "rate": global_rate,
        "team_rate": team_rate,
    }


# ──────────────── การเรียนรู้/จดจำรูปแบบไฟล์ ────────────────

def get_file_format(sig):
    """คืน mapping ที่จำไว้สำหรับลายเซ็นรูปแบบไฟล์นี้ (id_col/out_col/start_row) หรือ None"""
    if not sig:
        return None
    with get_conn() as c:
        r = c.execute("SELECT * FROM file_formats WHERE sig=?", (sig,)).fetchone()
    return dict(r) if r else None


def save_file_format(sig, id_col, out_col, start_row, headers=""):
    """บันทึก/อัปเดตรูปแบบไฟล์ที่เรียนรู้ (นับ hits เพิ่มขึ้นเมื่อเจอซ้ำ)"""
    if not sig:
        return
    now = datetime.now().isoformat(timespec="seconds")
    with _lock, get_conn() as c:
        c.execute(
            "INSERT INTO file_formats(sig,id_col,out_col,start_row,headers,hits,updated_at)"
            " VALUES(?,?,?,?,?,1,?)"
            " ON CONFLICT(sig) DO UPDATE SET"
            " id_col=excluded.id_col, out_col=excluded.out_col,"
            " start_row=excluded.start_row, headers=excluded.headers,"
            " hits=file_formats.hits+1, updated_at=excluded.updated_at",
            (sig, id_col, out_col, start_row, headers, now),
        )


def list_file_formats():
    with get_conn() as c:
        rows = c.execute("SELECT * FROM file_formats ORDER BY hits DESC, updated_at DESC").fetchall()
    return [dict(r) for r in rows]


# ──────────────── existing functions ────────────────

def log_search(account, file, row, national_id, outcome, case_count=0, detail="",
               user_id=0, incomplete=0, attempt=1):
    now = datetime.now()
    # ปิดข้อมูล: เก็บเลขบัตรแบบปิดบัง 70% + เก็บ hash (salted) ไว้นับจำนวน (ไม่เก็บเลขเต็มลงฐานข้อมูล)
    full = re.sub(r"\D", "", str(national_id or ""))
    id_hash = _hash_id(full)
    masked = mask_id(national_id)
    with _lock, get_conn() as c:
        c.execute(
            "INSERT INTO searches(ts,ym,account,file,row,national_id,outcome,case_count,detail,"
            "user_id,id_hash,incomplete,attempt) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (now.isoformat(timespec="seconds"), now.strftime("%Y-%m"),
             # detail เก็บข้อความผลเต็ม (เพดาน 2000 กันบวม) — ใช้กู้ผลลง Excel ได้โดยไม่ค้นซ้ำ
             account, file, row, masked, outcome, case_count, detail[:2000], user_id, id_hash,
             # incomplete: ธง 'ข้อมูลคดีไม่ครบ' ที่บันทึกไว้ตอนค้นครั้งแรก — ใช้ให้การกู้ผล
             # จากประวัติมาร์คสีแดงคืนได้ โดยไม่ต้อง parse ข้อความผลกลับ (ข้อหามี '/' ได้)
             1 if incomplete else 0, int(attempt or 1)),
        )


def start_run(account, files, user_id=0):
    now = datetime.now().isoformat(timespec="seconds")
    with _lock, get_conn() as c:
        cur = c.execute(
            "INSERT INTO runs(started,account,files,status,user_id) VALUES(?,?,?,?,?)",
            (now, account, files, "running", user_id),
        )
        return cur.lastrowid


def finish_run(run_id, total, found, notfound, errors, status="done"):
    now = datetime.now().isoformat(timespec="seconds")
    with _lock, get_conn() as c:
        c.execute(
            "UPDATE runs SET ended=?,total=?,found=?,notfound=?,errors=?,status=? WHERE id=?",
            (now, total, found, notfound, errors, status, run_id),
        )


def get_summary_adjust(ym):
    """คืนค่าที่ Super Admin แก้ไขจำนวนสรุปรายเดือนไว้ (หรือ None ถ้าไม่มี)"""
    with get_conn() as c:
        r = c.execute(
            "SELECT total,found,notfound,error,cases,note FROM summary_adjust WHERE ym=?",
            (ym,),
        ).fetchone()
    return dict(r) if r else None


def set_summary_adjust(ym, total=None, found=None, notfound=None, error=None, cases=None, note=""):
    """ตั้ง/ลบค่าแก้ไขจำนวนสรุปรายเดือน (ทุกช่อง None และไม่มี note = ลบ กลับไปใช้ค่าจริง)"""
    now = datetime.now().isoformat(timespec="seconds")
    with _lock, get_conn() as c:
        if all(v is None for v in (total, found, notfound, error, cases)) and not note:
            c.execute("DELETE FROM summary_adjust WHERE ym=?", (ym,))
        else:
            c.execute(
                "INSERT INTO summary_adjust(ym,total,found,notfound,error,cases,note,updated_at)"
                " VALUES(?,?,?,?,?,?,?,?)"
                " ON CONFLICT(ym) DO UPDATE SET total=excluded.total, found=excluded.found,"
                " notfound=excluded.notfound, error=excluded.error, cases=excluded.cases,"
                " note=excluded.note, updated_at=excluded.updated_at",
                (ym, total, found, notfound, error, cases, note, now),
            )


def month_totals(ym, user_id=None):
    """สรุปยอดรายเดือน — user_id=None คือภาพรวมทั้งระบบ (สำหรับแอดมิน),
    ระบุ user_id = เห็นเฉพาะยอดของตัวเอง (สำหรับสมาชิก)"""
    frag, extra = _scope(user_id, prefix="AND")
    q = ("SELECT outcome, COUNT(*) n, COALESCE(SUM(case_count),0) cc"
         " FROM searches WHERE ym=?" + frag)
    params = [ym] + extra
    with get_conn() as c:
        rows = c.execute(q + " GROUP BY outcome", params).fetchall()
    out = {"found": 0, "notfound": 0, "error": 0, "cases": 0, "total": 0}
    for r in rows:
        out[r["outcome"]] = r["n"]
        out["total"] += r["n"]
        if r["outcome"] == "found":
            out["cases"] = r["cc"]
    # ค่าที่ Super Admin แก้ไขทับเป็นตัวเลข 'ระดับทั้งระบบ' — ใช้เฉพาะมุมมองภาพรวมเท่านั้น
    # (ห้ามเอาไปทับยอดส่วนตัวของสมาชิก ไม่งั้นสมาชิกเห็นตัวเลของค์กรเป็นของตัวเอง)
    adj = get_summary_adjust(ym) if user_id is None else None
    if adj:
        out["raw"] = {k: out[k] for k in ("total", "found", "notfound", "error", "cases")}
        out["adjusted"] = True
        out["note"] = adj.get("note") or ""
        for k in ("total", "found", "notfound", "error", "cases"):
            if adj.get(k) is not None:
                out[k] = adj[k]
    return out


def _scope(user_id, prefix="WHERE"):
    """ประกอบเงื่อนไขกรองรายผู้ใช้ — คืน (sql_fragment, params)
    None = ทั้งระบบ (แอดมิน) · ตัวเลข = เฉพาะคนนั้น · ลิสต์ = หลายคน (มุมมองระดับทีม)
    ลิสต์ว่างแปลว่า "ไม่เห็นอะไรเลย" ไม่ใช่ "เห็นทั้งหมด" — กันหัวหน้าทีมที่ยังไม่มี
    สมาชิกเห็นข้อมูลทั้งระบบโดยไม่ตั้งใจ"""
    if user_id is None:
        return "", []
    if isinstance(user_id, (list, tuple, set, frozenset)):
        ids = sorted({int(u) for u in user_id})
        if not ids:
            return f" {prefix} 0=1", []
        return f" {prefix} user_id IN ({','.join('?' * len(ids))})", ids
    return f" {prefix} user_id=?", [user_id]


def month_by_account(ym, user_id=None):
    frag, extra = _scope(user_id, prefix="AND")
    with get_conn() as c:
        rows = c.execute(
            "SELECT COALESCE(account,'(ไม่ระบุ)') account,"
            " SUM(outcome='found') found, SUM(outcome='notfound') notfound,"
            " SUM(outcome='error') error, COUNT(*) total"
            " FROM searches WHERE ym=?" + frag +
            " GROUP BY account ORDER BY total DESC", [ym] + extra
        ).fetchall()
    return [dict(r) for r in rows]


def daily_series(ym, user_id=None):
    frag, extra = _scope(user_id, prefix="AND")
    with get_conn() as c:
        rows = c.execute(
            "SELECT substr(ts,1,10) d, SUM(outcome='found') found, COUNT(*) total"
            " FROM searches WHERE ym=?" + frag + " GROUP BY d ORDER BY d",
            [ym] + extra
        ).fetchall()
    return [dict(r) for r in rows]


def available_months(user_id=None):
    frag, extra = _scope(user_id)
    with get_conn() as c:
        rows = c.execute(
            "SELECT DISTINCT ym FROM searches" + frag + " ORDER BY ym DESC", extra
        ).fetchall()
    return [r["ym"] for r in rows]


def recent_searches(limit=50, user_id=None):
    frag, extra = _scope(user_id)
    with get_conn() as c:
        rows = c.execute(
            "SELECT ts,account,file,row,national_id,outcome,case_count,detail"
            " FROM searches" + frag + " ORDER BY id DESC LIMIT ?",
            extra + [limit]
        ).fetchall()
    return [dict(r) for r in rows]


def recent_runs(limit=20, user_id=None):
    frag, extra = _scope(user_id)
    with get_conn() as c:
        rows = c.execute(
            "SELECT * FROM runs" + frag + " ORDER BY id DESC LIMIT ?",
            extra + [limit]
        ).fetchall()
    return [dict(r) for r in rows]


def overall_stats(user_id=None):
    frag, extra = _scope(user_id)
    with get_conn() as c:
        r = c.execute(
            "SELECT COUNT(*) total, SUM(outcome='found') found,"
            " SUM(outcome='notfound') notfound, SUM(outcome='error') error"
            " FROM searches" + frag, extra
        ).fetchone()
    return dict(r) if r else {}


def count_searched_ids(file_pattern):
    # นับจำนวนรายชื่อไม่ซ้ำจาก hash (คงถูกต้องแม้เลขบัตรถูกปิดบัง), สำรองด้วย national_id
    with get_conn() as c:
        r = c.execute(
            "SELECT COUNT(DISTINCT COALESCE(NULLIF(id_hash,''), national_id)) n"
            " FROM searches WHERE file LIKE ?",
            (f"%{file_pattern}%",),
        ).fetchone()
    return r["n"] if r else 0


# อายุสูงสุดของผลเดิมที่ยอมให้กู้มาใช้แทนการค้นใหม่ (ชั่วโมง)
# เจตนาของฟีเจอร์คือ "กู้งานของรอบที่เพิ่งค้างไว้" (เครื่องดับ/แบตหมด/เน็ตหลุด) เท่านั้น
# ไม่ใช่แคชผลถาวร — ข้อมูลคดีเปลี่ยนแปลงได้ คนที่วันนี้ 'ไม่พบคดี' เดือนหน้าอาจมีคดี
RESTORE_MAX_AGE_HOURS = 24


def find_prev_result(file, national_id, row=None, user_id=None,
                     max_age_hours=RESTORE_MAX_AGE_HOURS):
    """หาผลการค้นเดิม (found/notfound) ของเลขบัตรนี้ในไฟล์เดียวกัน "ของรอบที่เพิ่งค้างไว้"

    ใช้ตอนกลับมาค้นต่อ: แถวที่เคยค้นสำเร็จแล้วแต่ผลยังไม่ทันถูกบันทึกลง Excel
    (เครื่องดับ/แบตหมด/ไฟล์หาย) จะถูกเติมผลจากฐานข้อมูลแทนการค้นซ้ำ = ไม่เสียโควตา
    จับคู่ด้วย id_hash (salted) จึงทำงานได้แม้เลขบัตรในฐานข้อมูลถูกปิดบังไว้

    ขอบเขตที่จำกัดไว้ (สำคัญ — กันการกู้ผลผิดคน/ผิดไฟล์/ผลเก่าเกินไป):
      user_id       จำกัดเฉพาะผลที่ "ผู้ใช้คนเดียวกัน" เคยค้นเอง
                    (ชื่อไฟล์ซ้ำกันข้ามผู้ใช้เป็นเรื่องปกติ เช่น 'รายชื่อ.xlsx')
      max_age_hours จำกัดอายุผลเดิม — รอบที่ค้างไว้ย่อมถูกสานต่อภายในเวลาไม่นาน
                    ผลที่เก่ากว่านี้ให้ค้นใหม่เสมอ เพราะข้อมูลคดีอาจเปลี่ยนไปแล้ว

    คืน {'outcome','case_count','detail','row'} หรือ None ถ้าไม่เข้าเงื่อนไข"""
    full = re.sub(r"\D", "", str(national_id or ""))
    if not full:
        return None
    h = _hash_id(full)
    q = ("SELECT outcome, case_count, detail, row,"
         " COALESCE(incomplete,0) AS incomplete FROM searches"
         " WHERE file=? AND id_hash=? AND outcome IN ('found','notfound')")
    params = [file, h]
    if max_age_hours is not None:
        cutoff = (datetime.now() - timedelta(hours=max_age_hours)).isoformat(timespec="seconds")
        q += " AND ts >= ?"
        params.append(cutoff)
    if user_id is not None:
        q += " AND user_id=?"
        params.append(user_id)
    q += " ORDER BY id DESC LIMIT 10"
    with get_conn() as c:
        rows = c.execute(q, params).fetchall()
    if not rows:
        return None
    for r in rows:   # ผลของแถวเดิมก่อน (เผื่อเลขเดียวกันอยู่หลายแถวในไฟล์)
        if row is None or r["row"] == row:
            return dict(r)
    return dict(rows[0])   # เลขเดียวกันในไฟล์เดียวกัน — ผลการค้นย่อมเหมือนกัน
