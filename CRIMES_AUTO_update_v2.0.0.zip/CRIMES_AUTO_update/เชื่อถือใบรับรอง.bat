@echo off
chcp 65001 >nul
title CRIMES AUTO - Trust Certificate
cd /d "%~dp0"
echo.
echo ============================================
echo   Install CRIMES AUTO certificate (optional)
echo   Run as Administrator (right-click - Run as administrator)
echo ============================================
echo.
if not exist "%~dp0CRIMES-AUTO-cert.cer" (
  echo [i] CRIMES-AUTO-cert.cer not found - and that is usually FINE.
  echo.
  echo     This certificate file only exists INSIDE a built offline package
  echo     ^(created by build.ps1 / build-update.ps1^). The GitHub source does
  echo     not contain it.
  echo.
  echo     You do NOT need this step if you installed with:
  echo        - ติดตั้งลงเครื่อง.bat   ^(direct install to C:\Crimes-Automate^)
  echo     Nothing is code-signed in that case, and the program runs normally.
  echo.
  echo     This step is ONLY for machines that received the signed offline zip
  echo     and want the installer signature to show as "Valid" ^(cosmetic^).
  echo.
  pause
  exit /b 0
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Import-Certificate -FilePath '%~dp0CRIMES-AUTO-cert.cer' -CertStoreLocation Cert:\LocalMachine\TrustedPublisher -ErrorAction Stop | Out-Null; Import-Certificate -FilePath '%~dp0CRIMES-AUTO-cert.cer' -CertStoreLocation Cert:\LocalMachine\Root -ErrorAction Stop | Out-Null; Write-Host '[OK] Certificate installed' -ForegroundColor Green } catch { Write-Host ('[X] Failed: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }"
echo.
pause
