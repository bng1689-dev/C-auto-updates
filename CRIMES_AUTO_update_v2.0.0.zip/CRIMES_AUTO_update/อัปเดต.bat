@echo off
chcp 65001 >nul
set "VER="
if exist "%~dp0app\VERSION" set /p VER=<"%~dp0app\VERSION"
if defined VER (title CRIMES AUTO - Update v%VER%) else (title CRIMES AUTO - Update)
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update.ps1"
if errorlevel 1 (
  echo.
  echo [X] Update failed - see messages above
  pause
)
