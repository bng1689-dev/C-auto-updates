"""Auth module — multi-user with roles, system config in config.json."""
import json
import secrets

import db  # user auth now lives in SQLite
from config import CONFIG_PATH  # ไฟล์ตั้งค่าระบบ (กำหนดที่ backend/config.py)


def _default_config():
    return {
        "secret_key": secrets.token_hex(32),
        "account": "",
        "display_name": "",
        "bind_host": "127.0.0.1",
        "port": 8770,
        "search_speed": 2,   # ระดับความเร็วการค้น 1(ช้าสุด)–5(เร็วสุด)
        # URL ตรวจสอบเวอร์ชันล่าสุด (ไฟล์ manifest .json) — ตั้งค่าเริ่มต้นไว้ให้เลย
        # ใช้ repo สาธารณะแยกสำหรับปล่อยอัปเดต (repo ซอร์สหลักเป็น private เลยดึง raw ไม่ได้)
        # ให้ตรงกับที่ manifest ชี้ไฟล์ .zip ไว้ (bng1689-dev/C-auto-updates)
        "update_url": "https://raw.githubusercontent.com/bng1689-dev/C-auto-updates/main/update-manifest.json",
    }


def load_config():
    existed = CONFIG_PATH.exists()
    if existed:
        try:
            cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            cfg, existed = _default_config(), False
    else:
        cfg = _default_config()
    base = _default_config()
    changed = False
    for k, v in base.items():
        if k not in cfg:
            cfg[k] = v
            changed = True
    # persist ทันทีเมื่อสร้างไฟล์ครั้งแรก/เติมคีย์ที่ขาด — สำคัญมากกับ secret_key
    # ซึ่งใช้เป็นทั้ง Flask session key และ salt แฮชเลขบัตร (db._id_salt): ต้องคงที่
    # ข้ามการรีสตาร์ท ไม่งั้น session หลุดทุกครั้งที่เปิดใหม่ และ hash เลขบัตรไม่ตรงกัน
    if not existed or changed:
        try:
            save_config(cfg)
        except Exception:
            pass
    return cfg


def save_config(cfg):
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def is_configured():
    return db.has_any_user()


def get_secret_key():
    return load_config()["secret_key"]
