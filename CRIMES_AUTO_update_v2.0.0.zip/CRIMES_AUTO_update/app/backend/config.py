"""ศูนย์รวมการตั้งค่า path ของ backend — ผูกกับฐานข้อมูล SQLite ที่จัดเก็บเอง

ทุกโมดูลฝั่ง backend (server, db, auth, engine, worker) อ้างอิง path จากที่นี่ที่เดียว
ทำให้ backend เป็นเจ้าของชั้นข้อมูล (data/) อย่างชัดเจน และย้าย/ตั้งค่าตำแหน่งเก็บข้อมูลได้จากจุดเดียว
"""
import os
from pathlib import Path

# โครงสร้างโฟลเดอร์
BASE_DIR = Path(__file__).resolve().parent          # .../backend
PROJECT_DIR = BASE_DIR.parent                        # .../app
FRONTEND_DIR = PROJECT_DIR / "frontend"
TEMPLATE_DIR = FRONTEND_DIR / "templates"
STATIC_DIR = FRONTEND_DIR / "static"

# เบราว์เซอร์ Chromium ที่แถมมาในแพ็กเกจ (ทำงานออฟไลน์ 100% — ไม่ต้องดาวน์โหลด)
# วางไว้ที่ <รากติดตั้ง>/browsers  (ระดับเดียวกับ app/ และ runtime/)
# ตั้ง PLAYWRIGHT_BROWSERS_PATH ให้ Playwright ใช้เบราว์เซอร์ในแพ็กเกจก่อนถูกเรียกใช้จริง
BUNDLED_BROWSERS_DIR = PROJECT_DIR.parent / "browsers"
if BUNDLED_BROWSERS_DIR.exists() and not os.environ.get("PLAYWRIGHT_BROWSERS_PATH"):
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(BUNDLED_BROWSERS_DIR)

# เวอร์ชันโปรแกรม (อ่านจากไฟล์ app/VERSION) — ใช้แสดงผลและตรวจสอบอัปเดต
try:
    APP_VERSION = (PROJECT_DIR / "VERSION").read_text(encoding="utf-8").strip() or "0.0.0"
except Exception:
    APP_VERSION = "0.0.0"

# ชั้นเก็บข้อมูลที่ backend จัดเก็บเอง (override ได้ด้วย env CRIMES_DATA_DIR)
DATA_DIR = Path(os.environ.get("CRIMES_DATA_DIR", BASE_DIR / "data")).resolve()
UPLOAD_DIR = Path(os.environ.get("CRIMES_UPLOAD_DIR", BASE_DIR / "uploads")).resolve()

# ฐานข้อมูล SQLite + ไฟล์ตั้งค่า/คิว (override path ฐานข้อมูลได้ด้วย env CRIMES_DB_PATH)
DB_PATH = Path(os.environ.get("CRIMES_DB_PATH", DATA_DIR / "data.db")).resolve()
CONFIG_PATH = DATA_DIR / "config.json"
QUEUE_PATH = DATA_DIR / "queue.json"

# สร้างโฟลเดอร์ข้อมูลให้พร้อมใช้เสมอ
DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
