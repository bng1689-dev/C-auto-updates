"""CRIMES Auto — backend package (API + data layer + automation engine)."""
