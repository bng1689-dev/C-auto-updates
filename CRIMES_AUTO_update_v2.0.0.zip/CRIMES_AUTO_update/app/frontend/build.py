"""ประกอบ frontend/index.html จากไฟล์ต้นทาง (pure assembler — ไม่มี HTML/JS ฝังในสคริปต์)

รันหลังแก้ไฟล์ต้นทาง:  python frontend/build.py
ชิ้นส่วน: templates/_head.html + static/style.css + templates/_auth.html +
         templates/app.html (เฉพาะเนื้อ <body>..<script) + static/app.js + static/_glue.js
หมายเหตุ: templates/app.html และ static/app.js เป็น "ไฟล์ต้นทางของ build" (ไม่ได้เสิร์ฟตรง ๆ)
"""
from pathlib import Path
FE = Path(__file__).resolve().parent
head = (FE / "templates" / "_head.html").read_text(encoding="utf-8")
css  = (FE / "static" / "style.css").read_text(encoding="utf-8")
auth = (FE / "templates" / "_auth.html").read_text(encoding="utf-8")
glue = (FE / "static" / "_glue.js").read_text(encoding="utf-8")
appjs   = (FE / "static" / "app.js").read_text(encoding="utf-8")
apphtml = (FE / "templates" / "app.html").read_text(encoding="utf-8")
body = apphtml.split("<body>", 1)[1].split("<script", 1)[0]
html = (
    '<!DOCTYPE html>\n<html lang="th">\n<head>\n'
    + head
    + "<style>\n" + css + "\n</style>\n</head>\n<body>\n"
    + auth
    + '<div id="screen-app" class="hidden">\n' + body + "\n</div>\n"
    + "<script>\n" + appjs + "\n" + glue + "\n</script>\n</body>\n</html>\n"
)
out = FE / "index.html"
out.write_text(html, encoding="utf-8")
print(f"สร้างไฟล์เดียวสำเร็จ: {out}  ({len(html):,} ตัวอักษร)")
