/* ===== auth screen control (single-page) ===== */
function showAuth(mode){
  document.getElementById('screen-app').classList.add('hidden');
  document.getElementById('screen-auth').classList.remove('hidden');
  var login = mode!=='setup';
  document.getElementById('authLoginBox').classList.toggle('hidden', !login);
  document.getElementById('authSetupBox').classList.toggle('hidden', login);
}
function showApp(){
  document.getElementById('screen-auth').classList.add('hidden');
  document.getElementById('screen-app').classList.remove('hidden');
  bootApp();
}
function _setErr(id,msg){ var e=document.getElementById(id); if(!e) return; e.textContent=msg||''; e.style.display=msg?'block':'none'; }
async function checkAuth(){
  try{ var r=await fetch('/api/me'); if(r.ok){ showApp(); return; } }catch(e){}
  var st={configured:true};
  try{ st=await (await fetch('/api/auth/state')).json(); }catch(e){}
  showAuth(st.configured ? 'login' : 'setup');
}
document.getElementById('authLoginForm').addEventListener('submit', async function(e){
  e.preventDefault(); _setErr('authLoginErr','');
  var body={username:document.getElementById('authLoginUser').value.trim(), password:document.getElementById('authLoginPw').value, remember:document.getElementById('authRemember').checked};
  var r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  var d={}; try{ d=await r.json(); }catch(e){}
  if(r.ok && d.ok){ document.getElementById('authLoginPw').value=''; showApp(); }
  else { _setErr('authLoginErr', d.error||'เข้าสู่ระบบไม่สำเร็จ'); }
});
document.getElementById('authSetupForm').addEventListener('submit', async function(e){
  e.preventDefault(); _setErr('authSetupErr','');
  var body={username:document.getElementById('suUser').value.trim(), display_name:document.getElementById('suName').value.trim(), password:document.getElementById('suPw').value, password2:document.getElementById('suPw2').value};
  var r=await fetch('/api/setup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  var d={}; try{ d=await r.json(); }catch(e){}
  if(r.ok && d.ok){ showApp(); }
  else { _setErr('authSetupErr', d.error||'สร้างบัญชีไม่สำเร็จ'); }
});
(function(){ var lo=document.getElementById('btnLogout');
  if(lo) lo.addEventListener('click', async function(e){ e.preventDefault(); try{ await fetch('/api/logout',{method:'POST'}); }catch(e){} location.reload(); });
})();
/* ปุ่มดู/ซ่อนรหัสผ่าน (ทุกช่องที่มี .pw-eye) */
document.querySelectorAll('.pw-eye').forEach(function(btn){
  btn.addEventListener('click', function(){
    var t = document.getElementById(btn.dataset.target);
    if(!t) return;
    if(t.type === 'password'){ t.type = 'text'; btn.textContent = '🙈'; btn.title = 'ซ่อนรหัสผ่าน'; }
    else { t.type = 'password'; btn.textContent = '👁'; btn.title = 'ดูรหัสผ่าน'; }
  });
});
checkAuth();
