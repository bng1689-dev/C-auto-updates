"use strict";
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const api = async (url, opt) => {
  const r = await fetch(url, opt);
  if (r.status === 401) { showAuth('login'); return null; }
  return r.json().catch(() => ({}));
};
const esc = s => (s ?? "").toString().replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
function maskName(s){
  if(!s) return "";
  const t = s.trim();
  if(t.length<=2) return t[0]+"*";
  const show = Math.ceil(t.length*0.4);
  return t.slice(0,show) + "*".repeat(t.length-show);
}
const fmtMonth = m=>{ const [y,mo]=m.split("-"); const n=["ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค."]; return n[+mo-1]+" "+(+y+543); };
const fmtNum = n => Number(n||0).toLocaleString("th-TH");
const fmtBaht = n => Number(n||0).toLocaleString("th-TH",{minimumFractionDigits:2,maximumFractionDigits:2});

/* ---------- current user state ---------- */
let ME = {id:0, username:"", display_name:"", role:"member"};

async function loadMe(){
  const m = await api("/api/me");
  if(!m || m.error) return;
  ME = m;
  if(ME.display_name) $("#sideAccount").textContent = "👤 "+ME.display_name;
  else $("#sideAccount").textContent = "👤 "+ME.username;
  const roleLabels = {super_admin:"Super Admin", member:"Member"};
  $("#sideRole").textContent = roleLabels[ME.role]||ME.role;
  if(ME.version && $("#sideVersion")) $("#sideVersion").textContent = "v"+ME.version;
  const isAdmin = ME.role === "super_admin";
  $$(".nav-admin").forEach(b=>b.classList.toggle("hidden", !isAdmin));
  $$(".admin-only").forEach(b=>b.classList.toggle("hidden", !isAdmin));
}

/* ---------- navigation ---------- */
$$(".nav-item").forEach(b => b.onclick = () => {
  $$(".nav-item").forEach(x => x.classList.remove("active"));
  b.classList.add("active");
  const v = b.dataset.view;
  $$(".view").forEach(s => s.classList.add("hidden"));
  $("#view-" + v).classList.remove("hidden");
  if (v === "dashboard") loadDashboard();
  if (v === "run") loadQueue();
  if (v === "history") loadHistory();
  if (v === "settings") loadSettings();
  if (v === "members") loadMembers();
  if (v === "billing") loadBilling();
  if (v === "audit") loadAudit();
});

/* ---------- dashboard + reports ---------- */
async function loadDashboard(){
  $("#todayStr").textContent = new Date().toLocaleDateString("th-TH",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
  const s = await api("/api/summary");
  if(!s) return;
  drawBars($("#chartDaily"), (s.daily||[]).map(d=>({x:d.d.slice(8),y:d.total})));
  const rec = await api("/api/recent");
  renderActivity(rec ? rec.searches : []);
  loadReports();
  loadMyBilling();
}

/* ---------- my billing (dashboard) ---------- */
async function loadMyBilling(ym){
  const card = $("#myBillingCard");
  const d = await api("/api/my/billing"+(ym?("?ym="+ym):""));
  if(!d){ card.classList.add("hidden"); return; }
  card.classList.remove("hidden");
  const monthLabel = d.ym ? fmtMonth(d.ym) : "—";
  const mine = d.mine || {total_count:0,total_amount:0,rate:0,daily:[]};
  let html = `<div class="tiles" style="grid-template-columns:repeat(3,1fr);margin-bottom:14px">
    <div class="tile"><div class="tile-ic blue">Σ</div><div><div class="tile-n">${fmtNum(mine.total_count)}</div><div class="tile-l">ค้นของฉัน (${monthLabel})</div></div></div>
    <div class="tile"><div class="tile-ic amber">฿</div><div><div class="tile-n">${fmtBaht(mine.total_amount)}</div><div class="tile-l">ยอดของฉัน (บาท)</div></div></div>
    <div class="tile"><div class="tile-ic green">⊘</div><div><div class="tile-n">${mine.rate}</div><div class="tile-l">อัตรา/ชื่อ (บาท)</div></div></div>
  </div>`;

  // my daily breakdown (collapsible)
  if(mine.daily && mine.daily.length){
    html += `<details><summary style="cursor:pointer;font-size:13px;color:var(--acc);margin-bottom:8px">📅 ดูรายวันของฉัน</summary>
      <div class="tablewrap"><table><thead><tr><th>วันที่</th><th class="num">จำนวนค้น</th><th class="num">ยอด (฿)</th></tr></thead><tbody>`+
      mine.daily.map(r=>`<tr><td>${r.date}</td><td class="num">${fmtNum(r.count)}</td><td class="num">${fmtBaht(r.amount)}</td></tr>`).join("")+
      `</tbody></table></div></details>`;
  } else {
    html += `<div class="qempty">ยังไม่มีการค้นในเดือนนี้</div>`;
  }

  // my teams
  if(d.teams && d.teams.length){
    html += `<div class="card-h" style="margin-top:18px">ทีมของฉัน (หารเท่ากัน)</div>`;
    for(const t of d.teams){
      html += `<div class="team-card">
        <div class="team-header">
          <div><div class="team-name">${esc(t.name)}</div>
          <div class="team-members-text">${t.member_count} คนในทีม</div></div>
        </div>
        <div class="team-billing">
          <div class="team-stat"><span class="muted">ค้นรวมทีม</span><b>${fmtNum(t.total_count)}</b></div>
          <div class="team-stat"><span class="muted">ยอดรวมทีม</span><b>${fmtBaht(t.total_amount)} ฿</b></div>
          <div class="team-stat"><span class="muted">÷ ${t.member_count} คน</span></div>
          <div class="team-stat team-per-person"><span class="muted">ที่ฉันต้องจ่าย</span><b>${fmtBaht(t.per_person)} ฿</b></div>
        </div>
        <div class="team-detail-table"><table><tbody>
          <tr><td>ยอดค้นของฉันในทีมนี้</td><td class="num">${fmtNum(t.my_count)} ชื่อ</td><td class="num">${fmtBaht(t.my_amount)} ฿ <span class="muted">(ยอดจริง)</span></td></tr>
        </tbody></table></div>
      </div>`;
    }
  }
  $("#myBilling").innerHTML = html;
}
function renderActivity(rows){
  const el = $("#activity");
  if(!rows || !rows.length){ el.innerHTML = '<div class="qempty">ยังไม่มีกิจกรรม</div>'; return; }
  el.innerHTML = rows.slice(0,18).map(r=>{
    const b = r.outcome==="found"?'<span class="badge b-found">พบ '+r.case_count+' คดี</span>'
      : r.outcome==="error"?'<span class="badge b-err">ผิดพลาด</span>'
      : '<span class="badge b-none">ไม่พบ</span>';
    return `<div class="act-row">${b}<span style="flex:1">${esc(r.national_id)}</span><span class="muted">${esc(r.ts.slice(5,16).replace("T"," "))}</span></div>`;
  }).join("");
}

/* ---------- reports (inside dashboard) ---------- */
async function loadReports(ym){
  const s = await api("/api/summary"+(ym?("?ym="+ym):""));
  if(!s) return;
  const sel = $("#monthSel");
  if(!ym){
    sel.innerHTML = (s.months||[]).map(m=>`<option value="${m}">${fmtMonth(m)}</option>`).join("") || `<option>—</option>`;
    sel.onchange = ()=>{ loadReports(sel.value); loadMyBilling(sel.value); };
  }
  const t = s.totals||{};
  curSummary = { ym: s.ym||"", totals: t, adjust: s.adjust||null };
  if($("#btnEditSummary")) $("#btnEditSummary").classList.toggle("hidden", !s.can_adjust);
  if($("#adjBadge")) $("#adjBadge").classList.toggle("hidden", !t.adjusted);
  $("#rTotal").textContent=t.total||0;
  $("#rFound").textContent=t.found||0;
  $("#rCases").textContent=t.cases||0;
  $("#rNone").textContent=t.notfound||0;
  drawDonut($("#chartType"), [
    {label:"พบคดี",value:t.found||0,color:"#22c55e"},
    {label:"ไม่พบคดี",value:t.notfound||0,color:"#64748b"},
    {label:"ผิดพลาด",value:t.error||0,color:"#ef4444"},
  ]);
  const acc = s.by_account||[];
  $("#acctTable").innerHTML = acc.length ? `<table><thead><tr><th>บัญชี CRIMES</th><th class="num">พบ</th><th class="num">ไม่พบ</th><th class="num">ผิดพลาด</th><th class="num">รวม</th></tr></thead><tbody>`+
    acc.map(a=>`<tr><td>${esc(maskName(a.account))}</td><td class="num">${a.found}</td><td class="num">${a.notfound}</td><td class="num">${a.error}</td><td class="num">${a.total}</td></tr>`).join("")+`</tbody></table>`
    : '<div class="qempty">ไม่มีข้อมูลเดือนนี้</div>';
}

/* ---------- แก้ไขจำนวนบนแดชบอร์ด (Super Admin + รหัสยืนยัน) ---------- */
let curSummary = { ym:"", totals:{}, adjust:null };
$("#btnEditSummary").onclick = ()=>{
  const t = curSummary.totals||{};
  const raw = t.raw || t;   // ค่าจริงจากระบบ
  $("#summaryAdjRaw").innerHTML = `เดือน <b>${esc(curSummary.ym||"—")}</b> · ค่าจริง: ค้น <b>${fmtNum(raw.total||0)}</b> · พบ <b>${fmtNum(raw.found||0)}</b> · คดี <b>${fmtNum(raw.cases||0)}</b> · ไม่พบ <b>${fmtNum(raw.notfound||0)}</b> · ผิดพลาด <b>${fmtNum(raw.error||0)}</b>`;
  const a = curSummary.adjust||{};
  const v = x => (x===null||x===undefined) ? "" : x;
  $("#adjTotal").value=v(a.total); $("#adjFound").value=v(a.found); $("#adjCases").value=v(a.cases);
  $("#adjNotfound").value=v(a.notfound); $("#adjError").value=v(a.error);
  $("#adjSumNote").value=a.note||""; $("#adjSumCode").value=""; $("#adjSumMsg").textContent="";
  $("#summaryAdjModal").classList.remove("hidden");
};
$("#btnAdjSumCancel").onclick = ()=>$("#summaryAdjModal").classList.add("hidden");
async function saveSummaryAdjust(reset){
  const code = $("#adjSumCode").value;
  if(!code){ $("#adjSumMsg").textContent="กรุณาใส่รหัสยืนยัน"; return; }
  const num = id => { const x=$(id).value.trim(); return x===""?null:(+x); };
  const body = reset
    ? {ym:curSummary.ym, total:null,found:null,notfound:null,error:null,cases:null,note:"",code}
    : {ym:curSummary.ym, total:num("#adjTotal"),found:num("#adjFound"),notfound:num("#adjNotfound"),
       error:num("#adjError"),cases:num("#adjCases"),note:$("#adjSumNote").value.trim(),code};
  const r = await api("/api/admin/summary/adjust",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  if(r && r.error){ $("#adjSumMsg").textContent="✕ "+r.error; return; }
  $("#summaryAdjModal").classList.add("hidden");
  loadReports($("#monthSel").value||undefined);
}
$("#btnAdjSumSave").onclick = ()=>saveSummaryAdjust(false);
$("#btnAdjSumReset").onclick = ()=>saveSummaryAdjust(true);

/* ---------- upload — ตรวจจับคอลัมน์เลขบัตรอัตโนมัติ (ไม่มีขั้นตอนบังคับ) ---------- */

/* ---------- queue + upload ---------- */
async function loadQueue(){
  const q = await api("/api/queue");
  const el = $("#queueList");
  if(!q || !q.length){
    el.innerHTML='<div class="qempty">ยังไม่มีไฟล์ในคิว — ทำตามขั้นตอนทางซ้าย</div>';
    $("#btnStart").disabled = true;
    return;
  }
  // มีไฟล์ในคิว — เปิดปุ่มได้ ยกเว้นเพิ่งกดเริ่มไปแล้ว (ค้างสีเทาจนกว่าจะเริ่มงานชิ้นใหม่)
  $("#btnStart").disabled = runStarted;
  renderQueue(q);
}
function renderQueue(q){
  const el = $("#queueList");
  el.innerHTML = q.map((j,i)=>{
    const name = j.path.split("/").pop();
    const meta = `${j.id_col||"B"}→${j.out_col||"F"}${j.no_year?" · ไม่ใส่ปี":""}${j.start_row?` · แถว ${j.start_row}${j.end_row?"-"+j.end_row:"+"}`:""}`;
    const cls = j.done ? "qdl-btn qdl-green" : "qdl-btn qdl-red";
    const label = j.done ? `⬇ Download (${j.searched}ชื่อ)` : `⬇ Download`;
    return `<div class="qitem"><span class="qname">${esc(name)}<div class="qmeta">${esc(meta)}</div></span><a class="${cls}" href="/api/download?path=${encodeURIComponent(j.path)}">${label}</a><span class="qx" data-i="${i+1}">✕</span></div>`;
  }).join("");
  el.querySelectorAll(".qx").forEach(x=>x.onclick=async()=>{
    await api("/api/queue/remove",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({index:+x.dataset.i})});
    loadQueue();
  });
}
function uploadFile(file){
  if(!file.name.toLowerCase().endsWith(".xlsx")){ $("#uploadMsg").textContent="ต้องเป็นไฟล์ .xlsx"; return; }
  const fd = new FormData();
  fd.append("file", file);
  const idOverride = ($("#cfgId").value||"").trim();
  const outOverride = ($("#cfgOut").value||"").trim();
  if(idOverride) fd.append("id_col", idOverride);      // เว้นว่าง = ตรวจอัตโนมัติที่ฝั่งเซิร์ฟเวอร์
  if(outOverride) fd.append("out_col", outOverride);
  fd.append("no_year", $("#cfgNoYear").checked?"true":"false");
  if($("#cfgStart").value) fd.append("start_row",$("#cfgStart").value);
  if($("#cfgEnd").value) fd.append("end_row",$("#cfgEnd").value);
  $("#uploadMsg").textContent = "กำลังอัปโหลดและตรวจหาคอลัมน์เลขบัตร...";
  fetch("/api/upload",{method:"POST",body:fd}).then(r=>r.json()).then(d=>{
    if(d.error){ $("#uploadMsg").textContent = "✕ "+d.error; }
    else {
      const j = d.job || {};
      let msg = `✓ เพิ่มแล้ว (${d.rows??"?"} แถว)`;
      if(d.source==="learned"){
        msg += ` · 🧠 จำรูปแบบไฟล์นี้ได้ → เลขบัตรคอลัมน์ ${j.id_col} · เขียนผล ${j.out_col}`;
      } else if(d.source==="detected"){
        const det = d.detected||{};
        msg += ` · ตรวจพบเลขบัตรคอลัมน์ ${j.id_col} (เลข 13 หลัก ${det.id_count??"?"} รายการ) → เขียนผล ${j.out_col} · จดจำรูปแบบไว้แล้ว`;
      } else {
        msg += ` · เลขบัตรคอลัมน์ ${j.id_col} → เขียนผล ${j.out_col}`;
      }
      $("#uploadMsg").textContent = msg;
      runStarted = false;   // เพิ่มไฟล์ใหม่ = เริ่มงานชิ้นใหม่ได้ → เปิดปุ่มเริ่มค้นหา
      $("#btnStart").disabled = false;
      loadQueue();
    }
  }).catch(()=>$("#uploadMsg").textContent="อัปโหลดล้มเหลว");
}
const dz = $("#dropzone");
dz.onclick = ()=> $("#fileInput").click();
$("#fileInput").onchange = e=>{ if(e.target.files[0]) uploadFile(e.target.files[0]); };
["dragover","dragenter"].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault(); dz.classList.add("drag");}));
["dragleave","drop"].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove("drag");}));
dz.addEventListener("drop",e=>{ if(e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0]); });
$("#btnClearQ").onclick = async()=>{ if(confirm("ล้างคิวทั้งหมด?")){ await api("/api/queue/clear",{method:"POST"}); loadQueue(); } };
$("#btnReset").onclick = async()=>{
  if($("#btnReset").disabled) return;   // กันกดซ้ำระหว่างกำลังทำงาน
  if(!confirm("เริ่มรอบใหม่: ล้างคิวและไฟล์ที่อัปโหลดค้างไว้ เพื่อให้พร้อมรับไฟล์ใหม่\n\n(ประวัติการค้นทั้งหมดยังถูกเก็บไว้เหมือนเดิม ไม่ถูกลบ)")) return;
  $("#btnReset").disabled = true;
  try {
    const r = await api("/api/run/reset",{method:"POST"});
    if(r && r.error){ alert("✕ "+r.error); return; }
    $("#uploadMsg").textContent = `✓ พร้อมรับไฟล์ใหม่แล้ว (ลบไฟล์ค้าง ${r.uploads_removed||0} ไฟล์ · ประวัติยังอยู่ครบ)`;
    const sa = $("#saveAlert"); if(sa){ sa.classList.add("hidden"); }
    runStarted = false;   // เริ่มรอบใหม่ = พร้อมเริ่มงานชิ้นใหม่ → เปิดปุ่มเริ่มค้นหา
  } finally {
    $("#btnReset").disabled = false;
    loadQueue();
  }
};
let runStarted = false;   // กดเริ่มค้นหาไปแล้ว → ปุ่มเทา/กดไม่ได้ จนกว่าจะเริ่มงานชิ้นใหม่
$("#btnStart").onclick = async()=>{
  if($("#btnStart").disabled) return;
  $("#btnStart").disabled = true;   // ปิดปุ่มทันทีที่กด (กันกดซ้ำ + ขึ้นสีเทา)
  const r = await api("/api/run/start",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({account:$("#acctInput").value, step_mode:$("#cfgStepMode").checked})});
  if(r && r.error){
    alert(r.error);
    $("#btnStart").disabled = false;   // เริ่มไม่สำเร็จ → เปิดปุ่มคืน
    return;
  }
  runStarted = true;   // เริ่มงานแล้ว — ค้างสีเทาจนกว่าจะเพิ่มไฟล์ใหม่/เริ่มรอบใหม่
};

/* ---------- run control ---------- */
$("#btnConfirmLogin").onclick = ()=>api("/api/run/confirm-login",{method:"POST"});
$("#btnStop").onclick = ()=>{ if(confirm("หยุดการทำงาน?")) api("/api/run/stop",{method:"POST"}); };
$("#btnNextStep").onclick = ()=>api("/api/run/step",{method:"POST"});
$("#btnAutoMode").onclick = ()=>api("/api/run/auto",{method:"POST"});
$("#btnCloseBrowser").onclick = ()=>api("/api/run/close-browser",{method:"POST"});

let lastState = "idle";
let realtimeTick = 0;
async function poll(){
  const s = await api("/api/status");
  if(s){
    updateBanner(s);
    updateSaveAlert(s);
    if(["done","stopped","error"].includes(s.state) && lastState==="running"){
      loadDashboard();
      refreshQueueButtons();
      if(ME.role==="super_admin" && !$("#view-billing").classList.contains("hidden"))
        loadBilling($("#billMonthSel").value||undefined);
    }
    // เรียลไทม์: ระหว่างกำลังค้น ให้ยอดการเงิน/แดชบอร์ดที่เปิดอยู่อัปเดตเป็นช่วงๆ
    if(s.state==="running"){
      realtimeTick++;
      if(realtimeTick % 5 === 0){  // ~ทุก 6 วิ
        if(!$("#view-dashboard").classList.contains("hidden")) loadMyBilling($("#monthSel").value||undefined);
        if(ME.role==="super_admin" && !$("#view-billing").classList.contains("hidden"))
          loadBilling($("#billMonthSel").value||undefined);
      }
    }
    lastState = s.state;
  }
  setTimeout(poll, 1200);
}
function updateSaveAlert(s){
  const el = $("#saveAlert");
  if(!el) return;
  if(s.save_error){
    el.style.cssText = "background:rgba(239,68,68,.14);color:#fca5a5;padding:12px 15px;border-radius:10px;margin-bottom:16px;border:1px solid rgba(239,68,68,.45);font-size:13px;line-height:1.7";
    el.innerHTML = "⛔ <b>บันทึกผลลงไฟล์ไม่สำเร็จ</b><br>"+esc(s.save_error);
    el.classList.remove("hidden");
  } else if(s.save_warning){
    el.style.cssText = "background:rgba(245,158,11,.12);color:#fcd9a3;padding:12px 15px;border-radius:10px;margin-bottom:16px;border:1px solid rgba(245,158,11,.4);font-size:13px;line-height:1.7";
    el.innerHTML = "⚠ <b>คำเตือนการบันทึกไฟล์</b><br>"+esc(s.save_warning);
    el.classList.remove("hidden");
  } else {
    el.classList.add("hidden");
    el.innerHTML = "";
  }
}
function updateBanner(s){
  const banner = $("#runBanner");
  const busy = ["launching","awaiting_login","running"].includes(s.state);
  const visible = busy || s.browser_open || ["done","stopped","error"].includes(s.state);
  banner.classList.toggle("hidden", !visible);
  if(!visible){ return; }
  const names = {launching:"กำลังเปิดเบราว์เซอร์",awaiting_login:"รอยืนยัน login",running:"กำลังค้นหา",done:"เสร็จสมบูรณ์",stopped:"หยุดแล้ว",error:"ผิดพลาด"};
  $("#rbState").textContent = (names[s.state]||s.state) + (s.step_mode ? " · ทีละขั้น" : "")
    + (s.recording ? ` · 🔴 บันทึก ${s.recording_steps||0} สเต็ป` : "");
  // โหมดทีละขั้น: เน้นแสดงขั้นปัจจุบัน
  if(s.awaiting_step && s.current_step){
    $("#rbMsg").textContent = "⏸ รอกด 'ทำขั้นต่อไป': " + s.current_step;
  } else if(s.step_mode && s.current_step && s.state==="running"){
    $("#rbMsg").textContent = "▶ " + s.current_step;
  } else {
    $("#rbMsg").textContent = s.message||"";
  }
  $("#rbBar").style.width = (s.percent||0)+"%";
  $("#rbNum").textContent = `${s.processed||0}/${s.total_rows||0}`;
  $("#btnConfirmLogin").classList.toggle("hidden", s.state!=="awaiting_login");
  $("#btnNextStep").classList.toggle("hidden", !s.awaiting_step);
  $("#btnAutoMode").classList.toggle("hidden", !(s.step_mode && busy));
  $("#btnStop").classList.toggle("hidden", !busy);
  $("#btnCloseBrowser").classList.toggle("hidden", !s.browser_open);
  if(s.account) $("#sideAccount").textContent = "👤 "+maskName(s.account);
  if(s.log){ const lg=$("#liveLog"); lg.textContent=s.log.join("\n"); lg.scrollTop=lg.scrollHeight; }
}

async function refreshQueueButtons(){
  const q = await api("/api/queue");
  if(q && q.length) renderQueue(q);
}

/* ---------- history ---------- */
async function loadHistory(){
  const r = await api("/api/recent");
  const rows = r ? r.searches : [];
  $("#histTable").innerHTML = rows.length ? `<table><thead><tr><th>เวลา</th><th>บัญชี</th><th>ไฟล์</th><th>แถว</th><th>เลขบัตร</th><th>ผล</th><th>รายละเอียด</th></tr></thead><tbody>`+
    rows.map(r=>{
      const b = r.outcome==="found"?`พบ ${r.case_count}`:r.outcome==="error"?"ผิดพลาด":"ไม่พบ";
      return `<tr><td>${esc(r.ts.slice(5,16).replace("T"," "))}</td><td>${esc(maskName(r.account||""))}</td><td>${esc((r.file||"").slice(0,22))}</td><td class="num">${r.row||""}</td><td>${esc(r.national_id)}</td><td>${b}</td><td>${esc((r.detail||"").slice(0,60))}</td></tr>`;
    }).join("")+`</tbody></table>` : '<div class="qempty">ยังไม่มีประวัติ</div>';
}

/* ---------- ล้างข้อมูลแต่ละหน้า (ของตัวเอง / admin=ทั้งหมด) ---------- */
async function clearSearches(){
  const scopeMsg = ME.role==="super_admin"
    ? "ล้างประวัติการค้นของ \"ทุกคน\" ทั้งระบบ?\n(สมาชิก/ทีม/อัตรา/รหัส ยังอยู่ครบ)"
    : "ล้างประวัติการค้น \"ของคุณ\" ทั้งหมด?";
  if(!confirm(scopeMsg + "\n\n⚠ ลบแล้วกู้คืนไม่ได้")) return;
  const r = await api("/api/clear/searches",{method:"POST"});
  if(r && r.ok){
    alert(r.scope==="all" ? "✓ ล้างข้อมูลการค้นทั้งระบบแล้ว" : "✓ ล้างข้อมูลการค้นของคุณแล้ว");
    loadDashboard();
    if(!$("#view-history").classList.contains("hidden")) loadHistory();
    if(ME.role==="super_admin" && !$("#view-billing").classList.contains("hidden")) loadBilling();
  } else {
    alert("✕ "+((r&&r.error)||"ล้มเหลว"));
  }
}
$("#btnClearSearches").onclick = clearSearches;
$("#btnClearHistory").onclick = clearSearches;

/* ---------- คู่มือการใช้งาน ---------- */
$("#btnManual").onclick = ()=>$("#manualModal").classList.remove("hidden");
$("#btnManualClose").onclick = ()=>$("#manualModal").classList.add("hidden");
$("#manualModal").onclick = e=>{ if(e.target.id==="manualModal") $("#manualModal").classList.add("hidden"); };

/* ---------- settings ---------- */
async function loadSettings(){
  const s = await api("/api/settings");
  if(!s) return;
  $("#setDisplayName").value = s.display_name||"";
  $("#setAccount").value = s.account||"";
  $("#setBind").value = s.bind_host||"127.0.0.1";
  $("#setPort").value = s.port||8770;
  if($("#setUpdateUrl")) $("#setUpdateUrl").value = s.update_url||"";
  if($("#curVersion")) $("#curVersion").textContent = s.version||"—";
  if(s.version) $("#sideVersion").textContent = "v"+s.version;
  if(ME.role==="super_admin"){
    const cs = await api("/api/action-code/state");
    $("#codeState").innerHTML = (cs && cs.has_code)
      ? '<span class="badge b-found">ตั้งรหัสแล้ว</span> เปลี่ยนได้โดยใส่รหัสใหม่ด้านล่าง'
      : '<span class="badge b-err">ยังไม่ได้ตั้งรหัส</span> ต้องตั้งก่อนจึงจะล้างทั้งหมด/แก้ไขจำนวนได้';
  }
}

$("#btnSaveCode").onclick = async ()=>{
  const code = $("#newActionCode").value;
  const r = await api("/api/admin/action-code",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code})});
  if(r && r.error){ $("#codeMsg").textContent = "✕ "+r.error; return; }
  $("#codeMsg").textContent = code ? "✓ บันทึกรหัสแล้ว" : "✓ ลบรหัสแล้ว";
  $("#newActionCode").value = "";
  loadSettings();
};

$("#btnClearAll").onclick = async ()=>{
  const code = $("#clearAllCode").value;
  if(!code){ $("#clearAllMsg").textContent = "กรุณาใส่รหัสยืนยัน"; return; }
  if(!confirm("⚠ ล้างข้อมูลทั้งหมด (ประวัติ+คิว+ไฟล์อัปโหลด) ของทั้งระบบ?\n\nกู้คืนไม่ได้!")) return;
  const r = await api("/api/clear/all",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code})});
  if(r && r.error){ $("#clearAllMsg").textContent = "✕ "+r.error; return; }
  $("#clearAllCode").value = "";
  $("#clearAllMsg").textContent = `✓ ล้างข้อมูลทั้งหมดแล้ว (ลบไฟล์อัปโหลด ${r.uploads_removed} ไฟล์)`;
  loadDashboard();
};
$("#btnSaveSettings").onclick = async()=>{
  const body = {display_name:$("#setDisplayName").value};
  // ค่าระดับระบบ (บัญชีเริ่มต้น/เครือข่าย/พอร์ต/URL อัปเดต) — เฉพาะ Super Admin ส่งได้ (ฝั่งเซิร์ฟเวอร์ก็กันซ้ำ)
  if(ME.role==="super_admin"){
    body.account = $("#setAccount").value;
    body.bind_host = $("#setBind").value;
    body.port = +$("#setPort").value;
    if($("#setUpdateUrl")) body.update_url = $("#setUpdateUrl").value;
  }
  const r = await api("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  if(r){
    $("#setMsg").textContent = "✓ บันทึกแล้ว (พอร์ต/เครือข่ายมีผลเมื่อเปิดโปรแกรมใหม่)";
    if($("#setDisplayName").value) $("#sideAccount").textContent = "👤 "+$("#setDisplayName").value;
  } else {
    $("#setMsg").textContent = "ล้มเหลว";
  }
};
$("#btnCheckUpdate").onclick = async()=>{
  $("#updateMsg").textContent = "กำลังตรวจสอบ...";
  const v = await api("/api/version");
  if(!v){ $("#updateMsg").textContent = "✕ ตรวจสอบไม่ได้"; return; }
  if($("#curVersion")) $("#curVersion").textContent = v.version||"—";
  if(!v.checked){
    $("#updateMsg").innerHTML = v.error
      ? "⚠ ตรวจสอบออนไลน์ไม่ได้ ("+esc(v.error)+")"
      : "ยังไม่ได้ตั้ง URL ตรวจสอบอัปเดต (Super Admin ตั้งได้ด้านล่าง)";
    return;
  }
  if($("#btnDoUpdate")) $("#btnDoUpdate").classList.toggle("hidden", !v.update_available);
  if(v.update_available){
    const link = v.download_url ? ` — <a class="link" href="${esc(v.download_url)}" target="_blank">ดาวน์โหลดเอง</a>` : "";
    $("#updateMsg").innerHTML = `🎉 มีเวอร์ชันใหม่ <b>v${esc(v.latest)}</b> — กด "อัปเดตเดี๋ยวนี้"${link}`+(v.notes?`<div class="muted" style="font-size:12px">${esc(v.notes)}</div>`:"");
  } else {
    $("#updateMsg").textContent = "✓ ใช้เวอร์ชันล่าสุดอยู่แล้ว (v"+(v.version||"")+")";
  }
};

/* ---------- อัปเดตออนไลน์ในตัว (ดาวน์โหลด+ติดตั้งเอง) ---------- */
let _updating = false;
async function doOnlineUpdate(){
  if(_updating) return;
  if(!confirm("อัปเดตโปรแกรมออนไลน์เดี๋ยวนี้?\n\nระบบจะดาวน์โหลดและติดตั้งเวอร์ชันใหม่ให้อัตโนมัติ\n(บัญชี/ประวัติ/การตั้งค่าเดิมอยู่ครบ)\n\nเสร็จแล้วให้ปิดโปรแกรมแล้วเปิดใหม่")) return;
  _updating = true;
  const btns = [$("#btnDoUpdate"), $("#unUpdate")].filter(Boolean);
  btns.forEach(b=>b.disabled=true);
  if($("#updateMsg")) $("#updateMsg").textContent = "⏳ กำลังดาวน์โหลดและติดตั้งอัปเดต...";
  const r = await api("/api/update/apply",{method:"POST"});
  _updating = false;
  btns.forEach(b=>b.disabled=false);
  if(!r || r.error){
    const m = "✕ "+((r&&r.error)||"อัปเดตไม่สำเร็จ");
    if($("#updateMsg")) $("#updateMsg").textContent = m;
    alert(m);
    return;
  }
  const un = $("#updateNotify"); if(un) un.classList.add("hidden");
  if(r.restarting){
    if($("#updateMsg")) $("#updateMsg").textContent = `✓ อัปเดตเป็น v${r.version} — กำลังรีสตาร์ทโปรแกรม...`;
    alert(`✓ อัปเดตเป็นเวอร์ชัน ${r.version} สำเร็จ!\n\nโปรแกรมกำลังรีสตาร์ทเองอัตโนมัติ — รอสักครู่หน้าต่างจะเปิดใหม่`);
  } else {
    if($("#updateMsg")) $("#updateMsg").textContent = `✓ อัปเดตเป็น v${r.version} แล้ว`;
    alert(`✓ อัปเดตเป็นเวอร์ชัน ${r.version} สำเร็จ!\n\nกรุณาปิดโปรแกรมแล้วเปิดใหม่ เพื่อใช้เวอร์ชันใหม่`);
  }
}
if($("#btnDoUpdate")) $("#btnDoUpdate").onclick = doOnlineUpdate;
$("#btnChangePw").onclick = async()=>{
  const r = await api("/api/password",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({current:$("#pwCur").value,new:$("#pwNew").value})});
  if(r && r.error){ $("#pwMsg").textContent="✕ "+r.error; }
  else { $("#pwMsg").textContent="✓ เปลี่ยนรหัสผ่านแล้ว"; $("#pwCur").value="";$("#pwNew").value=""; }
};

/* ========== MEMBERS (admin) ========== */
let editingMemberId = null;

async function loadMembers(){
  const members = await api("/api/admin/members");
  if(!members) return;
  const el = $("#memberList");
  if(!members.length){
    el.innerHTML = '<div class="qempty">ยังไม่มีสมาชิก</div>';
    return;
  }
  const roleLabel = r => r==="super_admin"?'<span class="badge b-found">Super Admin</span>':'<span class="badge b-none">Member</span>';
  const statusLabel = a => a?'<span class="badge b-found">ใช้งาน</span>':'<span class="badge b-err">ปิดใช้งาน</span>';
  el.innerHTML = `<table><thead><tr><th>ID</th><th>ชื่อผู้ใช้</th><th>ชื่อที่แสดง</th><th>สิทธิ์</th><th class="num">อัตรา (฿/ชื่อ)</th><th>สถานะ</th><th>สร้างเมื่อ</th><th>จัดการ</th></tr></thead><tbody>`+
    members.map(m=>`<tr>
      <td>${m.id}</td>
      <td>${esc(m.username)}</td>
      <td>${esc(m.display_name||"—")}</td>
      <td>${roleLabel(m.role)}</td>
      <td class="num">${m.rate_per_name!=null ? m.rate_per_name : '<span class="muted">ทั่วไป</span>'}</td>
      <td>${statusLabel(m.active)}</td>
      <td>${esc((m.created_at||"").slice(0,10))}</td>
      <td style="white-space:nowrap">
        <button class="btn-ghost btn-sm" onclick="editMember(${m.id})">แก้ไข</button>
        ${m.id !== ME.id ? `<button class="btn-ghost btn-sm" onclick="toggleMember(${m.id},${m.active?0:1})">${m.active?'ปิดใช้งาน':'เปิดใช้งาน'}</button>
        <button class="btn-danger btn-sm" onclick="deleteMember(${m.id},'${esc(m.username)}')">ลบ</button>` : '<span class="muted">(บัญชีคุณ)</span>'}
      </td>
    </tr>`).join("")+`</tbody></table>`;
}

$("#btnAddMember").onclick = ()=>{
  editingMemberId = null;
  $("#memberModalTitle").textContent = "เพิ่มสมาชิก";
  $("#mUsername").value = "";
  $("#mUsername").disabled = false;
  $("#mDisplayName").value = "";
  $("#mPassword").value = "";
  $("#mPassword").placeholder = "รหัสผ่าน (≥ 6 ตัว)";
  $("#mRole").value = "member";
  $("#mRate").value = "";
  $("#memberMsg").textContent = "";
  $("#memberModal").classList.remove("hidden");
};

window.editMember = async (id)=>{
  const members = await api("/api/admin/members");
  const m = members.find(x=>x.id===id);
  if(!m) return;
  editingMemberId = id;
  $("#memberModalTitle").textContent = "แก้ไขสมาชิก: "+m.username;
  $("#mUsername").value = m.username;
  $("#mUsername").disabled = true;
  $("#mDisplayName").value = m.display_name||"";
  $("#mPassword").value = "";
  $("#mPassword").placeholder = "เว้นว่าง = ไม่เปลี่ยน";
  $("#mRole").value = m.role;
  $("#mRate").value = m.rate_per_name != null ? m.rate_per_name : "";
  $("#memberMsg").textContent = "";
  $("#memberModal").classList.remove("hidden");
};

window.deleteMember = async (id, name)=>{
  if(!confirm(`ลบสมาชิก "${name}" ออกจากระบบถาวร?\n\n(ประวัติการค้นที่เคยทำจะยังอยู่ แต่จะไม่ผูกกับบัญชีนี้อีก)`)) return;
  const r = await api(`/api/admin/members/${id}`,{method:"DELETE"});
  if(r && r.error){ alert("✕ "+r.error); return; }
  loadMembers();
};

window.toggleMember = async (id, active)=>{
  const r = await api(`/api/admin/members/${id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({active})});
  if(r && r.error){ alert("✕ "+r.error); return; }
  loadMembers();
};

$("#btnMemberSave").onclick = async ()=>{
  const rateVal = $("#mRate").value.trim();
  const data = {
    username: $("#mUsername").value.trim(),
    display_name: $("#mDisplayName").value.trim(),
    password: $("#mPassword").value,
    role: $("#mRole").value,
    rate_per_name: rateVal !== "" ? parseFloat(rateVal) : null,
  };
  let r;
  if(editingMemberId){
    r = await api(`/api/admin/members/${editingMemberId}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
  } else {
    r = await api("/api/admin/members",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
  }
  if(r && r.error){
    $("#memberMsg").textContent = "✕ "+r.error;
  } else {
    $("#memberModal").classList.add("hidden");
    loadMembers();
  }
};

$("#btnMemberCancel").onclick = ()=>{
  $("#memberModal").classList.add("hidden");
};

/* ========== BILLING (admin) ========== */
async function loadBilling(ym){
  const cfg = await api("/api/admin/billing/config");
  if(cfg) $("#billRate").value = cfg.rate_per_name;

  const s = await api("/api/admin/billing/summary"+(ym?("?ym="+ym):""));
  if(!s) return;
  const sel = $("#billMonthSel");
  if(!ym){
    sel.innerHTML = (s.months||[]).map(m=>`<option value="${m}">${fmtMonth(m)}</option>`).join("") || `<option>—</option>`;
    sel.onchange = ()=>loadBilling(sel.value);
  }
  $("#billTotalCount").textContent = fmtNum(s.total_count);
  $("#billTotalAmount").textContent = fmtBaht(s.total_amount);
  $("#billRateDisp").textContent = s.rate;

  // ดาวน์โหลดสรุปการเงินเดือนที่เลือกเป็นไฟล์ Excel
  $("#btnExportBilling").onclick = ()=>{
    const m = $("#billMonthSel").value || "";
    const a = document.createElement("a");
    a.href = "/api/admin/billing/export" + (m ? ("?ym="+encodeURIComponent(m)) : "");
    document.body.appendChild(a); a.click(); a.remove();
  };

  const members = s.members||[];
  const el = $("#billMemberTable");
  if(!members.length){
    el.innerHTML = '<div class="qempty">ไม่มีข้อมูลเดือนนี้</div>';
  } else {
    const curYm = sel.value||s.ym;
    el.innerHTML = `<table><thead><tr><th>สมาชิก</th><th>ชื่อที่แสดง</th><th class="num">จำนวนค้น</th><th class="num">อัตรา (฿)</th><th class="num">ยอด (฿)</th><th>จัดการ</th></tr></thead><tbody>`+
      members.map(m=>{
        const adj = m.adjusted ? ` <span class="badge b-amber" title="${esc(m.note||'')}">แก้ไขแล้ว</span>` : "";
        const rawHint = m.adjusted && m.raw_count!=null && m.raw_count!==m.count ? `<div class="muted" style="font-size:11px">จริง ${fmtNum(m.raw_count)}</div>` : "";
        return `<tr>
        <td>${esc(m.username)}</td>
        <td>${esc(m.display_name||"—")}${adj}</td>
        <td class="num">${fmtNum(m.count)}${rawHint}</td>
        <td class="num">${m.rate}</td>
        <td class="num bill-amount">${fmtBaht(m.amount)}</td>
        <td style="white-space:nowrap">
          <button class="btn-ghost btn-sm" onclick="showBillDetail(${m.user_id},'${curYm}')">ดูรายวัน</button>
          <button class="btn-ghost btn-sm" onclick="openAdjust(${m.user_id},'${curYm}')">✎ แก้ไขยอด</button>
        </td>
      </tr>`;}).join("")+
      `<tr class="bill-total-row"><td colspan="2"><b>รวมทั้งหมด</b></td><td class="num"><b>${fmtNum(s.total_count)}</b></td><td></td><td class="num"><b>${fmtBaht(s.total_amount)}</b></td><td></td></tr>`+
      `</tbody></table>`;
  }
  $("#billDetailCard").classList.add("hidden");
  loadTeams();
}

window.showBillDetail = async (uid, ym)=>{
  const d = await api(`/api/admin/billing/detail/${uid}?ym=${ym}`);
  if(!d) return;
  const card = $("#billDetailCard");
  card.classList.remove("hidden");
  $("#billDetailTitle").textContent = `รายละเอียดรายวัน — ${d.display_name||d.username} (${fmtMonth(ym)})`;
  const daily = d.daily||[];
  if(!daily.length){
    $("#billDetailTable").innerHTML = '<div class="qempty">ไม่มีข้อมูล</div>';
    $("#billDetailTotal").textContent = "";
    return;
  }
  $("#billDetailTable").innerHTML = `<table><thead><tr><th>วันที่</th><th class="num">จำนวนค้น</th><th class="num">อัตรา (฿)</th><th class="num">ยอด (฿)</th></tr></thead><tbody>`+
    daily.map(r=>`<tr><td>${r.date}</td><td class="num">${fmtNum(r.count)}</td><td class="num">${d.rate}</td><td class="num">${fmtBaht(r.amount)}</td></tr>`).join("")+
    `</tbody></table>`;
  $("#billDetailTotal").textContent = `รวมทั้งเดือน: ${fmtNum(d.total_count)} รายชื่อ = ${fmtBaht(d.total_amount)} บาท`;
  card.scrollIntoView({behavior:"smooth"});
};

/* ---------- adjust billing (Super Admin) ---------- */
let adjustCtx = {uid:null, ym:null};

window.openAdjust = async (uid, ym)=>{
  adjustCtx = {uid, ym};
  const d = await api(`/api/admin/billing/detail/${uid}?ym=${ym}`);
  if(!d) return;
  $("#adjustTitle").textContent = `แก้ไขยอด — ${d.display_name||d.username} (${fmtMonth(ym)})`;
  $("#adjustRawInfo").innerHTML = `ค่าจริงจากระบบ: <b>${fmtNum(d.raw_count!=null?d.raw_count:d.total_count)}</b> รายชื่อ · อัตรา ${d.rate} ฿/ชื่อ = <b>${fmtBaht((d.raw_count!=null?d.raw_count:d.total_count)*d.rate)}</b> ฿`;
  const adj = d.adjust || {};
  $("#adjCount").value = adj.adj_count != null ? adj.adj_count : "";
  $("#adjAmount").value = adj.adj_amount != null ? adj.adj_amount : "";
  $("#adjNote").value = adj.note || "";
  $("#adjCode").value = "";
  $("#adjustMsg").textContent = "";
  $("#adjustModal").classList.remove("hidden");
};

async function saveAdjust(reset){
  const {uid, ym} = adjustCtx;
  if(!uid) return;
  const code = $("#adjCode").value;
  if(!code){ $("#adjustMsg").textContent = "กรุณาใส่รหัสยืนยัน"; return; }
  const body = reset
    ? {ym, adj_count:null, adj_amount:null, note:"", code}
    : {ym, adj_count:$("#adjCount").value, adj_amount:$("#adjAmount").value, note:$("#adjNote").value.trim(), code};
  const r = await api(`/api/admin/billing/adjust/${uid}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  if(r && r.error){ $("#adjustMsg").textContent = "✕ "+r.error; return; }
  $("#adjustModal").classList.add("hidden");
  loadBilling($("#billMonthSel").value||undefined);
}
$("#btnAdjSave").onclick = ()=>saveAdjust(false);
$("#btnAdjReset").onclick = ()=>saveAdjust(true);
$("#btnAdjCancel").onclick = ()=>$("#adjustModal").classList.add("hidden");

/* ========== AUDIT LOG (admin) ========== */
const AUDIT_LABELS = {
  login:"เข้าสู่ระบบ", login_failed:"เข้าสู่ระบบล้มเหลว", logout:"ออกจากระบบ",
  setup_superadmin:"ตั้งค่าผู้ดูแลระบบ", set_action_code:"ตั้งรหัสยืนยัน",
  clear_searches:"ล้างประวัติการค้น", clear_all:"ล้างข้อมูลทั้งหมด",
  update_apply:"อัปเดตโปรแกรม", member_create:"เพิ่มสมาชิก",
  member_update:"แก้ไขสมาชิก", member_delete:"ลบสมาชิก", billing_export:"ส่งออกรายงานการเงิน",
};
async function loadAudit(){
  loadRecordings();
  const d = await api("/api/admin/audit?limit=300");
  const el = $("#auditTable");
  if(!el) return;
  const rows = (d && d.entries) || [];
  if(!rows.length){ el.innerHTML = '<div class="qempty">ยังไม่มีบันทึก</div>'; return; }
  el.innerHTML = `<table><thead><tr><th>เวลา</th><th>ผู้ใช้</th><th>การกระทำ</th><th>รายละเอียด</th><th>IP</th></tr></thead><tbody>`+
    rows.map(e=>{
      const t = (e.ts||"").replace("T"," ");
      const act = AUDIT_LABELS[e.action] || e.action;
      const failed = e.action==="login_failed" || e.action==="clear_all";
      return `<tr>
        <td style="white-space:nowrap">${esc(t)}</td>
        <td>${esc(e.username||"—")}</td>
        <td>${failed?'<span class="badge b-amber">':''}${esc(act)}${failed?'</span>':''}</td>
        <td>${esc(e.detail||"")}</td>
        <td class="muted" style="font-size:11px">${esc(e.ip||"")}</td>
      </tr>`;}).join("")+
    `</tbody></table>`;
}
async function loadRecordings(){
  const el = $("#recTable");
  if(!el) return;
  const d = await api("/api/admin/recordings");
  const rows = (d && d.recordings) || [];
  if(!rows.length){ el.innerHTML = '<div class="qempty">ยังไม่มีบันทึก — ลองค้นแบบ “โหมดทีละขั้น” สักครั้ง</div>'; return; }
  el.innerHTML = `<table><thead><tr><th>เริ่ม</th><th>เสร็จ</th><th>บัญชี</th><th>สเต็ป</th><th>สถานะ</th><th></th></tr></thead><tbody>`+
    rows.map(r=>`<tr>
        <td style="white-space:nowrap">${esc(r.started||r.name)}</td>
        <td style="white-space:nowrap">${esc(r.finished||"—")}</td>
        <td>${esc(r.account||"—")}</td>
        <td>${r.steps||0}</td>
        <td>${r.done?'<span class="badge b-found">เสร็จ</span>':'<span class="badge b-amber">ค้างอยู่</span>'}</td>
        <td><a class="btn-ghost btn-sm" href="/api/admin/recordings/${encodeURIComponent(r.name)}/download">⬇ .zip</a></td>
      </tr>`).join("")+
    `</tbody></table>`;
}
const _btnRefreshAudit = $("#btnRefreshAudit");
if(_btnRefreshAudit) _btnRefreshAudit.onclick = loadAudit;

$("#btnSaveRate").onclick = async ()=>{
  const rate = parseFloat($("#billRate").value);
  if(isNaN(rate) || rate < 0){ $("#rateMsg").textContent = "กรุณาใส่ตัวเลขที่ถูกต้อง"; return; }
  const r = await api("/api/admin/billing/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({rate_per_name:rate})});
  if(r){
    $("#rateMsg").textContent = "✓ บันทึกแล้ว";
    loadBilling($("#billMonthSel").value||undefined);
  }
};

/* ========== TEAMS (admin — inside billing) ========== */
let editingTeamId = null;
let allMembersCache = [];

async function loadTeams(){
  const ym = $("#billMonthSel").value || "";
  const teams = await api("/api/admin/teams");
  const el = $("#teamList");
  if(!teams || !teams.length){
    el.innerHTML = '<div class="qempty">ยังไม่มีทีม — กดปุ่ม "+ สร้างทีม" เพื่อจัดกลุ่ม</div>';
    return;
  }
  let html = "";
  for(const t of teams){
    const memberNames = t.members.map(m=>esc(m.display_name||m.username)).join(", ") || "(ไม่มีสมาชิก)";
    const bill = await api(`/api/admin/teams/${t.id}/billing?ym=${ym}`);
    const perPerson = bill ? fmtBaht(bill.per_person) : "—";
    const totalAmt = bill ? fmtBaht(bill.total_amount) : "—";
    const totalCnt = bill ? fmtNum(bill.total_count) : "0";
    const n = bill ? bill.member_count : t.members.length;
    const teamRateLabel = t.rate_per_name != null ? `${t.rate_per_name} ฿/ชื่อ` : "ใช้อัตราทั่วไป";

    html += `<div class="team-card">
      <div class="team-header">
        <div>
          <div class="team-name">${esc(t.name)} <span class="muted" style="font-size:12px;font-weight:400">— อัตราทีม: ${teamRateLabel}</span></div>
          <div class="team-members-text">${memberNames}</div>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn-ghost btn-sm" onclick="openEditTeam(${t.id})">แก้ไข</button>
          <button class="btn-danger btn-sm" onclick="deleteTeam(${t.id},'${esc(t.name)}')">ลบ</button>
        </div>
      </div>
      <div class="team-billing">
        <div class="team-stat"><span class="muted">ค้นรวม</span><b>${totalCnt}</b></div>
        <div class="team-stat"><span class="muted">ยอดรวม</span><b>${totalAmt} ฿</b></div>
        <div class="team-stat"><span class="muted">÷ ${n} คน</span></div>
        <div class="team-stat team-per-person"><span class="muted">คนละ</span><b>${perPerson} ฿</b></div>
      </div>`;

    if(bill && bill.members && bill.members.length){
      html += `<div class="team-detail-table"><table><thead><tr><th>สมาชิก</th><th class="num">อัตรา (฿)</th><th class="num">ค้น</th><th class="num">ยอดจริง (฿)</th><th class="num">จ่ายเท่ากัน (฿)</th></tr></thead><tbody>`;
      for(const m of bill.members){
        html += `<tr><td>${esc(m.display_name||m.username)}</td><td class="num">${m.rate}</td><td class="num">${fmtNum(m.count)}</td><td class="num">${fmtBaht(m.amount)}</td><td class="num bill-amount">${perPerson}</td></tr>`;
      }
      html += `</tbody></table>`;

      // daily breakdown per member
      for(const m of bill.members){
        if(m.daily && m.daily.length){
          html += `<details style="margin-top:8px"><summary style="cursor:pointer;font-size:12.5px;color:var(--acc)">📅 รายวัน — ${esc(m.display_name||m.username)}</summary>`;
          html += `<table style="margin-top:6px"><thead><tr><th>วันที่</th><th class="num">จำนวนค้น</th><th class="num">ยอด (฿)</th></tr></thead><tbody>`;
          for(const d of m.daily){
            html += `<tr><td>${d.date}</td><td class="num">${fmtNum(d.count)}</td><td class="num">${fmtBaht(d.amount)}</td></tr>`;
          }
          html += `</tbody></table></details>`;
        }
      }
      html += `</div>`;
    }
    html += `</div>`;
  }
  el.innerHTML = html;
}

$("#btnAddTeam").onclick = async ()=>{
  editingTeamId = null;
  $("#teamModalTitle").textContent = "สร้างทีม";
  $("#tName").value = "";
  $("#tRate").value = "";
  $("#teamMsg").textContent = "";
  await renderTeamMemberChecks([]);
  $("#teamModal").classList.remove("hidden");
};

async function renderTeamMemberChecks(selectedIds){
  const members = await api("/api/admin/members");
  allMembersCache = members || [];
  const el = $("#tMemberChecks");
  el.innerHTML = allMembersCache.filter(m=>m.active).map(m=>{
    const checked = selectedIds.includes(m.id) ? "checked" : "";
    return `<label class="chk-row"><input type="checkbox" value="${m.id}" ${checked}> ${esc(m.display_name||m.username)} <span class="muted">(${m.username})</span></label>`;
  }).join("");
}

function getSelectedTeamMembers(){
  return Array.from($("#tMemberChecks").querySelectorAll("input:checked")).map(el=>+el.value);
}

window.openEditTeam = async (id)=>{
  const teams = await api("/api/admin/teams");
  const t = teams.find(x=>x.id===id);
  if(!t) return;
  editingTeamId = id;
  $("#teamModalTitle").textContent = "แก้ไขทีม: "+t.name;
  $("#tName").value = t.name;
  $("#tRate").value = t.rate_per_name != null ? t.rate_per_name : "";
  $("#teamMsg").textContent = "";
  await renderTeamMemberChecks(t.members.map(m=>m.id));
  $("#teamModal").classList.remove("hidden");
};

window.deleteTeam = async (id, name)=>{
  if(!confirm(`ลบทีม "${name}" ?`)) return;
  await api(`/api/admin/teams/${id}`,{method:"DELETE"});
  loadTeams();
};

$("#btnTeamSave").onclick = async ()=>{
  const name = $("#tName").value.trim();
  if(!name){ $("#teamMsg").textContent = "กรุณาตั้งชื่อทีม"; return; }
  const memberIds = getSelectedTeamMembers();
  const tRateVal = $("#tRate").value.trim();
  const body = {name, member_ids:memberIds, rate_per_name: tRateVal !== "" ? parseFloat(tRateVal) : null};
  let r;
  if(editingTeamId){
    r = await api(`/api/admin/teams/${editingTeamId}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  } else {
    r = await api("/api/admin/teams",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  }
  if(r && r.error){
    $("#teamMsg").textContent = "✕ "+r.error;
  } else {
    $("#teamModal").classList.add("hidden");
    loadTeams();
  }
};

$("#btnTeamCancel").onclick = ()=>{
  $("#teamModal").classList.add("hidden");
};

/* ---------- charts (vanilla SVG/DOM) ---------- */
function drawBars(el, data){
  if(!data || !data.length){ el.innerHTML='<div class="qempty">ไม่มีข้อมูล</div>'; return; }
  const max = Math.max(...data.map(d=>d.y),1);
  el.innerHTML = `<div class="bars">`+data.map(d=>
    `<div class="bar-col"><div class="bar" style="height:${Math.round(100*d.y/max)}%" title="${d.y}"></div><div class="bar-x">${esc(d.x)}</div></div>`
  ).join("")+`</div>`;
}
function drawDonut(el, segs){
  const total = segs.reduce((a,s)=>a+s.value,0);
  if(!total){ el.innerHTML='<div class="qempty">ไม่มีข้อมูล</div>'; return; }
  const R=70, C=2*Math.PI*R; let off=0;
  const circles = segs.map(s=>{
    const len = C*s.value/total;
    const c = `<circle r="${R}" cx="90" cy="90" fill="none" stroke="${s.color}" stroke-width="26"
      stroke-dasharray="${len} ${C-len}" stroke-dashoffset="${-off}" transform="rotate(-90 90 90)"/>`;
    off += len; return c;
  }).join("");
  const legend = segs.map(s=>`<div class="legend-row"><span class="dot" style="background:${s.color}"></span>${s.label} <b style="margin-left:auto">${s.value}</b> <span class="muted">(${Math.round(100*s.value/total)}%)</span></div>`).join("");
  el.innerHTML = `<div class="donut-wrap"><svg width="180" height="180" viewBox="0 0 180 180">${circles}
    <text x="90" y="86" text-anchor="middle" fill="#e6edf7" font-size="26" font-weight="700">${total}</text>
    <text x="90" y="106" text-anchor="middle" fill="#8295b3" font-size="12">รายการ</text></svg>
    <div class="legend" style="flex:1">${legend}</div></div>`;
}

/* ---------- แจ้งเตือนมีเวอร์ชันใหม่อัตโนมัติ (กดอัปเดตเอง) ---------- */
async function checkUpdateNotify(){
  const el = $("#updateNotify"); if(!el) return;
  let v; try { v = await api("/api/version"); } catch(e){ return; }
  if(!v || !v.update_available || !v.latest) return;
  if(localStorage.getItem("crimesDismissUpdate") === v.latest) return;   // เคยปิดแจ้งเตือนเวอร์ชันนี้แล้ว
  const link = v.download_url ? `<a class="link" href="${esc(v.download_url)}" target="_blank">ดาวน์โหลดเอง</a>` : "";
  const notes = v.notes ? `<span class="muted" style="flex:1;min-width:120px">${esc(v.notes)}</span>` : `<span style="flex:1"></span>`;
  el.style.cssText = "background:linear-gradient(135deg,rgba(34,227,154,.14),rgba(0,229,255,.08));border:1px solid rgba(34,227,154,.45);color:#c8ffe6;padding:12px 16px;border-radius:10px;margin-bottom:16px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;font-size:13.5px";
  el.innerHTML = `🎉 <b>มีเวอร์ชันใหม่ v${esc(v.latest)}</b> (ปัจจุบัน v${esc(v.version||"")})${notes}`+
    `<button class="btn-primary btn-sm" id="unUpdate" style="width:auto;margin:0;padding:6px 14px">⬇ อัปเดตเดี๋ยวนี้</button>${link}`+
    `<button class="btn-ghost btn-sm" id="unDismiss">ปิด</button>`;
  el.classList.remove("hidden");
  const u = $("#unUpdate"); if(u) u.onclick = doOnlineUpdate;
  const d = $("#unDismiss");
  if(d) d.onclick = ()=>{ localStorage.setItem("crimesDismissUpdate", v.latest); el.classList.add("hidden"); };
}

/* ---------- init (auth-controlled) ---------- */
let __booted=false;
function bootApp(){ if(__booted) return; __booted=true; loadMe().then(()=>{ loadDashboard(); poll(); checkUpdateNotify(); }); }

