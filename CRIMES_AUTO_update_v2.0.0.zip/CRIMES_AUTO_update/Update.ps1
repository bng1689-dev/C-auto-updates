﻿<#
  Update.ps1 — อัปเดตโค้ดโปรแกรม CRIMES AUTO (แบบเบา)
  แทนที่เฉพาะโฟลเดอร์ app\ (โค้ด) โดย "เก็บบัญชี/ประวัติ/การตั้งค่าเดิมไว้ครบ"
  ไม่แตะ runtime\ และ browsers\ (จึงไฟล์เล็ก อัปเดตเร็ว)
  เซ็นด้วยใบรับรอง self-signed โดย build.ps1 · เรียกผ่าน อัปเดต.bat
#>
$ErrorActionPreference = "Stop"
$Src = $PSScriptRoot
$Install = Join-Path $env:LOCALAPPDATA "CRIMES-AUTO"

Write-Host ""
Write-Host "============================================"
Write-Host "   อัปเดตโปรแกรม CRIMES AUTO"
Write-Host "============================================"

if (-not (Test-Path $Install)) {
    Write-Host "[X] ยังไม่ได้ติดตั้งโปรแกรมบนเครื่องนี้ — ใช้ ติดตั้ง.bat ก่อน" -ForegroundColor Red
    Read-Host "กด Enter เพื่อปิด"; exit 1
}
if (-not (Test-Path (Join-Path $Src "app"))) {
    Write-Host "[X] ไม่พบโฟลเดอร์ app\ ในชุดอัปเดต" -ForegroundColor Red
    Read-Host "กด Enter เพื่อปิด"; exit 1
}

function Get-Ver($p){ if (Test-Path $p) { (Get-Content $p -Raw).Trim() } else { "?" } }
$curVer = Get-Ver (Join-Path $Install "app\VERSION")
$newVer = Get-Ver (Join-Path $Src "app\VERSION")
Write-Host ("เวอร์ชันปัจจุบัน: {0}   ->   เวอร์ชันใหม่: {1}" -f $curVer, $newVer)

# ---- ปิดโปรแกรมที่กำลังรัน + Chrome ของระบบที่ค้าง (กันไฟล์ถูกล็อก) ----
Write-Host "  - ปิดโปรแกรมที่กำลังทำงาน (ถ้ามี)..."
try {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        ($_.Name -eq 'pythonw.exe' -or $_.Name -eq 'python.exe') -and $_.CommandLine -match 'CRIMES-AUTO'
    } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -match 'crimes_auto_profile'
    } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}
Start-Sleep -Milliseconds 1200

# ---- สำรองฐานข้อมูลเดิมไว้ก่อน (กันเหนียว) ----
$dataDir = Join-Path $Install "app\backend\data"
if (Test-Path (Join-Path $dataDir "data.db")) {
    $bk = Join-Path $dataDir ("data.backup-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".db")
    Copy-Item (Join-Path $dataDir "data.db") $bk -Force -ErrorAction SilentlyContinue
    Write-Host "  - สำรองฐานข้อมูลไว้: $(Split-Path $bk -Leaf)"
}

# ---- แทนที่โค้ด app\ (merge) — กันไม่ให้ทับ data\ / uploads\ ของเครื่องที่ติดตั้ง ----
# (กัน /XD ทั้งฝั่ง source และ dest เพื่อความปลอดภัยไม่ว่าจะรันจากที่ใด)
Write-Host "  - อัปเดตไฟล์โปรแกรม (เก็บบัญชี/ประวัติเดิมไว้ครบ)..."
$xdData = @(
    (Join-Path $Src "app\backend\data"), (Join-Path $Src "app\backend\uploads"),
    (Join-Path $Install "app\backend\data"), (Join-Path $Install "app\backend\uploads"),
    "__pycache__"
)
robocopy (Join-Path $Src "app") (Join-Path $Install "app") /E /XD @xdData /XF "*.pyc" /NFL /NDL /NJH /NJS /NP > $null
$rc = $LASTEXITCODE
if ($rc -ge 8) {
    Write-Host "[X] อัปเดตล้มเหลว (robocopy code $rc) — ปิดโปรแกรมค้างแล้วลองใหม่" -ForegroundColor Red
    Read-Host "กด Enter เพื่อปิด"; exit 1
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host ("   [OK] อัปเดตเป็นเวอร์ชัน {0} สำเร็จ!" -f $newVer) -ForegroundColor Green
Write-Host "   เปิดโปรแกรมจากไอคอน CRIMES AUTO ได้ตามปกติ" -ForegroundColor Green
Write-Host "   (บัญชี/ประวัติ/การตั้งค่าเดิมยังอยู่ครบ)" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Read-Host "กด Enter เพื่อปิด"
