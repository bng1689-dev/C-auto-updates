"""ส่ง "ตัวเลขนับ" ขึ้นศูนย์กลาง (Google Apps Script) — ไม่ส่งข้อมูลประวัติใด ๆ

ขอบเขตที่ตกลงไว้ และห้ามขยายโดยไม่ได้รับอนุมัติ
────────────────────────────────────────────────
ส่งออกได้:   จำนวนการค้นรายวันรายคน (รวม/พบ/ไม่พบ/ผิดพลาด) · จำนวนไฟล์
             · ชื่อที่แสดงของผู้ใช้ · รหัสติดตั้งของเครื่อง
             (ยอดรับ/จ่ายรายวันเคยอยู่ในก้อนนี้ — ตั้งแต่ 3.9.0 เงินไปทางสมุดกองกลาง (kind="ledger") ทางเดียว
              ไม่งั้นยอดที่เครื่องหนึ่งรายงานจะค้างในชีต counts หลังอีกเครื่องลบรายการ)
             · (v3.2.0) เวอร์ชันโปรแกรมและเวลาใช้งานล่าสุดของแต่ละคน — เพื่อให้ผู้ดูแลเห็นว่า
               สมาชิกเครื่องไหนใช้ Ver. ไหน/ออนไลน์อยู่ไหม แบบเรียลไทม์
             · (v3.7.0 — เจ้าของโปรเจกต์อนุมัติ) ไดเรกทอรีสมาชิกกลาง: ชื่อผู้ใช้สำหรับล็อกอิน ·
               ชื่อที่แสดง · บทบาท · สิทธิ์ · สถานะ · รหัสผ่านแบบแฮช pbkdf2+salt (ไม่ใช่รหัสผ่านจริง) ·
               อัตราค่าบริการ · เวลาสร้าง/แก้ — เพื่อให้สมาชิกเข้าได้ทุกเครื่องที่ติดตั้ง
               · (v3.9.0 — "เครื่อง Superadmin เป็นผู้จัดการทุกสิทธิ์ได้") ทีมที่สังกัด: ชื่อทีม + อัตราทีม
             · (v3.9.0 — เจ้าของโปรเจกต์สั่ง "แสดงค่าเดียวกันทุกเครื่อง") สมุดกองกลาง: รายการรับ/จ่ายทีละรายการ
               (เวลา · เดือน · ชื่อผู้ใช้เจ้าของ · ประเภท · จำนวน · หมายเหตุที่ผู้ดูแลพิมพ์เอง · ผู้บันทึก · ลบแล้ว)
               — เพื่อให้ทุกเครื่องเห็นสมุดเล่มเดียวกัน · หมายเหตุเป็นข้อความอิสระ: ห้ามพิมพ์เลขบัตร/ชื่อผู้ถูกค้น/ผลคดีลงไป
ห้ามส่งเด็ดขาด: เลขบัตรประชาชน · ชื่อผู้ถูกค้น · รายละเอียดคดี/ผลการค้น · ชื่อไฟล์งาน
             · รหัสผ่านตัวจริง · PASSCODE (ผูก secret ของเครื่อง) · KEY

payload ถูกประกอบจาก ALLOWED_FIELDS / PRESENCE_FIELDS / MEMBER_FIELDS / LEDGER_FIELDS เท่านั้น
(ไม่ใช่ "เอาทั้ง row แล้วลบบางคอลัมน์") เพราะการเพิ่มคอลัมน์ใหม่ในฐานข้อมูลวันหลังจะได้ไม่หลุดออกไปเอง
"""
import base64
import hashlib
import hmac
import json
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

import db

# คีย์ทุกตัวที่อนุญาตให้อยู่ในแถวข้อมูลที่ส่งออก — มีเท่านี้ ไม่มีมากกว่านี้
# (v3.9.0: ตัด amount_in/amount_out — เงินไปทางชีต ledger ซึ่งศูนย์กลางใช้คิดยอดของกระดานเอง)
ALLOWED_FIELDS = ("date", "uid", "display_name", "searches", "found",
                  "notfound", "error", "files")
# v3.2.0: ข้อมูล "ตัวตน/สถานะ" ของสมาชิกที่ส่งขึ้นศูนย์กลาง — มีเท่านี้เช่นกัน
PRESENCE_FIELDS = ("uid", "display_name", "app_version", "last_seen")
PAYLOAD_VERSION = 2
CONNECT_PREFIX = "CRIMES-HUB:"
# v3.9.2: รุ่นสคริปต์ศูนย์กลาง (tools/hub_gas.js) ที่โปรแกรมรุ่นนี้ต้องการ — สคริปต์ตอบ ver มาในทุกคำตอบ
HUB_SCRIPT_REQUIRED = "3.9.2"
TIMEOUT = 15
# v3.9.0: การอ่านกระดาน/สถานะ (GET) ต้องรอคิวล็อกของสคริปต์ (สูงสุด 25 วิ) ถ้ามีเครื่องอื่นกำลังส่งอยู่ —
# 15 วิ สั้นเกินไป ผู้ใช้เห็น "The read operation timed out" ทั้งที่ศูนย์กลางปกติดี
BOARD_TIMEOUT = 40


_REDIRECTS = (301, 302, 303, 307, 308)
_MAX_HOPS = 6


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """ไม่ตาม redirect เอง — ให้ _open คืนรหัส 3xx พร้อม Location กลับไป แล้ว _walk_post ตัดสินว่าจะตามอย่างไร"""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _open(req):
    """เปิดคำขอหนึ่งครั้งโดยไม่ตาม redirect — คืน (status, headers, body) · 3xx คืน body ว่าง · 4xx/5xx โยน HTTPError"""
    try:
        with urllib.request.build_opener(_NoRedirect).open(req, timeout=TIMEOUT) as r:
            return r.status, r.headers, r.read()
    except urllib.error.HTTPError as e:
        if e.code in _REDIRECTS:
            return e.code, e.headers, b""
        raise


def _walk_post(url, body, headers):
    """POST ไป Apps Script แล้วตาม redirect 'ให้ถูกชนิด' (v3.8.1) — คืน bytes ของคำตอบ

    Apps Script ตอบ 302 จาก /exec สองแบบ:
    • ไปที่ *.googleusercontent.com (…/macros/echo?user_content_key=…) = สคริปต์ทำงาน 'เสร็จแล้ว' นี่คือที่รับผล
      → ตามด้วย GET ไม่มี body (มาตรฐานของเบราว์เซอร์) · ถ้าที่นั่นตอบ 405 ให้ขอผลด้วย POST ที่ URL เดิมนั้น
      ห้ามย้อนไปยิง /exec ซ้ำ — สคริปต์ทำงานไปแล้ว การส่งซ้ำจะทำให้แถวสมาชิกที่เพิ่งรับกลายเป็น conflict
    • ไปที่ script.google.com อีก URL (เช่น /a/macros/<โดเมน>/… ของบัญชีองค์กร) = ยังไม่ถึงสคริปต์ → คง POST + body
    รุ่นก่อน 3.8.1 คง POST + body ไปที่ googleusercontent ทุกกรณี → Google ตอบ 405 ได้ (ซิงก์สมาชิกล้ม)"""
    get_headers = {"User-Agent": headers.get("User-Agent", "CRIMES-AUTO-Hub")}
    target, method = url, "POST"
    for _hop in range(_MAX_HOPS):
        if method == "POST":
            req = urllib.request.Request(target, data=body, method="POST", headers=headers)
        else:
            req = urllib.request.Request(target, method="GET", headers=get_headers)
        try:
            status, hdrs, raw = _open(req)
        except urllib.error.HTTPError as e:
            if e.code != 405 or method != "GET":
                raise
            # ที่รับผลไม่รับ GET → ขอผลด้วย POST ที่ URL นี้ (ไม่ใช่ /exec จึงไม่ทำให้สคริปต์ทำงานซ้ำ)
            status, hdrs, raw = _open(urllib.request.Request(target, data=body, method="POST", headers=headers))
        if status not in _REDIRECTS:
            return raw
        loc = hdrs.get("Location") or ""
        if not loc:
            raise urllib.error.URLError("ศูนย์กลางตอบ redirect โดยไม่บอกปลายทาง")
        target = urllib.parse.urljoin(target, loc)
        host = (urllib.parse.urlsplit(target).hostname or "").lower()
        method = "GET" if host.endswith("googleusercontent.com") else "POST"
    raise urllib.error.URLError("ศูนย์กลาง redirect มากเกินไป")


def sign(body_bytes, token):
    return hmac.new(str(token or "").encode("utf-8"), body_bytes, hashlib.sha256).hexdigest()


def collect_rows(ym):
    """รวบรวมตัวเลขของเดือนนี้จากฐานข้อมูลในเครื่อง — อ่านอย่างเดียว ไม่แตะข้อมูลจริง
    v3.9.0: ไม่มียอดรับ/จ่ายในก้อนนี้อีกแล้ว — สมุดกองกลาง (sync_ledger) เป็นทางเดียวที่เงินขึ้นศูนย์กลาง"""
    # ไม่มีชื่อที่แสดง → ใช้ "ผู้ใช้ #id" (ห้ามถอยไปใช้ชื่อล็อกอิน)
    people = {u["id"]: (u["display_name"] or f"ผู้ใช้ #{u['id']}") for u in db.list_users()}
    daily = {}
    with db.get_conn() as c:
        for r in c.execute(
            "SELECT substr(ts,1,10) d, user_id,"
            " COUNT(*) n,"
            " SUM(outcome='found') f,"
            " SUM(outcome='notfound') nf,"
            " SUM(outcome='error') e,"
            " COUNT(DISTINCT file) nfiles"
            " FROM searches WHERE ym=? GROUP BY d, user_id", (ym,)
        ).fetchall():
            daily[(r["d"], r["user_id"])] = {
                "searches": r["n"], "found": r["f"] or 0,
                "notfound": r["nf"] or 0, "error": r["e"] or 0,
                # นับจำนวนไฟล์เท่านั้น — ชื่อไฟล์ไม่ออกจากเครื่อง
                "files": r["nfiles"] or 0,
            }

    rows = []
    for (d, uid), vals in sorted(daily.items()):
        row = {"date": d, "uid": int(uid), "display_name": people.get(uid, "")}
        row.update(vals)
        rows.append({k: row.get(k, 0) for k in ALLOWED_FIELDS})
    return rows


def collect_presence():
    """รายชื่อ+เวอร์ชัน+เวลาใช้งานล่าสุด — กรองผ่าน PRESENCE_FIELDS เท่านั้น"""
    return [{k: r.get(k, "") for k in PRESENCE_FIELDS} for r in db.presence_rows()]


def build_payload(ym, install_id, app_version=""):
    """สร้างก้อนข้อมูลที่จะส่ง — ทุกแถวถูกกรองผ่าน ALLOWED_FIELDS อีกชั้นก่อนออก"""
    rows = []
    for r in collect_rows(ym):
        rows.append({k: r[k] for k in ALLOWED_FIELDS if k in r})
    return {
        "v": PAYLOAD_VERSION,
        "kind": "counts",
        "install_id": str(install_id or ""),
        "app_version": str(app_version or ""),
        "ym": ym,
        "sent_at": datetime.now().isoformat(timespec="seconds"),
        "rows": rows,
        "users": collect_presence(),
    }


def build_presence_payload(install_id, app_version=""):
    """ก้อนสถานะอย่างเดียว (ไม่มี rows) — ศูนย์กลางต้องไม่ลบตัวเลขเดือนเมื่อได้รับก้อนนี้"""
    return {
        "v": PAYLOAD_VERSION,
        "kind": "presence",
        "install_id": str(install_id or ""),
        "app_version": str(app_version or ""),
        "sent_at": datetime.now().isoformat(timespec="seconds"),
        "users": collect_presence(),
    }


# ──────────────── v3.2.0: รหัสเชื่อมต่อ (URL+รหัสลับ ในสตริงเดียว) ────────────────
def make_connect_code(url, token):
    """ให้ผู้ดูแลคัดลอกไปแจกสมาชิก — วางตอนสมัครใช้งานแล้วเครื่องนั้นเชื่อมศูนย์กลางทันที
    (มีรหัสลับอยู่ข้างใน จึงต้องส่งให้เฉพาะคนในหน่วยงาน ไม่โพสต์สาธารณะ)"""
    raw = json.dumps({"url": str(url or ""), "token": str(token or "")},
                     separators=(",", ":")).encode("utf-8")
    return CONNECT_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def parse_connect_code(code):
    """คืน (url, token) หรือ None ถ้ารหัสไม่ถูกต้อง"""
    s = "".join(str(code or "").split())
    if len(s) > 4096 or not s.startswith(CONNECT_PREFIX):
        return None
    b = s[len(CONNECT_PREFIX):]
    try:
        raw = base64.urlsafe_b64decode(b + "=" * (-len(b) % 4))
        d = json.loads(raw.decode("utf-8"))
        if not isinstance(d, dict):
            return None
        url, token = str(d.get("url") or "").strip(), str(d.get("token") or "")
    except (ValueError, TypeError, UnicodeDecodeError, AttributeError):
        return None
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in url + token):
        return None
    # รหัสเชื่อมต่อใช้ได้กับศูนย์กลาง Apps Script เท่านั้น — รหัสปลอมจะพาตัวเลขไปที่อื่นไม่ได้
    if not url.startswith("https://script.google.com/macros/") or not token:
        return None
    return url, token


def _with_query(url, extra):
    return url + ("&" if "?" in url else "?") + urllib.parse.urlencode(extra)


def _post(url, payload, token, admin_token=None):
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    # ลายเซ็นต้องไปกับ query string ไม่ใช่ header — Apps Script อ่าน header ที่ผู้เรียก
    # กำหนดเองไม่ได้เลย (เห็นแค่ e.parameter กับ e.postData) ถ้าใส่ใน header จะไม่มีวันถึงปลายทาง
    q = {"sign": sign(body, token)}
    if admin_token:
        q["asign"] = sign(body, admin_token)       # v3.7.0: ลายเซ็นผู้ดูแล — ศูนย์กลางจึงยอมให้แก้ไดเรกทอรีสมาชิก
    headers = {
        # Apps Script อ่านตัวข้อมูลดิบจาก e.postData.contents — ใช้ text/plain เพื่อไม่ให้ถูกตีความเป็นฟอร์ม
        "Content-Type": "text/plain;charset=utf-8",
        "User-Agent": "CRIMES-AUTO-Hub",
    }
    raw = _walk_post(_with_query(url, q), body, headers).decode("utf-8", "replace")
    try:
        return json.loads(raw)
    except ValueError:
        return {"ok": False, "error": "ศูนย์กลางตอบกลับไม่ใช่ JSON: " + raw[:150]}


def push(url, token, ym, install_id, app_version="", presence_only=False):
    """ส่งตัวเลขขึ้นศูนย์กลาง — คืน dict {"ok":bool, ...} ไม่โยน exception ออกไป

    ตัวส่งทำงานเบื้องหลัง ความล้มเหลวจึงต้องไม่ทำให้โปรแกรมหลักสะดุด
    presence_only=True ส่งเฉพาะสถานะ (ใครออนไลน์/เวอร์ชันไหน) — เบาและถี่ได้
    """
    if not url:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง URL ศูนย์กลาง"}
    payload = (build_presence_payload(install_id, app_version) if presence_only
               else build_payload(ym, install_id, app_version))
    try:
        res = _post(url, payload, token)
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"ศูนย์กลางตอบ {e.code}"}
    except Exception as e:                       # เน็ตหลุด/DNS/timeout — เก็บไว้ส่งรอบหน้า
        return {"ok": False, "error": str(e)[:150]}
    if not isinstance(res, dict) or not res.get("ok"):
        msg = (res or {}).get("error") if isinstance(res, dict) else "รูปแบบคำตอบไม่ถูกต้อง"
        return {"ok": False, "error": msg or "ศูนย์กลางปฏิเสธข้อมูล"}
    res["rows_sent"] = len(payload.get("rows") or [])
    return res


def fetch_board(url, token, ym):
    """ดึงยอดรวมของทุกเครื่องจากศูนย์กลาง (อ่านอย่างเดียว)"""
    if not url:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง URL ศูนย์กลาง"}
    q = _with_query(url, {"action": "board", "ym": ym,
                          "sign": sign(f"board:{ym}".encode("utf-8"), token)})
    req = urllib.request.Request(q, headers={"User-Agent": "CRIMES-AUTO-Hub"})
    try:
        with urllib.request.build_opener().open(req, timeout=BOARD_TIMEOUT) as r:     # GET ตาม redirect แบบมาตรฐาน
            return json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        return {"ok": False, "error": str(e)[:150]}


# ──────────────── v3.7.0: ไดเรกทอรีสมาชิกกลาง ────────────────
# ก้อน kind="members" — ส่งเฉพาะสมาชิกที่เครื่องนี้แก้ (พร้อม rev ที่เห็นล่าสุด) ศูนย์กลางตัดสินว่ารับหรือไม่
# แล้วตอบกลับไดเรกทอรีทั้งองค์กร + รายการที่ปัดตกในคำขอเดียว (เครื่องนี้เอาไปปรับสมาชิกในเครื่อง — db.apply_remote_members)
# ลายเซ็นผู้ดูแล (asign จาก 'รหัสผู้ดูแลศูนย์กลาง') ทำให้ศูนย์กลางยอมรับการสร้าง/แก้บทบาท/สิทธิ์/สถานะ/ลบ —
# เครื่องที่ไม่มีส่งได้แค่รหัสผ่านใหม่ของสมาชิกธรรมดา (เปลี่ยนรหัสตัวเอง/ลืมรหัส)
# v3.9.0: + teams = ทีมที่สังกัด [[ชื่อทีม, อัตราทีม], ...] (จัดจากเครื่อง Super Admin มีผลทุกเครื่อง)
MEMBER_FIELDS = ("username", "display_name", "role", "permissions", "active", "password_hash", "salt",
                 "rate_per_name", "created_at", "updated_at", "deleted", "rev", "teams")
REJECT_REASONS = ("auth", "conflict", "last_admin")
OLD_HUB_HINT = ("ศูนย์กลางรุ่นเก่า ยังไม่รองรับไดเรกทอรีสมาชิก — วาง tools/hub_gas.js รุ่น v3.7.0 ทับใน Apps Script "
                "แล้ว Deploy → Manage deployments → New version")


def build_members_payload(install_id, app_version, members):
    rows = [{k: m.get(k) for k in MEMBER_FIELDS}
            for m in (members or []) if isinstance(m, dict) and m.get("username")]
    return {
        "v": PAYLOAD_VERSION,
        "kind": "members",
        "install_id": str(install_id or ""),
        "app_version": str(app_version or ""),
        "sent_at": datetime.now().isoformat(timespec="seconds"),
        "members": rows,
    }


def sync_members(url, token, install_id, app_version="", members=None, admin_token=None):
    """ส่งสมาชิกที่เครื่องนี้แก้ + รับไดเรกทอรีทั้งองค์กรกลับมา — คืน dict ไม่โยน exception
    ผลลัพธ์: {"ok": True, "applied": n, "rejected": [{username, reason}], "admin": bool, "admin_ready": bool,
              "members": [...]} · members ถูกกรองผ่าน MEMBER_FIELDS อีกชั้น
    admin_token = 'รหัสผู้ดูแลศูนย์กลาง' ของเครื่องนี้ (ว่าง = ส่งได้แค่รหัสผ่านใหม่ของสมาชิกธรรมดา)"""
    if not url:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง URL ศูนย์กลาง"}
    payload = build_members_payload(install_id, app_version, members)
    try:
        res = _post(url, payload, token, admin_token=admin_token) if admin_token else _post(url, payload, token)
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"ศูนย์กลางตอบ {e.code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)[:150]}
    if not isinstance(res, dict) or not res.get("ok"):
        msg = (res or {}).get("error") if isinstance(res, dict) else "รูปแบบคำตอบไม่ถูกต้อง"
        return {"ok": False, "error": msg or "ศูนย์กลางปฏิเสธข้อมูล"}
    if not isinstance(res.get("members"), list):
        # สคริปต์รุ่นก่อน 3.7.0 ตอบ ok โดยไม่มี members — ต้องบอกผู้ดูแลให้อัปเดตสคริปต์ ไม่ใช่เงียบ
        return {"ok": False, "error": OLD_HUB_HINT}
    res["members"] = [{k: m.get(k) for k in MEMBER_FIELDS} for m in res["members"] if isinstance(m, dict)]
    res["rejected"] = [{"username": str(r.get("username") or ""), "reason": str(r.get("reason") or "")}
                       for r in (res.get("rejected") or []) if isinstance(r, dict) and r.get("reason") in REJECT_REASONS]
    res["admin"] = bool(res.get("admin"))
    res["admin_ready"] = bool(res.get("admin_ready"))
    res["sent"] = len(payload["members"])
    return res


# ──────────────── v3.9.0: สมุดกองกลางกลาง ────────────────
# ก้อน kind="ledger" — ส่งเฉพาะรายการที่เครื่องนี้เพิ่ม/ลบ (พร้อม rev ที่เห็นล่าสุด) + `after` = rev สูงสุดที่เครื่องนี้เคยรับ
# ศูนย์กลางรับการเปลี่ยนแปลงเฉพาะก้อนที่เซ็นด้วยรหัสผู้ดูแล (asign) แล้วตอบรายการที่ rev > after (ส่วนต่าง ไม่ใช่ทั้งเล่ม)
# + รายการที่เครื่องนี้เพิ่งส่ง (เพื่อจด rev) + `seq` = rev สูงสุดปัจจุบัน (เครื่องนี้จดไว้เป็น after รอบหน้า)
LEDGER_FIELDS = ("gid", "ts", "ym", "owner", "kind", "amount", "note", "created_by", "deleted", "rev")
LEDGER_REJECT_REASONS = ("auth", "conflict", "invalid")
OLD_HUB_LEDGER_HINT = ("ศูนย์กลางรุ่นเก่า ยังไม่รองรับสมุดกองกลางกลาง — ใน Apps Script ให้ลบโค้ดเดิมทั้งหมดแล้ววาง tools/hub_gas.js "
                       "รุ่นล่าสุดแทน (ใส่ HUB_TOKEN/ADMIN_TOKEN เดิม) → Deploy → Manage deployments → ✏ → Version: New version → Deploy "
                       "(ห้าม New deployment · URL ต้องเป็นอันเดิม) แล้วดู 'สคริปต์ศูนย์กลาง' ในหน้าตั้งค่าว่าขึ้นรุ่นใหม่")


def build_ledger_payload(install_id, app_version, entries, after=0):
    rows = [{k: e.get(k) for k in LEDGER_FIELDS}
            for e in (entries or []) if isinstance(e, dict) and e.get("gid")]
    return {
        "v": PAYLOAD_VERSION,
        "kind": "ledger",
        "install_id": str(install_id or ""),
        "app_version": str(app_version or ""),
        "sent_at": datetime.now().isoformat(timespec="seconds"),
        "after": int(after or 0),
        "entries": rows,
    }


def sync_ledger(url, token, install_id, app_version="", entries=None, after=0, admin_token=None):
    """ส่งรายการที่เครื่องนี้แก้ + รับส่วนต่างจากกลางกลับมา — คืน dict ไม่โยน exception
    ผลลัพธ์: {"ok": True, "applied": n, "rejected": [{gid, reason}], "admin": bool, "admin_ready": bool,
              "entries": [...], "seq": int, "full": bool, "sent": n} · entries ถูกกรองผ่าน LEDGER_FIELDS (+origin) อีกชั้น
    full=True = กลางส่งทั้งเล่ม (after=0 หรือ after เกินกว่าที่กลางเคยนับ — เปลี่ยนศูนย์กลาง/ชีตถูกสร้างใหม่)"""
    if not url:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง URL ศูนย์กลาง"}
    payload = build_ledger_payload(install_id, app_version, entries, after)
    try:
        res = _post(url, payload, token, admin_token=admin_token) if admin_token else _post(url, payload, token)
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"ศูนย์กลางตอบ {e.code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)[:150]}
    if not isinstance(res, dict) or not res.get("ok"):
        msg = (res or {}).get("error") if isinstance(res, dict) else "รูปแบบคำตอบไม่ถูกต้อง"
        return {"ok": False, "error": msg or "ศูนย์กลางปฏิเสธข้อมูล"}
    if not isinstance(res.get("entries"), list):
        return {"ok": False, "error": OLD_HUB_LEDGER_HINT}
    res["entries"] = [dict({k: e.get(k) for k in LEDGER_FIELDS}, origin=str(e.get("origin") or ""))
                      for e in res["entries"] if isinstance(e, dict)]
    res["rejected"] = [{"gid": str(r.get("gid") or ""), "reason": str(r.get("reason") or "")}
                       for r in (res.get("rejected") or []) if isinstance(r, dict) and r.get("reason") in LEDGER_REJECT_REASONS]
    res["admin"] = bool(res.get("admin"))
    res["admin_ready"] = bool(res.get("admin_ready"))
    try:
        res["seq"] = int(res.get("seq") or 0)
    except (TypeError, ValueError):
        res["seq"] = 0
    res["full"] = bool(res.get("full")) or int(after or 0) <= 0
    res["sent"] = len(payload["entries"])
    return res
