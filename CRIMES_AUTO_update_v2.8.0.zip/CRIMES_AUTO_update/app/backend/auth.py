"""Auth module — multi-user with roles, system config in config.json."""
import json
import os
import secrets
import threading

import db  # user auth now lives in SQLite
from config import CONFIG_PATH  # ไฟล์ตั้งค่าระบบ (กำหนดที่ backend/config.py)

# ล็อกครอบทุกการอ่าน-แก้-เขียน config.json — waitress รัน 8 เธรด การทำ
# read-modify-write พร้อมกันทำให้ค่าตั้งหาย (lost update) หรือไฟล์พังครึ่งเดียว
# ไฟล์นี้เก็บ secret_key ที่เป็นทั้ง Flask session key และ salt ของแฮชเลขบัตร
# (db._id_salt) — ถ้าพัง session หลุดทุกเครื่อง + hash เลขบัตรไม่ตรงกับประวัติเดิม
# ใช้ RLock เพราะ load_config อาจเรียก save_config ซ้อน (ตอนเติมคีย์ที่ขาด)
_CFG_LOCK = threading.RLock()


def _default_config():
    return {
        "secret_key": secrets.token_hex(32),
        "account": "",
        "display_name": "",
        "bind_host": "127.0.0.1",
        "port": 8770,
        "search_speed": 2,   # ระดับความเร็วการค้น 1(ช้าสุด)–5(เร็วสุด)
        # URL ตรวจสอบเวอร์ชันล่าสุด (ไฟล์ manifest .json) — ตั้งค่าเริ่มต้นไว้ให้เลย
        # ใช้ repo สาธารณะแยกสำหรับปล่อยอัปเดต (repo ซอร์สหลักเป็น private เลยดึง raw ไม่ได้)
        # ให้ตรงกับที่ manifest ชี้ไฟล์ .zip ไว้ (bng1689-dev/C-auto-updates)
        "update_url": "https://raw.githubusercontent.com/bng1689-dev/C-auto-updates/main/update-manifest.json",
        # รหัสประจำการติดตั้งนี้ — ผู้ใช้แจ้งให้ Admin ตอนขอ KEY เพื่อผูก KEY กับเครื่อง
        # สุ่มครั้งเดียวตอนสร้าง config แล้วคงที่ตลอด (ไม่ผูกกับ MAC ซึ่งเปลี่ยนได้)
        "install_id": secrets.token_hex(8),
        # กุญแจสาธารณะที่ใช้ตรวจ KEY อนุญาตอัปเดต (ได้จาก tools/keygen.py init)
        # ว่าง = ยังไม่เปิดใช้ระบบ KEY (อัปเดตได้ตามปกติ) — ตั้งค่าแล้วจึงเริ่มบังคับ
        "license_pubkey": {},
    }


def load_config():
    with _CFG_LOCK:
        existed = CONFIG_PATH.exists()
        if existed:
            try:
                cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            except Exception:
                cfg, existed = _default_config(), False
        else:
            cfg = _default_config()
        base = _default_config()
        changed = False
        for k, v in base.items():
            if k not in cfg:
                cfg[k] = v
                changed = True
        # persist ทันทีเมื่อสร้างไฟล์ครั้งแรก/เติมคีย์ที่ขาด — สำคัญมากกับ secret_key
        # ซึ่งใช้เป็นทั้ง Flask session key และ salt แฮชเลขบัตร (db._id_salt): ต้องคงที่
        # ข้ามการรีสตาร์ท ไม่งั้น session หลุดทุกครั้งที่เปิดใหม่ และ hash เลขบัตรไม่ตรงกัน
        if not existed or changed:
            try:
                save_config(cfg)
            except Exception:
                pass
        return cfg


def save_config(cfg):
    """เขียน config แบบ atomic (เขียนไฟล์ชั่วคราวแล้วสลับทับ) — ไฟดับ/แครชกลางคัน
    จะยังเหลือไฟล์เดิมที่สมบูรณ์ ไม่มีทางได้ไฟล์ครึ่งเดียว"""
    with _CFG_LOCK:
        tmp = CONFIG_PATH.with_name(CONFIG_PATH.name + ".tmp")
        tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, CONFIG_PATH)


def update_config(**kwargs):
    """อ่าน-แก้-เขียน config ในล็อกเดียว — ทุก endpoint ที่แก้ค่าตั้งต้องเรียกผ่านตัวนี้
    เท่านั้น (ห้าม load_config → แก้เอง → save_config แยกขั้น เพราะจะแพ้ race)
    คืน config ล่าสุดหลังบันทึก"""
    with _CFG_LOCK:
        cfg = load_config()
        cfg.update(kwargs)
        save_config(cfg)
        return cfg


def is_configured():
    return db.has_any_user()


def get_secret_key():
    return load_config()["secret_key"]
