"""CRIMES AUTO — Desktop launcher (pywebview)

เปิดแอปในหน้าต่างเดสก์ท็อปของตัวเอง (ไม่ต้องเปิดเบราว์เซอร์)
รัน Flask/Waitress ในเธรดเบื้องหลัง แล้วเปิดหน้าต่าง WebView ชี้มาที่เซิร์ฟเวอร์ในเครื่อง
"""
import os
import socket
import subprocess
import sys
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent

# บันทึกเหตุขัดข้องตอนเปิดโปรแกรม — อยู่ที่โฟลเดอร์ติดตั้ง (แม่ของ app/) หาเจอง่าย
CRASH_LOG = HERE.parent / "crash.log"


def _fatal(stage, exc):
    """โปรแกรมรันด้วย pythonw ซึ่งไม่มีคอนโซล — ถ้าพังตอนเปิด ผู้ใช้จะเห็นแค่
    'ดับเบิลคลิกแล้วไม่มีอะไรขึ้นเลย' และไม่มีใครรู้สาเหตุ จึงต้อง (1) เขียนลงไฟล์
    crash.log เสมอ และ (2) เด้งกล่องข้อความบอกทันที แล้วค่อยจบโปรเซส"""
    detail = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    stamp = datetime.now().isoformat(timespec="seconds")
    try:
        with open(CRASH_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n===== {stamp} · เปิดโปรแกรมไม่สำเร็จ (ขั้นตอน: {stage}) =====\n{detail}")
    except OSError:
        pass
    msg = (f"เปิด CRIMES AUTO ไม่สำเร็จ (ขั้นตอน: {stage})\n\n"
           f"{type(exc).__name__}: {exc}\n\n"
           f"รายละเอียดถูกบันทึกไว้ที่:\n{CRASH_LOG}\n\n"
           "ส่งไฟล์นี้ให้ผู้ดูแลระบบเพื่อแก้ไข")
    try:
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, msg, "CRIMES AUTO", 0x00000010)
        else:
            print(msg, file=sys.stderr)
    except Exception:
        pass
    sys.exit(1)


sys.path.insert(0, str(HERE / "backend"))

# import คือจุดที่พังบ่อยสุดหลังอัปเดต (ไฟล์ขาด/ไม่ครบ/ฐานข้อมูล migrate ไม่ผ่าน)
# ต้องห่อไว้ ไม่งั้น pythonw ตายเงียบโดยไม่ทิ้งร่องรอยอะไรเลย
try:
    import config  # noqa: E402  (ตั้งค่า path ของ backend)
    import server  # noqa: E402  (Flask app — import จะ init_db ให้อัตโนมัติ)
except Exception as _e:  # noqa: BLE001
    _fatal("โหลดโปรแกรม (import backend)", _e)

try:
    import webview  # noqa: E402
except Exception as _e:  # noqa: BLE001
    _fatal("โหลดตัวแสดงหน้าต่าง (pywebview)", _e)

HOST = "127.0.0.1"
PORT = 8770


def _relaunch_after_exit():
    """สั่งให้เปิดโปรแกรมใหม่หลังโปรเซสนี้จบ (ใช้ตอนอัปเดตเสร็จ) — ผ่านตัวช่วย PowerShell แบบแยกอิสระ"""
    pid = os.getpid()
    exe = sys.executable                      # pythonw.exe ของ runtime
    script = str(HERE / "desktop.py")         # ตัวแอป (เวอร์ชันใหม่หลังอัปเดต)
    ps = (
        f"try{{ Wait-Process -Id {pid} -Timeout 30 -ErrorAction SilentlyContinue }}catch{{}}; "
        f"Start-Sleep -Milliseconds 600; "
        f"Start-Process -FilePath '{exe}' -ArgumentList '\"{script}\"' -WorkingDirectory '{HERE}'"
    )
    # DETACHED_PROCESS | CREATE_NO_WINDOW = แยกอิสระ ไม่มีหน้าต่าง
    flags = 0x00000008 | 0x08000000
    subprocess.Popen(
        ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
        creationflags=flags, close_fds=True,
    )


def _do_restart():
    """รีสตาร์ทแอปอัตโนมัติ: เตรียมตัวเปิดใหม่ → ปิดหน้าต่าง/จบโปรเซส → ตัวช่วยเปิดแอปใหม่"""
    try:
        _relaunch_after_exit()
    except Exception as e:  # pragma: no cover
        print("relaunch error:", e)
    try:
        for w in list(webview.windows):
            w.destroy()
    except Exception:
        pass
    # เผื่อหน้าต่างปิดแล้วโปรเซสยังไม่จบ (เช่นโหมด fallback เบราว์เซอร์) → บังคับออกหลังหน่วงสั้นๆ
    threading.Timer(2.0, lambda: os._exit(0)).start()


def _find_icon():
    """หาไฟล์ icon.ico: โฟลเดอร์ติดตั้ง (แม่ของ app/) ก่อน แล้วค่อยข้างๆ desktop.py"""
    for p in (HERE.parent / "icon.ico", HERE / "icon.ico"):
        if p.exists():
            return str(p)
    return None


def _apply_window_icon(window):
    """ตั้งไอคอนหน้าต่าง/taskbar (WinForms บน Windows) — พลาดก็ข้าม ไม่กระทบการทำงาน"""
    try:
        icon_path = _find_icon()
        if not icon_path:
            return
        import clr  # pythonnet มากับ pywebview[winforms]
        clr.AddReference("System.Drawing")
        from System.Drawing import Icon
        window.native.Icon = Icon(icon_path)
    except Exception:
        pass


_serve_error = [None]     # เก็บเหตุที่เซิร์ฟเวอร์ล้ม เพื่อรายงานให้ผู้ใช้เห็น (pythonw ไม่มีคอนโซล)


def _serve():
    try:
        from waitress import serve
        serve(server.app, host=HOST, port=PORT, threads=8)
    except Exception as e:  # pragma: no cover
        _serve_error[0] = e
        try:
            with open(CRASH_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n===== {datetime.now().isoformat(timespec='seconds')}"
                        f" · เซิร์ฟเวอร์ภายในล้ม =====\n")
                traceback.print_exc(file=f)
        except OSError:
            pass


def _port_open(timeout=0.5):
    try:
        with socket.create_connection((HOST, PORT), timeout=timeout):
            return True
    except OSError:
        return False


def _wait_ready(timeout=25):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if _port_open(1):
            return True
        time.sleep(0.2)
    return False


def main():
    # ถ้าพอร์ตยังว่าง = ยังไม่มีเซิร์ฟเวอร์ → สตาร์ทเอง; ถ้ามีอยู่แล้วก็เปิดหน้าต่างชี้ไปที่เดิม
    if not _port_open():
        threading.Thread(target=_serve, daemon=True).start()
        if not _wait_ready():
            # เซิร์ฟเวอร์สตาร์ทไม่ขึ้น — เดิมจะเปิดหน้าต่างขาวค้างโดยไม่บอกอะไร
            err = _serve_error[0] or RuntimeError(
                f"เซิร์ฟเวอร์ภายในไม่ตอบที่พอร์ต {PORT} ภายในเวลาที่กำหนด — "
                "พอร์ตอาจถูกโปรแกรมอื่นใช้ หรือถูกไฟร์วอลล์บล็อก")
            _fatal("เปิดเซิร์ฟเวอร์ภายใน", err)
    # ให้เซิร์ฟเวอร์รีสตาร์ทแอปเองได้หลังอัปเดตออนไลน์
    server.RESTART_HOOK = _do_restart
    url = f"http://{HOST}:{PORT}"
    try:
        # เปิดให้ WebView2 ดาวน์โหลดไฟล์ได้ (ค่าเริ่มต้นเป็น False = กดปุ่ม Download แล้วเงียบ)
        webview.settings["ALLOW_DOWNLOADS"] = True
        win = webview.create_window(
            "CRIMES AUTO", url,
            width=1280, height=820, min_size=(960, 640),
        )
        win.events.shown += lambda: _apply_window_icon(win)
        webview.start()
    except Exception as e:
        # เครื่องปลายทางอาจไม่มี WebView2 runtime → เปิดด้วยเบราว์เซอร์เริ่มต้นแทน (ใช้งานได้ครบเหมือนกัน)
        import webbrowser
        print(f"[!] เปิดหน้าต่างแอปไม่ได้ ({e}) — เปิดด้วยเบราว์เซอร์เริ่มต้นแทน: {url}")
        webbrowser.open(url)
        try:
            while _port_open(1):
                time.sleep(1)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as _e:  # noqa: BLE001
        _fatal("เปิดหน้าต่างโปรแกรม", _e)
