"""ส่ง "ตัวเลขนับ" ขึ้นศูนย์กลาง (Google Apps Script) — ไม่ส่งข้อมูลประวัติใด ๆ

ขอบเขตที่ตกลงไว้ และห้ามขยายโดยไม่ได้รับอนุมัติ
────────────────────────────────────────────────
ส่งออกได้:   จำนวนการค้นรายวันรายคน (รวม/พบ/ไม่พบ/ผิดพลาด) · จำนวนไฟล์ · ยอดรับ/จ่าย
             · ชื่อที่แสดงของผู้ใช้ · รหัสติดตั้งของเครื่อง
ห้ามส่งเด็ดขาด: เลขบัตรประชาชน · ชื่อผู้ถูกค้น · รายละเอียดคดี/ผลการค้น · ชื่อไฟล์งาน
             · ชื่อผู้ใช้สำหรับล็อกอิน · รหัสผ่าน/PASSCODE/KEY

payload ถูกประกอบจาก ALLOWED_FIELDS เท่านั้น (ไม่ใช่ "เอาทั้ง row แล้วลบบางคอลัมน์")
เพราะการเพิ่มคอลัมน์ใหม่ในฐานข้อมูลวันหลังจะได้ไม่หลุดออกไปเองโดยไม่ตั้งใจ
"""
import hashlib
import hmac
import json
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

import db

# คีย์ทุกตัวที่อนุญาตให้อยู่ในแถวข้อมูลที่ส่งออก — มีเท่านี้ ไม่มีมากกว่านี้
ALLOWED_FIELDS = ("date", "uid", "display_name", "searches", "found",
                  "notfound", "error", "files", "amount_in", "amount_out")
PAYLOAD_VERSION = 1
TIMEOUT = 15


class _KeepPostRedirect(urllib.request.HTTPRedirectHandler):
    """คง method เดิมไว้ตอนถูก redirect

    Apps Script ตอบ 302 จาก /exec ไปยัง script.googleusercontent.com เสมอ
    ตัว urllib มาตรฐานจะเปลี่ยน POST เป็น GET ตอนตาม redirect ทำให้เนื้อข้อมูลหายเงียบ ๆ
    และฝั่ง Apps Script จะได้ doGet แทน doPost โดยไม่มีใครรู้ว่าพลาด
    """

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        newreq = super().redirect_request(req, fp, code, msg, headers, newurl)
        if newreq is not None and req.get_method() == "POST":
            newreq = urllib.request.Request(
                newurl, data=req.data, headers=dict(req.header_items()), method="POST")
        return newreq


def sign(body_bytes, token):
    return hmac.new(str(token or "").encode("utf-8"), body_bytes, hashlib.sha256).hexdigest()


def collect_rows(ym):
    """รวบรวมตัวเลขของเดือนนี้จากฐานข้อมูลในเครื่อง — อ่านอย่างเดียว ไม่แตะข้อมูลจริง"""
    people = {u["id"]: (u["display_name"] or u["username"]) for u in db.list_users()}
    daily = {}
    with db.get_conn() as c:
        for r in c.execute(
            "SELECT substr(ts,1,10) d, user_id,"
            " COUNT(*) n,"
            " SUM(outcome='found') f,"
            " SUM(outcome='notfound') nf,"
            " SUM(outcome='error') e,"
            " COUNT(DISTINCT file) nfiles"
            " FROM searches WHERE ym=? GROUP BY d, user_id", (ym,)
        ).fetchall():
            daily[(r["d"], r["user_id"])] = {
                "searches": r["n"], "found": r["f"] or 0,
                "notfound": r["nf"] or 0, "error": r["e"] or 0,
                # นับจำนวนไฟล์เท่านั้น — ชื่อไฟล์ไม่ออกจากเครื่อง
                "files": r["nfiles"] or 0,
            }
        for r in c.execute(
            "SELECT substr(ts,1,10) d, user_id, kind, COALESCE(SUM(amount),0) total"
            " FROM ledger WHERE ym=? GROUP BY d, user_id, kind", (ym,)
        ).fetchall():
            slot = daily.setdefault((r["d"], r["user_id"]),
                                    {"searches": 0, "found": 0, "notfound": 0,
                                     "error": 0, "files": 0})
            slot["amount_in" if r["kind"] == "in" else "amount_out"] = round(r["total"], 2)

    rows = []
    for (d, uid), vals in sorted(daily.items()):
        row = {"date": d, "uid": int(uid), "display_name": people.get(uid, "")}
        row.update(vals)
        rows.append({k: row.get(k, 0) for k in ALLOWED_FIELDS})
    return rows


def build_payload(ym, install_id, app_version=""):
    """สร้างก้อนข้อมูลที่จะส่ง — ทุกแถวถูกกรองผ่าน ALLOWED_FIELDS อีกชั้นก่อนออก"""
    rows = []
    for r in collect_rows(ym):
        rows.append({k: r[k] for k in ALLOWED_FIELDS if k in r})
    return {
        "v": PAYLOAD_VERSION,
        "install_id": str(install_id or ""),
        "app_version": str(app_version or ""),
        "ym": ym,
        "sent_at": datetime.now().isoformat(timespec="seconds"),
        "rows": rows,
    }


def _with_query(url, extra):
    return url + ("&" if "?" in url else "?") + urllib.parse.urlencode(extra)


def _post(url, payload, token):
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    # ลายเซ็นต้องไปกับ query string ไม่ใช่ header — Apps Script อ่าน header ที่ผู้เรียก
    # กำหนดเองไม่ได้เลย (เห็นแค่ e.parameter กับ e.postData) ถ้าใส่ใน header จะไม่มีวันถึงปลายทาง
    req = urllib.request.Request(
        _with_query(url, {"sign": sign(body, token)}), data=body, method="POST",
        headers={
            # Apps Script อ่านตัวข้อมูลดิบจาก e.postData.contents — ใช้ text/plain
            # เพื่อไม่ให้ถูกตีความเป็นฟอร์ม
            "Content-Type": "text/plain;charset=utf-8",
            "User-Agent": "CRIMES-AUTO-Hub",
        })
    opener = urllib.request.build_opener(_KeepPostRedirect)
    with opener.open(req, timeout=TIMEOUT) as r:
        raw = r.read().decode("utf-8", "replace")
    try:
        return json.loads(raw)
    except ValueError:
        return {"ok": False, "error": "ศูนย์กลางตอบกลับไม่ใช่ JSON: " + raw[:150]}


def push(url, token, ym, install_id, app_version=""):
    """ส่งตัวเลขขึ้นศูนย์กลาง — คืน dict {"ok":bool, ...} ไม่โยน exception ออกไป

    ตัวส่งทำงานเบื้องหลัง ความล้มเหลวจึงต้องไม่ทำให้โปรแกรมหลักสะดุด
    """
    if not url:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง URL ศูนย์กลาง"}
    payload = build_payload(ym, install_id, app_version)
    try:
        res = _post(url, payload, token)
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"ศูนย์กลางตอบ {e.code}"}
    except Exception as e:                       # เน็ตหลุด/DNS/timeout — เก็บไว้ส่งรอบหน้า
        return {"ok": False, "error": str(e)[:150]}
    if not isinstance(res, dict) or not res.get("ok"):
        msg = (res or {}).get("error") if isinstance(res, dict) else "รูปแบบคำตอบไม่ถูกต้อง"
        return {"ok": False, "error": msg or "ศูนย์กลางปฏิเสธข้อมูล"}
    res["rows_sent"] = len(payload["rows"])
    return res


def fetch_board(url, token, ym):
    """ดึงยอดรวมของทุกเครื่องจากศูนย์กลาง (อ่านอย่างเดียว)"""
    if not url:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง URL ศูนย์กลาง"}
    q = _with_query(url, {"action": "board", "ym": ym,
                          "sign": sign(f"board:{ym}".encode("utf-8"), token)})
    req = urllib.request.Request(q, headers={"User-Agent": "CRIMES-AUTO-Hub"})
    try:
        opener = urllib.request.build_opener(_KeepPostRedirect)
        with opener.open(req, timeout=TIMEOUT) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        return {"ok": False, "error": str(e)[:150]}
