"""ส่ง "ตัวเลขนับ" ขึ้นศูนย์กลาง (Google Apps Script) — ไม่ส่งข้อมูลประวัติใด ๆ

ขอบเขตที่ตกลงไว้ และห้ามขยายโดยไม่ได้รับอนุมัติ
────────────────────────────────────────────────
ส่งออกได้:   จำนวนการค้นรายวันรายคน (รวม/พบ/ไม่พบ/ผิดพลาด) · จำนวนไฟล์ · ยอดรับ/จ่าย
             · ชื่อที่แสดงของผู้ใช้ · รหัสติดตั้งของเครื่อง
             · (v3.2.0) เวอร์ชันโปรแกรมและเวลาใช้งานล่าสุดของแต่ละคน — เพื่อให้ผู้ดูแลเห็นว่า
               สมาชิกเครื่องไหนใช้ Ver. ไหน/ออนไลน์อยู่ไหม แบบเรียลไทม์
             · (v3.7.0 — เจ้าของโปรเจกต์อนุมัติ) ไดเรกทอรีสมาชิกกลาง: ชื่อผู้ใช้สำหรับล็อกอิน ·
               ชื่อที่แสดง · บทบาท · สิทธิ์ · สถานะ · รหัสผ่านแบบแฮช pbkdf2+salt (ไม่ใช่รหัสผ่านจริง) ·
               อัตราค่าบริการ · เวลาสร้าง/แก้ — เพื่อให้สมาชิกเข้าได้ทุกเครื่องที่ติดตั้ง
ห้ามส่งเด็ดขาด: เลขบัตรประชาชน · ชื่อผู้ถูกค้น · รายละเอียดคดี/ผลการค้น · ชื่อไฟล์งาน
             · รหัสผ่านตัวจริง · PASSCODE (ผูก secret ของเครื่อง) · KEY

payload ถูกประกอบจาก ALLOWED_FIELDS / PRESENCE_FIELDS / MEMBER_FIELDS เท่านั้น
(ไม่ใช่ "เอาทั้ง row แล้วลบบางคอลัมน์") เพราะการเพิ่มคอลัมน์ใหม่ในฐานข้อมูลวันหลังจะได้ไม่หลุดออกไปเอง
"""
import base64
import hashlib
import hmac
import json
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

import db

# คีย์ทุกตัวที่อนุญาตให้อยู่ในแถวข้อมูลที่ส่งออก — มีเท่านี้ ไม่มีมากกว่านี้
ALLOWED_FIELDS = ("date", "uid", "display_name", "searches", "found",
                  "notfound", "error", "files", "amount_in", "amount_out")
# v3.2.0: ข้อมูล "ตัวตน/สถานะ" ของสมาชิกที่ส่งขึ้นศูนย์กลาง — มีเท่านี้เช่นกัน
PRESENCE_FIELDS = ("uid", "display_name", "app_version", "last_seen")
PAYLOAD_VERSION = 2
CONNECT_PREFIX = "CRIMES-HUB:"
TIMEOUT = 15


class _KeepPostRedirect(urllib.request.HTTPRedirectHandler):
    """ตาม redirect ของ Apps Script ให้ถูกชนิด

    Apps Script ตอบ 302 จาก /exec สองแบบ:
    • ไปที่ script.googleusercontent.com (…/macros/echo?user_content_key=…) = สคริปต์ทำงาน 'เสร็จแล้ว' นี่คือที่รับผล
      ต้องตามด้วย GET แบบไม่มี body (มาตรฐานของเบราว์เซอร์) — v3.8.1: POST ซ้ำไปที่นี่ Google ตอบ 405 ได้
    • ไปที่ script.google.com อีก URL (เช่น /a/macros/<โดเมน>/… ของบัญชีองค์กร) = ยังไม่ถึงสคริปต์
      ต้องคง POST + body ไว้ ไม่งั้นฝั่ง Apps Script ได้ doGet แทน doPost และเนื้อข้อมูลหายเงียบ ๆ
    keep_post=True = พฤติกรรมเดิมก่อน v3.8.1 (คง POST ทุกกรณี) ใช้เป็นแผนสำรองถ้าแบบใหม่ถูกปฏิเสธ
    """
    keep_post = False

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        newreq = super().redirect_request(req, fp, code, msg, headers, newurl)
        if newreq is None or req.get_method() != "POST":
            return newreq
        host = (urllib.parse.urlsplit(newurl).hostname or "").lower()
        if host.endswith("googleusercontent.com") and not self.keep_post:
            return newreq                                   # GET ไม่มี body — รับผลที่สคริปต์ตอบไว้แล้ว
        return urllib.request.Request(newurl, data=req.data, headers=dict(req.header_items()), method="POST")


class _AlwaysPostRedirect(_KeepPostRedirect):
    keep_post = True


def sign(body_bytes, token):
    return hmac.new(str(token or "").encode("utf-8"), body_bytes, hashlib.sha256).hexdigest()


def collect_rows(ym):
    """รวบรวมตัวเลขของเดือนนี้จากฐานข้อมูลในเครื่อง — อ่านอย่างเดียว ไม่แตะข้อมูลจริง"""
    # ไม่มีชื่อที่แสดง → ใช้ "ผู้ใช้ #id" (ห้ามถอยไปใช้ชื่อล็อกอิน)
    people = {u["id"]: (u["display_name"] or f"ผู้ใช้ #{u['id']}") for u in db.list_users()}
    daily = {}
    with db.get_conn() as c:
        for r in c.execute(
            "SELECT substr(ts,1,10) d, user_id,"
            " COUNT(*) n,"
            " SUM(outcome='found') f,"
            " SUM(outcome='notfound') nf,"
            " SUM(outcome='error') e,"
            " COUNT(DISTINCT file) nfiles"
            " FROM searches WHERE ym=? GROUP BY d, user_id", (ym,)
        ).fetchall():
            daily[(r["d"], r["user_id"])] = {
                "searches": r["n"], "found": r["f"] or 0,
                "notfound": r["nf"] or 0, "error": r["e"] or 0,
                # นับจำนวนไฟล์เท่านั้น — ชื่อไฟล์ไม่ออกจากเครื่อง
                "files": r["nfiles"] or 0,
            }
        for r in c.execute(
            "SELECT substr(ts,1,10) d, user_id, kind, COALESCE(SUM(amount),0) total"
            " FROM ledger WHERE ym=? GROUP BY d, user_id, kind", (ym,)
        ).fetchall():
            slot = daily.setdefault((r["d"], r["user_id"]),
                                    {"searches": 0, "found": 0, "notfound": 0,
                                     "error": 0, "files": 0})
            slot["amount_in" if r["kind"] == "in" else "amount_out"] = round(r["total"], 2)

    rows = []
    for (d, uid), vals in sorted(daily.items()):
        row = {"date": d, "uid": int(uid), "display_name": people.get(uid, "")}
        row.update(vals)
        rows.append({k: row.get(k, 0) for k in ALLOWED_FIELDS})
    return rows


def collect_presence():
    """รายชื่อ+เวอร์ชัน+เวลาใช้งานล่าสุด — กรองผ่าน PRESENCE_FIELDS เท่านั้น"""
    return [{k: r.get(k, "") for k in PRESENCE_FIELDS} for r in db.presence_rows()]


def build_payload(ym, install_id, app_version=""):
    """สร้างก้อนข้อมูลที่จะส่ง — ทุกแถวถูกกรองผ่าน ALLOWED_FIELDS อีกชั้นก่อนออก"""
    rows = []
    for r in collect_rows(ym):
        rows.append({k: r[k] for k in ALLOWED_FIELDS if k in r})
    return {
        "v": PAYLOAD_VERSION,
        "kind": "counts",
        "install_id": str(install_id or ""),
        "app_version": str(app_version or ""),
        "ym": ym,
        "sent_at": datetime.now().isoformat(timespec="seconds"),
        "rows": rows,
        "users": collect_presence(),
    }


def build_presence_payload(install_id, app_version=""):
    """ก้อนสถานะอย่างเดียว (ไม่มี rows) — ศูนย์กลางต้องไม่ลบตัวเลขเดือนเมื่อได้รับก้อนนี้"""
    return {
        "v": PAYLOAD_VERSION,
        "kind": "presence",
        "install_id": str(install_id or ""),
        "app_version": str(app_version or ""),
        "sent_at": datetime.now().isoformat(timespec="seconds"),
        "users": collect_presence(),
    }


# ──────────────── v3.2.0: รหัสเชื่อมต่อ (URL+รหัสลับ ในสตริงเดียว) ────────────────
def make_connect_code(url, token):
    """ให้ผู้ดูแลคัดลอกไปแจกสมาชิก — วางตอนสมัครใช้งานแล้วเครื่องนั้นเชื่อมศูนย์กลางทันที
    (มีรหัสลับอยู่ข้างใน จึงต้องส่งให้เฉพาะคนในหน่วยงาน ไม่โพสต์สาธารณะ)"""
    raw = json.dumps({"url": str(url or ""), "token": str(token or "")},
                     separators=(",", ":")).encode("utf-8")
    return CONNECT_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def parse_connect_code(code):
    """คืน (url, token) หรือ None ถ้ารหัสไม่ถูกต้อง"""
    s = "".join(str(code or "").split())
    if len(s) > 4096 or not s.startswith(CONNECT_PREFIX):
        return None
    b = s[len(CONNECT_PREFIX):]
    try:
        raw = base64.urlsafe_b64decode(b + "=" * (-len(b) % 4))
        d = json.loads(raw.decode("utf-8"))
        if not isinstance(d, dict):
            return None
        url, token = str(d.get("url") or "").strip(), str(d.get("token") or "")
    except (ValueError, TypeError, UnicodeDecodeError, AttributeError):
        return None
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in url + token):
        return None
    # รหัสเชื่อมต่อใช้ได้กับศูนย์กลาง Apps Script เท่านั้น — รหัสปลอมจะพาตัวเลขไปที่อื่นไม่ได้
    if not url.startswith("https://script.google.com/macros/") or not token:
        return None
    return url, token


def _with_query(url, extra):
    return url + ("&" if "?" in url else "?") + urllib.parse.urlencode(extra)


def _post(url, payload, token, admin_token=None):
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    # ลายเซ็นต้องไปกับ query string ไม่ใช่ header — Apps Script อ่าน header ที่ผู้เรียก
    # กำหนดเองไม่ได้เลย (เห็นแค่ e.parameter กับ e.postData) ถ้าใส่ใน header จะไม่มีวันถึงปลายทาง
    q = {"sign": sign(body, token)}
    if admin_token:
        q["asign"] = sign(body, admin_token)       # v3.7.0: ลายเซ็นผู้ดูแล — ศูนย์กลางจึงยอมให้แก้ไดเรกทอรีสมาชิก
    def _request():
        return urllib.request.Request(
            _with_query(url, q), data=body, method="POST",
            headers={
                # Apps Script อ่านตัวข้อมูลดิบจาก e.postData.contents — ใช้ text/plain
                # เพื่อไม่ให้ถูกตีความเป็นฟอร์ม
                "Content-Type": "text/plain;charset=utf-8",
                "User-Agent": "CRIMES-AUTO-Hub",
            })
    try:
        with urllib.request.build_opener(_KeepPostRedirect).open(_request(), timeout=TIMEOUT) as r:
            raw = r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        # v3.8.1: ถ้า Google ปฏิเสธวิธีตาม redirect แบบใหม่ (405) ลองแบบเดิม (คง POST ทุกกรณี) อีกครั้งเดียว
        # — สคริปต์ทำงานไปแล้วในคำขอแรก การส่งซ้ำแค่ไปรับผล ไม่ได้ทำให้ตัวเลขถูกบวกสองรอบ (ส่งเป็นภาพรวมทั้งเดือน)
        if e.code != 405:
            raise
        with urllib.request.build_opener(_AlwaysPostRedirect).open(_request(), timeout=TIMEOUT) as r:
            raw = r.read().decode("utf-8", "replace")
    try:
        return json.loads(raw)
    except ValueError:
        return {"ok": False, "error": "ศูนย์กลางตอบกลับไม่ใช่ JSON: " + raw[:150]}


def push(url, token, ym, install_id, app_version="", presence_only=False):
    """ส่งตัวเลขขึ้นศูนย์กลาง — คืน dict {"ok":bool, ...} ไม่โยน exception ออกไป

    ตัวส่งทำงานเบื้องหลัง ความล้มเหลวจึงต้องไม่ทำให้โปรแกรมหลักสะดุด
    presence_only=True ส่งเฉพาะสถานะ (ใครออนไลน์/เวอร์ชันไหน) — เบาและถี่ได้
    """
    if not url:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง URL ศูนย์กลาง"}
    payload = (build_presence_payload(install_id, app_version) if presence_only
               else build_payload(ym, install_id, app_version))
    try:
        res = _post(url, payload, token)
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"ศูนย์กลางตอบ {e.code}"}
    except Exception as e:                       # เน็ตหลุด/DNS/timeout — เก็บไว้ส่งรอบหน้า
        return {"ok": False, "error": str(e)[:150]}
    if not isinstance(res, dict) or not res.get("ok"):
        msg = (res or {}).get("error") if isinstance(res, dict) else "รูปแบบคำตอบไม่ถูกต้อง"
        return {"ok": False, "error": msg or "ศูนย์กลางปฏิเสธข้อมูล"}
    res["rows_sent"] = len(payload.get("rows") or [])
    return res


def fetch_board(url, token, ym):
    """ดึงยอดรวมของทุกเครื่องจากศูนย์กลาง (อ่านอย่างเดียว)"""
    if not url:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง URL ศูนย์กลาง"}
    q = _with_query(url, {"action": "board", "ym": ym,
                          "sign": sign(f"board:{ym}".encode("utf-8"), token)})
    req = urllib.request.Request(q, headers={"User-Agent": "CRIMES-AUTO-Hub"})
    try:
        opener = urllib.request.build_opener(_KeepPostRedirect)
        with opener.open(req, timeout=TIMEOUT) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        return {"ok": False, "error": str(e)[:150]}


# ──────────────── v3.7.0: ไดเรกทอรีสมาชิกกลาง ────────────────
# ก้อน kind="members" — ส่งเฉพาะสมาชิกที่เครื่องนี้แก้ (พร้อม rev ที่เห็นล่าสุด) ศูนย์กลางตัดสินว่ารับหรือไม่
# แล้วตอบกลับไดเรกทอรีทั้งองค์กร + รายการที่ปัดตกในคำขอเดียว (เครื่องนี้เอาไปปรับสมาชิกในเครื่อง — db.apply_remote_members)
# ลายเซ็นผู้ดูแล (asign จาก 'รหัสผู้ดูแลศูนย์กลาง') ทำให้ศูนย์กลางยอมรับการสร้าง/แก้บทบาท/สิทธิ์/สถานะ/ลบ —
# เครื่องที่ไม่มีส่งได้แค่รหัสผ่านใหม่ของสมาชิกธรรมดา (เปลี่ยนรหัสตัวเอง/ลืมรหัส)
MEMBER_FIELDS = ("username", "display_name", "role", "permissions", "active", "password_hash", "salt",
                 "rate_per_name", "created_at", "updated_at", "deleted", "rev")
REJECT_REASONS = ("auth", "conflict", "last_admin")
OLD_HUB_HINT = ("ศูนย์กลางรุ่นเก่า ยังไม่รองรับไดเรกทอรีสมาชิก — วาง tools/hub_gas.js รุ่น v3.7.0 ทับใน Apps Script "
                "แล้ว Deploy → Manage deployments → New version")


def build_members_payload(install_id, app_version, members):
    rows = [{k: m.get(k) for k in MEMBER_FIELDS}
            for m in (members or []) if isinstance(m, dict) and m.get("username")]
    return {
        "v": PAYLOAD_VERSION,
        "kind": "members",
        "install_id": str(install_id or ""),
        "app_version": str(app_version or ""),
        "sent_at": datetime.now().isoformat(timespec="seconds"),
        "members": rows,
    }


def sync_members(url, token, install_id, app_version="", members=None, admin_token=None):
    """ส่งสมาชิกที่เครื่องนี้แก้ + รับไดเรกทอรีทั้งองค์กรกลับมา — คืน dict ไม่โยน exception
    ผลลัพธ์: {"ok": True, "applied": n, "rejected": [{username, reason}], "admin": bool, "admin_ready": bool,
              "members": [...]} · members ถูกกรองผ่าน MEMBER_FIELDS อีกชั้น
    admin_token = 'รหัสผู้ดูแลศูนย์กลาง' ของเครื่องนี้ (ว่าง = ส่งได้แค่รหัสผ่านใหม่ของสมาชิกธรรมดา)"""
    if not url:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง URL ศูนย์กลาง"}
    payload = build_members_payload(install_id, app_version, members)
    try:
        res = _post(url, payload, token, admin_token=admin_token) if admin_token else _post(url, payload, token)
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"ศูนย์กลางตอบ {e.code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)[:150]}
    if not isinstance(res, dict) or not res.get("ok"):
        msg = (res or {}).get("error") if isinstance(res, dict) else "รูปแบบคำตอบไม่ถูกต้อง"
        return {"ok": False, "error": msg or "ศูนย์กลางปฏิเสธข้อมูล"}
    if not isinstance(res.get("members"), list):
        # สคริปต์รุ่นก่อน 3.7.0 ตอบ ok โดยไม่มี members — ต้องบอกผู้ดูแลให้อัปเดตสคริปต์ ไม่ใช่เงียบ
        return {"ok": False, "error": OLD_HUB_HINT}
    res["members"] = [{k: m.get(k) for k in MEMBER_FIELDS} for m in res["members"] if isinstance(m, dict)]
    res["rejected"] = [{"username": str(r.get("username") or ""), "reason": str(r.get("reason") or "")}
                       for r in (res.get("rejected") or []) if isinstance(r, dict) and r.get("reason") in REJECT_REASONS]
    res["admin"] = bool(res.get("admin"))
    res["admin_ready"] = bool(res.get("admin_ready"))
    res["sent"] = len(payload["members"])
    return res
