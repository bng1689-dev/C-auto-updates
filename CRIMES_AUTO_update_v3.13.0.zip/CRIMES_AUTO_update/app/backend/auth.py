"""Auth module — multi-user with roles, system config in config.json."""
import hashlib
import hmac
import json
import os
import secrets
import threading

import db  # user auth now lives in SQLite
from config import CONFIG_PATH, DEFAULT_HUB_TOKEN, DEFAULT_HUB_URL, OLD_HUB_URLS  # ไฟล์ตั้งค่าระบบ (backend/config.py)

# ล็อกครอบทุกการอ่าน-แก้-เขียน config.json — waitress รัน 8 เธรด การทำ
# read-modify-write พร้อมกันทำให้ค่าตั้งหาย (lost update) หรือไฟล์พังครึ่งเดียว
# ไฟล์นี้เก็บ secret_key ที่เป็นทั้ง Flask session key และ salt ของแฮชเลขบัตร
# (db._id_salt) — ถ้าพัง session หลุดทุกเครื่อง + hash เลขบัตรไม่ตรงกับประวัติเดิม
# ใช้ RLock เพราะ load_config อาจเรียก save_config ซ้อน (ตอนเติมคีย์ที่ขาด)
_CFG_LOCK = threading.RLock()
# v3.13.0: รหัสผู้ดูแลที่ถอดออกจาก config.json รุ่นก่อน — อยู่ในหน่วยความจำของโปรเซสนี้เท่านั้น (ดู load_config)
_LEGACY_ADMIN_TOKEN = [""]


def _default_config():
    return {
        "secret_key": secrets.token_hex(32),
        "account": "",
        "display_name": "",
        "bind_host": "127.0.0.1",
        "port": 8770,
        "search_speed": 2,   # ระดับความเร็วการค้น 1(ช้าสุด)–5(เร็วสุด)
        # URL ตรวจสอบเวอร์ชันล่าสุด (ไฟล์ manifest .json) — ตั้งค่าเริ่มต้นไว้ให้เลย
        # ใช้ repo สาธารณะแยกสำหรับปล่อยอัปเดต (repo ซอร์สหลักเป็น private เลยดึง raw ไม่ได้)
        # ให้ตรงกับที่ manifest ชี้ไฟล์ .zip ไว้ (bng1689-dev/C-auto-updates)
        "update_url": "https://raw.githubusercontent.com/bng1689-dev/C-auto-updates/main/update-manifest.json",
        # รหัสประจำการติดตั้งนี้ — ผู้ใช้แจ้งให้ Admin ตอนขอ KEY เพื่อผูก KEY กับเครื่อง
        # สุ่มครั้งเดียวตอนสร้าง config แล้วคงที่ตลอด (ไม่ผูกกับ MAC ซึ่งเปลี่ยนได้)
        "install_id": secrets.token_hex(8),
        # กุญแจสาธารณะที่ใช้ตรวจ KEY อนุญาตอัปเดต (ได้จาก tools/keygen.py init)
        # ว่าง = ยังไม่เปิดใช้ระบบ KEY (อัปเดตได้ตามปกติ) — ตั้งค่าแล้วจึงเริ่มบังคับ
        "license_pubkey": {},
        # ศูนย์กลางรวมตัวเลข (Google Apps Script) — v3.10.0: URL และรหัสลับฝังมากับโปรแกรม (config.DEFAULT_HUB_URL/TOKEN)
        # เจ้าของโปรเจกต์สั่ง "ฝัง HUB_TOKEN" → เครื่องใหม่เชื่อมและซิงก์เองทันที (ไม่มีค่าฝัง เช่นตอนทดสอบ = ปิดเหมือนเดิม)
        "hub_url": DEFAULT_HUB_URL,
        "hub_token": DEFAULT_HUB_TOKEN,
        "hub_enabled": bool(DEFAULT_HUB_TOKEN),
        "hub_interval_min": 1 if DEFAULT_HUB_TOKEN else 5,
        # v3.10.0: เริ่มค้นอัตโนมัติหลังตรวจพบว่าเข้าสู่ระบบ CRIMES — เจ้าของสั่ง "สถานะเริ่มต้นให้ปิดไว้ ไม่ต้องนับถอยหลัง"
        "autostart_enabled": False,
    }


def load_config():
    with _CFG_LOCK:
        existed = CONFIG_PATH.exists()
        if existed:
            try:
                cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            except Exception:
                cfg, existed = _default_config(), False
        else:
            cfg = _default_config()
        base = _default_config()
        changed = False
        for k, v in base.items():
            if k not in cfg:
                cfg[k] = v
                changed = True
        # v3.10.0: เครื่องที่ยังไม่เคยตั้ง URL ศูนย์กลาง (ค่าว่างจากรุ่นก่อน) → ใช้ URL ที่ฝังมา (ไม่แตะเครื่องที่ตั้งเองไว้)
        if not str(cfg.get("hub_url") or "").strip():
            cfg["hub_url"] = DEFAULT_HUB_URL
            changed = True
        # v3.10.1: ศูนย์กลางย้าย Deployment — เครื่องที่ยังชี้ URL เก่าขององค์กร ให้ย้ายตาม (รหัสลับเดิม)
        # ต้องลืมเลข rev กองกลางของเล่มเก่าด้วย (รีวิว Codex PR #37): กติกา "เลขเกิน → ตอบทั้งเล่ม" คุ้มครอง
        # เฉพาะตอนเล่มใหม่ยังนับไม่ทันเลขเก่า — เครื่องที่อัปเดตช้าหลังเล่มใหม่โตแซงแล้วจะกลายเป็นซิงก์ส่วนต่าง
        # แล้วรายการช่วงต้นเล่มหายเงียบ ๆ (ค่าคงที่ต้องตรงกับ server.LEDGER_SEQ_KEY — มีข้อทดสอบตรึงไว้)
        if cfg.get("hub_url") in OLD_HUB_URLS:
            cfg["hub_url"] = DEFAULT_HUB_URL
            try:
                db.set_meta("ledger_hub_rev", "0")
            except Exception:
                pass                        # ฐานข้อมูลยังไม่พร้อม (เครื่องประหลาด) — เล่มว่างได้ full ตามกติกาเดิมอยู่แล้ว
            changed = True
        # v3.10.0: เครื่องที่ยังไม่มีรหัสลับ (อัปเดตจากรุ่นก่อนที่ไม่เคยเชื่อมศูนย์กลาง) → ใช้รหัสที่ฝังมาและเปิดซิงก์
        # เครื่องที่มีรหัสอยู่แล้ว (รวมเครื่องที่กด 'ปิดการเชื่อมต่อ' — รหัสยังอยู่) ไม่ถูกแตะ
        # เติมเฉพาะเมื่อ URL เป็นของที่ฝังมาเท่านั้น — เครื่องที่ชี้ศูนย์กลางอื่นไว้ ห้ามเอารหัสขององค์กรไปเซ็นให้ปลายทางอื่น
        if DEFAULT_HUB_TOKEN and not str(cfg.get("hub_token") or "") and cfg.get("hub_url") == DEFAULT_HUB_URL:
            cfg["hub_token"] = DEFAULT_HUB_TOKEN
            cfg["hub_enabled"] = True
            cfg["hub_interval_min"] = 1          # ธรรมเนียม v3.9.0: เชื่อมแล้วซิงก์ทุก 1 นาที (config เก่าค้างไว้ที่ 5)
            changed = True
        # v3.13.0: เจ้าของสั่ง "ทุกเครื่องที่อัพเดทนี้ต้องไม่มี 🔑 · ผู้ดูแลผูกอยู่กับ User Superadmin เท่านั้น"
        # → ถอด 'รหัสผู้ดูแลศูนย์กลาง' ออกจาก config.json ของทุกเครื่องทันทีที่เปิดรุ่นนี้ (ไม่เหลือในไฟล์อีก)
        # ค่าเดิม (ถ้ามี) พักไว้ในหน่วยความจำของโปรเซสนี้เท่านั้น ให้ Superadmin ที่เข้าสู่ระบบด้วยรหัสผ่านในรอบนี้
        # ผูกกับบัญชีตัวเองได้เลยโดยไม่ต้องกรอกใหม่ (เครื่องของเจ้าของ) — ปิดโปรแกรมก่อนนั้น = หายไปพร้อมโปรเซส
        if "hub_admin_token" in cfg:
            legacy = str(cfg.pop("hub_admin_token") or "").strip()
            if legacy:
                _LEGACY_ADMIN_TOKEN[0] = legacy
            changed = True
        # persist ทันทีเมื่อสร้างไฟล์ครั้งแรก/เติมคีย์ที่ขาด — สำคัญมากกับ secret_key
        # ซึ่งใช้เป็นทั้ง Flask session key และ salt แฮชเลขบัตร (db._id_salt): ต้องคงที่
        # ข้ามการรีสตาร์ท ไม่งั้น session หลุดทุกครั้งที่เปิดใหม่ และ hash เลขบัตรไม่ตรงกัน
        if not existed or changed:
            try:
                save_config(cfg)
            except Exception:
                pass
        return cfg


def save_config(cfg):
    """เขียน config แบบ atomic (เขียนไฟล์ชั่วคราวแล้วสลับทับ) — ไฟดับ/แครชกลางคัน
    จะยังเหลือไฟล์เดิมที่สมบูรณ์ ไม่มีทางได้ไฟล์ครึ่งเดียว"""
    with _CFG_LOCK:
        tmp = CONFIG_PATH.with_name(CONFIG_PATH.name + ".tmp")
        tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, CONFIG_PATH)


def update_config(**kwargs):
    """อ่าน-แก้-เขียน config ในล็อกเดียว — ทุก endpoint ที่แก้ค่าตั้งต้องเรียกผ่านตัวนี้
    เท่านั้น (ห้าม load_config → แก้เอง → save_config แยกขั้น เพราะจะแพ้ race)
    คืน config ล่าสุดหลังบันทึก"""
    with _CFG_LOCK:
        cfg = load_config()
        cfg.update(kwargs)
        save_config(cfg)
        return cfg


def take_legacy_admin_token(peek=False):
    """v3.13.0: รหัสผู้ดูแลที่ถอดจาก config.json ของรุ่นก่อน (อยู่ในหน่วยความจำเท่านั้น) — peek=False = หยิบแล้วลืม"""
    with _CFG_LOCK:
        tok = _LEGACY_ADMIN_TOKEN[0]
        if not peek:
            _LEGACY_ADMIN_TOKEN[0] = ""
        return tok


# ──────────────── v3.13.0: ซองรหัสผู้ดูแลศูนย์กลาง ผูกกับรหัสผ่านของบัญชี Superadmin ────────────────
# ADMIN_TOKEN ถูกเข้ารหัสด้วยกุญแจที่ได้จากรหัสผ่านของ Superadmin (PBKDF2-SHA256 รอบเท่าแฮชรหัสผ่าน)
# แล้วเก็บในช่อง permissions ของบัญชีนั้น — ซิงก์ไปทุกเครื่องพร้อมไดเรกทอรีสมาชิก (สคริปต์ศูนย์กลางเดิม ไม่ต้อง Deploy ใหม่)
# เครื่องไหนก็ตามที่ Superadmin เข้าสู่ระบบด้วยรหัสผ่าน → ถอดซองได้ในหน่วยความจำ → จัดการได้ทุกอย่าง
# ไม่มีเครื่องไหนเก็บรหัสผู้ดูแลแบบอ่านได้อีก · คนที่ไม่รู้รหัสผ่านของ Superadmin เปิดซองไม่ได้
# (ซองมีค่าเท่ากับแฮชรหัสผ่านที่ไดเรกทอรีมีอยู่แล้ว: เดาซองได้ = เดารหัสผ่านได้ ไม่ง่ายกว่ากัน)
# รูปแบบ: v1$รอบ$salt$nonce$ข้อมูลเข้ารหัส$MAC — เข้ารหัสด้วย HMAC-SHA256 แบบนับเลข แล้วปิดผนึกด้วย MAC (encrypt-then-MAC)
ADMIN_KEY_VERSION = "v1"
_ADMIN_KEY_MIN_ITER = 100_000
_ADMIN_KEY_MAX_ITER = 2_000_000


def _admin_kdf(password, salt, iters):
    k = hashlib.pbkdf2_hmac("sha256", str(password or "").encode("utf-8"), salt, iters, dklen=64)
    return k[:32], k[32:]


def _keystream(key, nonce, n):
    out, i = b"", 0
    while len(out) < n:
        out += hmac.new(key, nonce + i.to_bytes(4, "big"), hashlib.sha256).digest()
        i += 1
    return out[:n]


def seal_admin_key(token, password):
    """เข้ารหัส ADMIN_TOKEN ด้วยรหัสผ่าน — คืนสตริงซอง (สุ่ม salt/nonce ใหม่ทุกครั้ง)"""
    pt = str(token or "").encode("utf-8")
    if not pt or len(pt) > 512:
        raise ValueError("admin token length")
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(16)
    iters = max(db._ITERATIONS, _ADMIN_KEY_MIN_ITER)
    ek, mk = _admin_kdf(password, salt, iters)
    ct = bytes(a ^ b for a, b in zip(pt, _keystream(ek, nonce, len(pt))))
    head = f"{ADMIN_KEY_VERSION}${iters}${salt.hex()}${nonce.hex()}${ct.hex()}"
    return head + "$" + hmac.new(mk, head.encode("ascii"), hashlib.sha256).hexdigest()


def open_admin_key(envelope, password):
    """ถอดซองด้วยรหัสผ่าน — คืน ADMIN_TOKEN หรือ "" (รหัสผ่านไม่ตรง/ซองเสีย) ไม่โยน exception"""
    try:
        env = str(envelope or "")
        ver, iters, salt, nonce, ct, mac = env.split("$")
        iters = int(iters)
        salt, nonce, ct = bytes.fromhex(salt), bytes.fromhex(nonce), bytes.fromhex(ct)
        head = env.rsplit("$", 1)[0].encode("ascii")
    except (ValueError, UnicodeEncodeError):
        return ""
    if ver != ADMIN_KEY_VERSION or not (_ADMIN_KEY_MIN_ITER <= iters <= _ADMIN_KEY_MAX_ITER) \
            or len(salt) != 16 or len(nonce) != 16 or not 0 < len(ct) <= 512:
        return ""
    ek, mk = _admin_kdf(password, salt, iters)
    want = hmac.new(mk, head, hashlib.sha256).hexdigest().encode("ascii")
    if not hmac.compare_digest(want, mac.lower().encode("utf-8", "replace")):
        return ""
    try:
        return bytes(a ^ b for a, b in zip(ct, _keystream(ek, nonce, len(ct)))).decode("utf-8")
    except UnicodeDecodeError:
        return ""


def is_configured():
    """มีผู้ใช้ที่ใช้งานได้จริงอย่างน้อยหนึ่งคน — v3.10.0: คำขอสมัครที่ยังไม่อนุมัติไม่นับ (หน้าตั้งค่าเครื่องแรกยังเปิดได้)"""
    return db.has_any_user()


def get_secret_key():
    return load_config()["secret_key"]
