"""
CRIMES Search automation — ค้นเลขบัตรในระบบ CRIMES แล้วเขียนผลคดีลง Excel
ดูคู่มือเต็มที่ README.md

ตัวอย่าง:
  python crimes_auto.py "file.xlsx" --start-row 2 --end-row 100 --id-col B
  python crimes_auto.py --queue queue.json
  python crimes_auto.py --queue queue.json --retry-errors
"""
import argparse
import hashlib
import json
import random
import re
import shutil
import sys
import time
from pathlib import Path

import openpyxl
from openpyxl.styles import PatternFill
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

# ให้ภาษาไทยพิมพ์ออก console ได้ทุก code page (กัน UnicodeEncodeError บน Windows)
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

SEARCH_URL = "https://bdasearch.crimespolice.com/bdasearch/#/bda/search/criteria/person"
DETAIL_HASH = "/bda/search/detail"
CRITERIA_HASH = "/bda/search/criteria/person"

# ป๊อบอัพ 'โปรดระบุเหตุผลที่สืบค้นข้อมูล' ที่เด้งขึ้นหลังกดปุ่มค้นหาทุกครั้ง
SEARCH_REASON_LABEL = "ตรวจสอบทั่วไป"   # ช่องที่ต้องติ๊กในป๊อบอัพ
# ข้อความเหตุผลที่กรอกในช่อง 'ระบุเหตุผล' — สุ่มวนใช้จากรายการนี้ในแต่ละครั้ง
#
# หมายเหตุสำคัญ: ช่องนี้คือ 'เหตุผลการเข้าถึงข้อมูล' ที่ระบบ CRIMES บันทึกผูกกับบัญชี
# ผู้สืบค้น ผู้ใช้เป็นผู้รับผิดชอบต่อข้อความที่ถูกบันทึก จึงควรใช้ข้อความที่ตรงกับงานจริง
_DEFAULT_SEARCH_REASONS = [
    "ค้นทั่วไป", "ตรวจประวัติ", "เช็คคดี", "ดูประวัติ",
    "หาข้อมูล", "ทำการสืบสวน", "ทำงาน", "ค้น",
]
SEARCH_REASON_TEXTS = list(_DEFAULT_SEARCH_REASONS)
SEARCH_REASON_TEXT = SEARCH_REASON_TEXTS[0]
SEARCH_CONFIRM_TEXT = "ยืนยันค้นหา"

# ── ป๊อบอัพ 'ประกาศ/มีอะไรใหม่' ของเว็บ CRIMES (v3.4.0) ────────────────────────
# เว็บ CRIMES เด้งกล่อง "มีอะไรใหม่" ทุกครั้งที่ระบบขึ้นเวอร์ชันใหม่ (หนึ่งครั้งต่อเวอร์ชัน)
# กล่องนี้ครอบทับทั้งหน้า ทำให้บอทกดอะไรไม่ได้และรอบค้นค้างทั้งรอบ
# จึงต้องปิดให้อัตโนมัติก่อนทำงานทุกครั้ง — ปิดด้วยปุ่มยืนยันของกล่องเอง ไม่ใช่ซ่อนด้วย CSS
# เพราะเว็บจะได้จำว่า "อ่านแล้ว" และไม่เด้งซ้ำอีก
ANNOUNCE_BUTTON_TEXTS = ("เข้าใจแล้ว", "รับทราบ", "ตกลง", "ปิด", "เริ่มใช้งาน", "ถัดไป")
ANNOUNCE_TITLE_TEXTS = ("มีอะไรใหม่", "อัปเดตล่าสุด", "ประกาศ", "What's New")

_LAST_SEARCH_REASON = None


def set_search_reasons(texts):
    """ตั้งรายการเหตุผลที่ใช้สุ่ม — ถ้า texts ว่างหรือ None ใช้ค่าเริ่มต้น"""
    global SEARCH_REASON_TEXTS
    clean = [s.strip() for s in (texts or []) if s and s.strip()]
    SEARCH_REASON_TEXTS = clean if clean else list(_DEFAULT_SEARCH_REASONS)


def get_search_reasons():
    return list(SEARCH_REASON_TEXTS)


def pick_search_reason():
    """สุ่มเลือกข้อความเหตุผลจาก SEARCH_REASON_TEXTS
    เลี่ยงไม่ให้ตรงกับข้อความที่สุ่มได้ครั้งก่อนหน้าทันที (กันซ้ำกัน 2 ครั้งติด)"""
    global _LAST_SEARCH_REASON
    pool = [r for r in SEARCH_REASON_TEXTS if r != _LAST_SEARCH_REASON] or list(SEARCH_REASON_TEXTS)
    choice = random.choice(pool)
    _LAST_SEARCH_REASON = choice
    return choice

# ==================== สัญญาเครื่องหมายในไฟล์ Excel ====================
# นิยามที่เดียวของทั้งระบบ — ทุกจุดที่ทาสี/เขียนข้อความ ERROR ต้องอ้างค่าจากตรงนี้
# เพื่อให้ผู้ใช้แยกความหมายด้วยตาได้ และให้โค้ดล้างสีได้เฉพาะเฉด "ของระบบเอง"
#
#   🟨 เหลือง  = เติมศูนย์นำหน้าให้ครบ 13 หลัก   → ทาเฉพาะ 'เซลล์เลขบัตร'
#   🟥 แดงเข้ม = เลขที่ระบบคืนไม่ตรงกับที่ค้น    → ทาเฉพาะ 'เซลล์เลขบัตร'
#   🌸 แดงอ่อน = ข้อมูลคดีไม่ครบ ต้องตรวจสอบ     → ทา 'ทั้งแถว' A..F
YELLOW = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
RED = PatternFill(start_color="FF6B6B", end_color="FF6B6B", fill_type="solid")
REVIEW_RED = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
NO_FILL = PatternFill(fill_type=None)

REVIEW_END_COL = 6      # ทาถึงคอลัมน์ F ตามที่กำหนด
REVIEW_MAX_COL = 12     # เพดานกันไฟล์บวม เผื่อคอลัมน์ผลถูกตั้งไว้ไกลมาก (detect_columns ไปได้ถึง 60)
# openpyxl คืนค่าสีเป็น aRGB 8 หลัก ('00FFC7CE') ไม่ใช่ 6 หลักที่เราตั้งไว้ — เทียบด้วยท้ายสตริง
_REVIEW_HEX = "FFC7CE"


def _merge_anchor(ws, row, col):
    """คืนเซลล์ที่ 'ทาสีแล้วเห็นผลจริง' — ถ้าอยู่ในช่วง merge ต้องทาที่เซลล์มุมบนซ้าย
    เพราะ Excel เรนเดอร์ทั้งช่วงด้วยสีของเซลล์ anchor เท่านั้น"""
    try:
        for rng in ws.merged_cells.ranges:
            if rng.min_row <= row <= rng.max_row and rng.min_col <= col <= rng.max_col:
                return ws.cell(row=rng.min_row, column=rng.min_col)
    except Exception:
        pass
    return ws.cell(row=row, column=col)


def mark_review_row(ws, row, out_col, on=True, skip_cols=()):
    """ทา/ล้างสี 'แถวข้อมูลไม่ครบ' ตั้งแต่คอลัมน์ A ถึง max(F, คอลัมน์ผล)

    on=False จะล้าง "เฉพาะเฉดของฟีเจอร์นี้" เท่านั้น — สีที่เจ้าหน้าที่ทำเครื่องหมายไว้เอง
    สีสลับแถว และสีหัวตารางของไฟล์ต้นฉบับต้องไม่ถูกลบ (เป็นข้อมูลของผู้ใช้)
    skip_cols: คอลัมน์ที่ห้ามแตะ — ใช้ส่งคอลัมน์เลขบัตรเข้ามาเสมอ เพื่อไม่ทับมาร์ค
    เหลือง/แดงเข้มที่มีความหมายคนละอย่าง"""
    end = min(max(REVIEW_END_COL, int(out_col or 0)), REVIEW_MAX_COL)
    for col in range(1, end + 1):
        if col in skip_cols:
            continue
        try:
            cell = _merge_anchor(ws, row, col)
            if on:
                cell.fill = REVIEW_RED
            else:
                rgb = getattr(getattr(cell.fill, "start_color", None), "rgb", None)
                if isinstance(rgb, str) and rgb.upper().endswith(_REVIEW_HEX):
                    cell.fill = NO_FILL
        except Exception:
            continue    # เซลล์แปลก ๆ ในไฟล์ผู้ใช้ต้องไม่ทำให้ทั้งรอบงานล้ม


# ---- ข้อความ ERROR ในเซลล์ผล: 'ERROR:' / 'ERROR#n:' (ลองครั้งที่ n) / 'ERROR!:' (ถาวร) ----
# ฝังเลขครั้งที่ลองไว้ในไฟล์เอง ตัวนับจึงอยู่รอดข้ามรอบงาน ข้ามการปิดโปรแกรม และข้ามเครื่อง
# คงคำนำหน้า 'ERROR' ไว้เหมือนเดิม เพื่อให้โค้ดเก่าทุกจุดที่เช็ค startswith('ERROR') ยังทำงานได้
_ERROR_RE = re.compile(r"^ERROR(?P<perm>!)?(?:#(?P<n>\d+))?\s*:\s*(?P<msg>.*)$", re.S)


def format_error_cell(msg, attempt=1, permanent=False):
    """ประกอบข้อความ ERROR ลงเซลล์ผล (ตัดความยาวข้อความสาเหตุกันเซลล์บวม)"""
    body = str(msg or "").strip()[:100]
    if permanent:
        return f"ERROR!: {body}"
    if attempt and attempt > 1:
        return f"ERROR#{attempt}: {body}"
    return f"ERROR: {body}"


def parse_error_cell(value):
    """อ่านเซลล์ผล — คืน dict {'attempt','permanent','msg'} ถ้าเป็น ERROR, ไม่ใช่คืน None"""
    s = str(value).strip() if value is not None else ""
    if not s.startswith("ERROR"):
        return None
    m = _ERROR_RE.match(s)
    if not m:
        return {"attempt": 1, "permanent": False, "msg": s[5:].lstrip(": ").strip()}
    return {
        "attempt": int(m.group("n") or 1),
        "permanent": bool(m.group("perm")),
        "msg": (m.group("msg") or "").strip(),
    }


def is_error_cell(value):
    return parse_error_cell(value) is not None


def classify_error(msg):
    """จัดกลุ่มสาเหตุ error เพื่อตัดสินว่าจะลองใหม่อย่างไร
      'net'       เครือข่ายมีปัญหา    → ใช้กลไกพัก/ค้นต่อ ไม่นับเป็นครั้งที่ลอง
      'auth'      หลุด login ปลายทาง  → ต้องพักรอคน ห้ามไล่ยิงซ้ำ (เผาโควตาเปล่า)
      'permanent' ถาวร (เลขใช้ไม่ได้/เว็บเปลี่ยน DOM) → ไม่ลองใหม่อัตโนมัติ
      'retry'     ชั่วคราวอื่น ๆ       → ลองใหม่ได้
    ต้องส่ง 'ข้อความสาเหตุ' ล้วน ๆ เข้ามา — ตัด path ของไฟล์หลักฐานออกก่อน ไม่งั้นเลข
    ในชื่อไฟล์/พาธจะไปแมตช์คำใบ้ผิดกลุ่ม"""
    m = str(msg or "")
    m = m.split(" · บันทึกหลักฐาน")[0]
    low = m.lower()
    if is_network_error(m):
        return "net"
    if any(h in low for h in ("status 401", "status 403", "http 401", "http 403",
                              "unauthorized", "forbidden", "session expired",
                              "หมดอายุ", "เข้าสู่ระบบใหม่", "กรุณาเข้าสู่ระบบ")):
        return "auth"
    if not is_retryable_error(m):
        return "permanent"
    return "retry"


# ---- ความครบถ้วนของข้อมูลคดี (ใช้ตัดสินการมาร์คแถวให้ตรวจสอบ) ----
def case_flags(c, no_year=False):
    """ตรวจ 'ต่อคดี' — คืน set ของสิ่งที่ขาด: {'charge'} / {'year'} / ทั้งคู่ / set() ถ้าครบ
    (เมื่อผู้ใช้เลือก 'ไม่ใส่ปี' จะไม่นับปีที่ขาดเป็นข้อมูลไม่ครบ)"""
    miss = set()
    if not (c.get("charge") or "").strip():
        miss.add("charge")
    if not no_year and not re.fullmatch(r"\d{4}", (c.get("year") or "").strip()):
        miss.add("year")
    return miss


def format_cases(kept, no_year=False):
    """ประกอบข้อความผลลง Excel + บอกว่าแถวนี้ข้อมูลไม่ครบหรือไม่ — คืน (text, review)

    ⚠ ข้อความต้องเหมือนรุ่นก่อนทุกไบต์ เพราะผลที่ถูกกู้จากประวัติ (find_prev_result)
    เป็นข้อความล้วน ถ้ารูปแบบเปลี่ยน ไฟล์เดียวกันจะมีสองรูปแบบปนกัน
    review คำนวณจาก 'อ็อบเจกต์คดี' ตรง ๆ ไม่ได้มาจากการ parse ข้อความกลับ
    (ข้อหามี '/' ได้ เช่น 'ลักทรัพย์/รับของโจร' การ split จึงแตกคดีผิด)"""
    def fmt(i, c):
        charge = c.get("charge", "").strip() or "(ไม่ระบุข้อหา)"
        if no_year:
            return f"คดีที่{i+1} {charge}"
        return f"คดีที่{i+1} {charge} ปี{c.get('year','').strip()}"
    text = "/ ".join(fmt(i, c) for i, c in enumerate(kept))
    review = any(case_flags(c, no_year) for c in kept)
    return text, review

USER_DATA_DIR = Path.home() / ".crimes_auto_profile"

# ---- ทำงานบนเครื่องผู้ใช้ + ลดร่องรอยการเป็นบอทอัตโนมัติ ----
# หลักการ: "แก้ให้น้อยที่สุด" — Chrome จริงของเครื่อง (channel="chrome") รายงานค่าที่ถูกต้อง
# อยู่แล้ว (plugins, window.chrome, WebGL, vendor, userAgentData ฯลฯ) การไปปลอมทับกลับ
# "เพิ่มร่องรอย" ให้ตรวจจับง่ายขึ้น เราจึงปล่อยค่าจริงไว้ และจัดการเฉพาะจุดที่จำเป็นเท่านั้น
STEALTH_ARGS = [
    "--start-maximized",
    "--disable-blink-features=AutomationControlled",   # ทำให้ navigator.webdriver = false ตั้งแต่ระดับเบราว์เซอร์
    "--no-default-browser-check",
    "--no-first-run",
]
# init script ที่ฝังก่อนสคริปต์ของหน้าเว็บ — ติดตั้งเฉพาะ (1) หน้ากาก Function.toString
# ให้ getter ที่เราแทรกยัง stringify เป็น native code และ (2) ตาข่ายกัน webdriver ที่ทำงาน
# เฉพาะกรณีหลุดมาเป็น true (เช่นตกไปใช้ Chromium สำรอง) — บน Chrome จริงจะไม่แตะอะไรเลย
STEALTH_INIT_JS = r"""
(() => {
  'use strict';
  // ---- (1) หน้ากาก Function.prototype.toString ให้รายงานเป็น native code ----
  // ใช้ Proxy + WeakMap: getter ที่เราลงทะเบียนจะ stringify เป็น "function <name>() { [native code] }"
  // และ toString ตัวมันเองก็รายงาน native (toString.toString()) — ปิดช่องตรวจว่า navigator ถูกแพตช์
  let masq = (fn) => fn;
  try {
    const nativeToString = Function.prototype.toString;
    const masks = new WeakMap();
    const proxy = new Proxy(nativeToString, {
      apply(target, thisArg, args) {
        if (thisArg === proxy) return 'function toString() { [native code] }';
        if (masks.has(thisArg)) return 'function ' + masks.get(thisArg) + '() { [native code] }';
        return Reflect.apply(target, thisArg, args);
      }
    });
    Function.prototype.toString = proxy;
    masq = (fn, name) => { try { masks.set(fn, name); } catch (e) {} return fn; };
  } catch (e) {}

  // ---- (2) navigator.webdriver — ตาข่ายกันเฉพาะเวลาหลุด ----
  // Chrome จริง + --disable-blink-features=AutomationControlled คืน boolean `false` อยู่แล้ว (ค่าจริง)
  // ปกติจึงไม่ทำอะไร — จะแทรกก็ต่อเมื่ออ่านได้ `true` (แฟล็กไม่ทำงาน/ตกไปใช้ Chromium สำรอง)
  // และแทรกให้เหมือน native เป๊ะ: accessor บน Navigator.prototype (ไม่ใช่ own property ของ instance)
  // คืน boolean false (ไม่ใช่ undefined) และผูกกับหน้ากาก toString ให้ getter ดู native
  try {
    if (navigator.webdriver === true) {
      const getter = masq(function webdriver() { return false; }, 'get webdriver');
      Object.defineProperty(Navigator.prototype, 'webdriver', {
        get: getter, configurable: true, enumerable: true
      });
    }
  } catch (e) {}

  // ---- ตั้งใจ "ไม่แตะ" (Chrome จริงถูกต้องอยู่แล้ว การปลอมจะกลายเป็นร่องรอย) ----
  // navigator.plugins / mimeTypes            -> PluginArray/PDF จริง prototype ถูกต้อง
  // window.chrome (runtime/loadTimes/csi/app) -> object จริงของ Chrome
  // navigator.languages / language           -> ค่าจริงจากโปรไฟล์ Chrome (สอดคล้องกันเองอยู่แล้ว)
  // vendor / userAgentData / UA / Client Hints -> จริงและสอดคล้องกัน
  // WebGL, canvas, AudioContext, deviceMemory, hardwareConcurrency, permissions, screen -> จริงทั้งหมด
})();
"""


PROFILE_TAG = "crimes_auto_profile"   # ชื่อโฟลเดอร์โปรไฟล์เฉพาะของระบบ (ใช้ระบุ Chrome ของเราเท่านั้น)

# True เมื่อ launch_browser() ครั้งล่าสุดต้องตกไปใช้ Chromium สำรอง (ไม่พบ/เปิด Chrome จริงไม่ได้)
# ผู้เรียก (worker) อ่านค่านี้เพื่อเตือนผู้ใช้ว่ากำลังรันโหมดที่เนียนน้อยกว่า
LAST_LAUNCH_USED_FALLBACK = False


def kill_profile_browsers():
    """ปิดหน้าต่าง Chrome ที่ค้างอยู่ซึ่งใช้ 'โปรไฟล์ของระบบ' (.crimes_auto_profile)
    เพื่อแก้ปัญหา 'profile already in use' — ปิดเฉพาะ Chrome ของระบบเท่านั้น ไม่แตะ Chrome ส่วนตัวของผู้ใช้
    คืนจำนวน process ที่ปิด (โดยประมาณ)"""
    import subprocess
    try:
        if sys.platform == "win32":
            ps = (
                "$n=0; Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | "
                "Where-Object { $_.CommandLine -match '" + PROFILE_TAG + "' } | "
                "ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop; $n++ } catch {} }; "
                "Write-Output $n"
            )
            r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                               capture_output=True, text=True, timeout=20)
            try:
                return int((r.stdout or "0").strip() or "0")
            except ValueError:
                return 0
        else:
            subprocess.run(["pkill", "-f", PROFILE_TAG], capture_output=True, timeout=15)
            return 0
    except Exception:
        return 0


def clean_profile_lock():
    """ลบไฟล์ล็อก Singleton ที่ค้างในโปรไฟล์ (กรณี Chrome ปิดไม่สมบูรณ์/แครช)
    ช่วยแก้ 'Opening in existing browser session' ที่เกิดจากล็อกค้าง"""
    for name in ("SingletonLock", "SingletonCookie", "SingletonSocket"):
        try:
            f = USER_DATA_DIR / name
            if f.is_symlink() or f.exists():
                f.unlink()
        except Exception:
            pass


def launch_browser(p, headless=False):
    """เปิดเบราว์เซอร์แบบ persistent (คงล็อกอินไว้) พร้อมมาตรการลดการถูกตรวจจับว่าเป็นบอท

    ก่อนเปิด: ปิด Chrome ของระบบที่ค้าง (เฉพาะที่ใช้โปรไฟล์ของเรา) + ลบไฟล์ล็อกค้าง
    เพื่อกัน 'Opening in existing browser session' ที่เกิดจาก Chrome เดิมค้าง/ล็อกค้าง
    ลำดับการเปิด: ใช้ Chrome ของเครื่อง (channel='chrome') ก่อน — โปรไฟล์เข้ากันได้และเนียนสุด,
    ถ้าเปิดไม่ได้จึงใช้ Chromium ของ Playwright เป็นตัวสำรอง (ถ้าติดตั้งไว้)
    """
    global LAST_LAUNCH_USED_FALLBACK
    LAST_LAUNCH_USED_FALLBACK = False
    kill_profile_browsers()
    clean_profile_lock()
    common = dict(
        user_data_dir=str(USER_DATA_DIR),
        headless=headless,
        no_viewport=True,
        args=STEALTH_ARGS,
        # เนียนเหมือน Chrome ของคนทั่วไปบน Windows:
        chromium_sandbox=True,                        # เปิด sandbox → ไม่มีแถบเตือน --no-sandbox + เหมือนคนใช้จริง
        ignore_default_args=["--enable-automation"],  # กันแฟล็ก automation ที่ Playwright บางเวอร์ชันเคยใส่มา
        # ไม่ตั้ง locale/timezone เอง — ปล่อยให้โปรไฟล์ Chrome จริงขับ navigator.language/languages +
        # Accept-Language + timezone ให้สอดคล้องกันตามค่าจริงของเครื่อง (เนียนกว่าการบังคับทับ)
    )
    # ใช้ Chrome จริงของเครื่องก่อนเสมอ (เนียนสุด) — ลอง 2 ครั้ง เผื่อโปรไฟล์ค้าง
    ctx = None
    for attempt in range(2):
        try:
            ctx = p.chromium.launch_persistent_context(channel="chrome", **common)  # Chrome ของเครื่อง
            break
        except Exception as e:
            print(f"[stealth] เปิด Chrome ของเครื่องไม่สำเร็จ (ครั้งที่ {attempt + 1}): {e}")
            clean_profile_lock()
    if ctx is None:
        # สำรอง: Chromium ของ Playwright — เตือนให้ชัด เพราะลายนิ้วมือต่างจาก Chrome จริงมาก (ตรวจจับว่าเป็นบอทง่ายขึ้น)
        LAST_LAUNCH_USED_FALLBACK = True
        print("[stealth][!] ใช้ Chromium สำรองแทน Chrome ของเครื่อง — ลายนิ้วมือเบราว์เซอร์จะดูเป็นบอทง่ายขึ้น "
              "โปรดติดตั้ง/เปิด Google Chrome เพื่อความเนียนสูงสุด")
        try:
            ctx = p.chromium.launch_persistent_context(**common)
        except Exception:
            # บางเครื่อง (เช่น container) เปิด sandbox ไม่ได้ → ลองอีกครั้งแบบผ่อนปรน sandbox
            relaxed = dict(common)
            relaxed.pop("chromium_sandbox", None)
            ctx = p.chromium.launch_persistent_context(**relaxed)
    try:
        ctx.add_init_script(STEALTH_INIT_JS)
    except Exception:
        pass
    return ctx

# ---- ความเร็วการค้น (ตัวคูณหน่วงเวลา) — ปรับได้จากสไลเดอร์ใน UI ----
# factor > 1 = ช้าลง (สมจริงกับมนุษย์มากขึ้น), < 1 = เร็วขึ้น
# ทุกระดับยังคงอยู่ในเกณฑ์ที่เหมือนมนุษย์ค้นเอง (ไม่เร็วเกินจริง)
SPEED_FACTORS = {1: 1.7, 2: 1.35, 3: 1.0, 4: 0.8, 5: 0.65}
SPEED_LABELS = {1: "ช้าสุด", 2: "ช้า", 3: "ปกติ", 4: "เร็ว", 5: "เร็วสุด"}
DEFAULT_SPEED = 2          # ค่าเริ่มต้น = ช้ากว่าเดิมเล็กน้อยเพื่อความสมจริง
CURRENT_SPEED = DEFAULT_SPEED           # ระดับที่ใช้อยู่ (แหล่งความจริงเดียวของทั้งระบบ)
DELAY_FACTOR = SPEED_FACTORS[DEFAULT_SPEED]   # ตัวคูณที่ใช้จริง — ต้องตรงกับ CURRENT_SPEED เสมอ


def clamp_speed(level):
    try:
        level = int(level)
    except (TypeError, ValueError):
        level = DEFAULT_SPEED
    return max(1, min(5, level))


def set_speed(level):
    """ตั้งระดับความเร็วการค้น 1(ช้าสุด)–5(เร็วสุด) แล้วคืน factor ที่ใช้จริง

    เรียกกลางรอบทำงานได้ปลอดภัย: ทั้งสองตัวแปรเป็น global ระดับโมดูล เขียนทีละตัว
    แบบ atomic ใต้ GIL และ sleep_range/human_type อ่านค่าใหม่ทุกครั้งที่ถูกเรียก
    ผลจึงมีตั้งแต่จังหวะหน่วงถัดไป (ช้าสุดราว ๆ ไม่กี่วินาที) โดยไม่มี torn read"""
    global DELAY_FACTOR, CURRENT_SPEED
    level = clamp_speed(level)
    DELAY_FACTOR = SPEED_FACTORS[level]
    CURRENT_SPEED = level
    return DELAY_FACTOR


def get_speed():
    """คืนระดับความเร็วปัจจุบัน — ใช้ร่วมกันทั้ง worker และ server
    (ห้ามให้ที่อื่นเก็บ 'ระดับ' ของตัวเองไว้ซ้ำ ไม่งั้นค่าจะเพี้ยนจากกัน)"""
    return {"speed": CURRENT_SPEED,
            "speed_label": SPEED_LABELS.get(CURRENT_SPEED, "?"),
            "speed_factor": DELAY_FACTOR}


def sleep_range(lo, hi):
    """หน่วงเวลาแบบสุ่มให้เหมือนมนุษย์กดเอง — จังหวะไม่สม่ำเสมอ ไม่ติดๆกันเท่ากันทุกครั้ง

    - ใช้การกระจายแบบ triangular (เอนเข้าหาค่ากลาง) แทน uniform แบน ๆ
      ทำให้เวลาส่วนใหญ่อยู่ช่วงกลางแต่ยังแกว่งได้ทั้งเร็ว/ช้า
    - บางครั้ง (~12%) เว้นจังหวะยาวขึ้นเหมือนคนหยุดคิด/ละมือ เพื่อไม่ให้จังหวะเป็นแพตเทิร์นเดิมซ้ำ ๆ
    """
    if hi <= lo:
        t = lo
    else:
        t = random.triangular(lo, hi, (lo + hi) / 2.0)
    # เว้นจังหวะยาวเป็นครั้งคราว (เหมือนคนเผลอ/คิด) — ตัดความสม่ำเสมอของการค้นติดๆกัน
    if random.random() < 0.12:
        t += random.uniform(0.6, 2.0)
    time.sleep(t * DELAY_FACTOR)


def normalize_id(raw):
    if raw is None:
        return None, False, False
    s = re.sub(r"\D", "", str(raw).strip())
    if not s:
        return None, False, True
    if len(s) > 13:
        return None, False, True
    if len(s) < 13:
        return s.zfill(13), True, False
    return s, False, False


def human_type(page, selector, text):
    loc = page.locator(selector)
    loc.fill("")
    loc.click()
    for ch in text:
        page.keyboard.type(ch, delay=int(random.randint(30, 110) * DELAY_FACTOR))


def human_move_to(page, locator):
    """ขยับเมาส์แบบมนุษย์ไปยังกลางองค์ประกอบ พร้อมหน่วงสั้น ๆ ก่อนคลิก
    — กันการคลิกแบบ 'ไม่มีการเคลื่อนเมาส์นำ' ที่ดูเป็นสคริปต์ (isTrusted/พฤติกรรม)
    คืน True ถ้าขยับได้, False ถ้าหา bounding box ไม่ได้ (ให้คลิกได้ตามปกติ)"""
    try:
        box = locator.bounding_box()
        if not box:
            return False
        cx = box["x"] + box["width"] / 2 + random.uniform(-4, 4)
        cy = box["y"] + box["height"] / 2 + random.uniform(-3, 3)
        page.mouse.move(cx, cy, steps=random.randint(8, 20))
        sleep_range(0.05, 0.2)
        return True
    except Exception:
        return False


def _checkbox_snapshot(page):
    """อ่านสถานะ checkbox ทั้งหมด (อ่านอย่างเดียว ไม่ใช่การคลิก จึงไม่เป็นสัญญาณบอท)"""
    return page.evaluate(
        r"""() => Array.from(document.querySelectorAll('input[type="checkbox"]')).map((cb, i) => {
          const host = cb.closest('nb-checkbox') || cb.closest('label') || cb.parentElement;
          return { i, label: ((host && host.textContent) || '').replace(/\s+/g, ''), checked: cb.checked };
        })"""
    )


def _checkbox_wrong(info):
    """คืน index ของช่องที่สถานะยังไม่ถูก: 'คดีอาญา' ต้องติ๊ก, ที่เหลือต้องไม่ติ๊ก"""
    return [c["i"] for c in info if bool(c["checked"]) != (c["label"] == "คดีอาญา")]


def ensure_checkboxes(page):
    """ติ๊ก 'คดีอาญา' เพียงช่องเดียว และเอาติ๊กช่องอื่นทั้งหมดออก (ก่อนกดค้นหาทุกครั้ง)

    คลิกจริงของ Playwright (trusted input ผ่าน CDP) เป็นหลัก เพื่อไม่ให้เป็นสัญญาณบอท
    แล้ว 'ตรวจสอบสถานะจริง' อีกครั้ง — ถ้ายังไม่ถูกค่อย fallback เป็น JS click
    เพื่อรับประกันว่าเงื่อนไขการค้นถูกต้องเสมอ (ความถูกต้องสำคัญกว่าความเนียน)
    """
    info = _checkbox_snapshot(page)
    todo = _checkbox_wrong(info)
    if not todo:
        return

    # (A) คลิกจริงผ่าน Playwright — คลิกที่ตัวครอบ nb-checkbox (สิ่งที่คนคลิกจริง) ถ้าเข้าคู่กัน 1:1,
    #     ไม่งั้นคลิก native input โดยตรงแบบ force (ยัง trusted อยู่ เพราะเป็น input event จริงของ CDP)
    hosts = page.locator("nb-checkbox")
    boxes = page.locator('input[type="checkbox"]')
    try:
        one_to_one = (hosts.count() == boxes.count() == len(info))
    except Exception:
        one_to_one = False
    for i in todo:
        try:
            if one_to_one and hosts.nth(i).count() > 0:
                human_move_to(page, hosts.nth(i))
                hosts.nth(i).click()
            else:
                boxes.nth(i).click(force=True)
        except Exception:
            pass

    # (B) ตรวจสถานะจริงซ้ำ — ถ้ายังผิด รับประกันด้วย JS click (fallback สุดท้าย)
    still = _checkbox_wrong(_checkbox_snapshot(page))
    if still:
        page.evaluate(
            r"""(idxs) => {
              const cbs = document.querySelectorAll('input[type="checkbox"]');
              for (const i of idxs) { const cb = cbs[i]; if (cb) cb.click(); }
            }""",
            still,
        )


def click_search(page):
    """กดปุ่มค้นหา — ปุ่มจริงเป็น <div> ข้อความ 'ค้นหา' (คลาส color-yellow-hard) ไม่ใช่ <button>
    จึงลองหลายวิธีให้ทน ทั้ง locator และ fallback ผ่าน JS (เทียบข้อความ 'ค้นหา' แบบตรงตัว)"""
    for sel in ('div.color-yellow-hard:has-text("ค้นหา")',
                'button:has-text("ค้นหา")'):
        try:
            loc = page.locator(sel)
            if loc.count() > 0:
                human_move_to(page, loc.first)   # ขยับเมาส์เข้าหาปุ่มก่อนคลิก (เหมือนคนกด)
                loc.first.click()
                return True
        except Exception:
            pass
    ok = page.evaluate(
        r"""() => {
          const els = Array.from(document.querySelectorAll('div, button, a, span'));
          const t = els.find(e => ((e.textContent || '').trim()) === 'ค้นหา');
          if (t) { (t.closest('button,[role=button]') || t).click(); return true; }
          return false;
        }"""
    )
    return bool(ok)


def confirm_search_reason(page, reason=None, note=None, timeout=8000):
    """จัดการป๊อบอัพ 'โปรดระบุเหตุผลที่สืบค้นข้อมูล' ที่เด้งขึ้นหลังกดปุ่มค้นหา

    ขั้นตอน: ติ๊ก 'ตรวจสอบทั่วไป' → พิมพ์เหตุผล (สุ่มข้อความ) → กด 'ยืนยันค้นหา'
    (การกดยืนยันคือสิ่งที่สั่งให้การค้นทำงานจริง)

    reason: ระบุข้อความเองได้ — ถ้าไม่ระบุจะสุ่มจาก SEARCH_REASON_TEXTS ให้แต่ละครั้ง

    คืนสถานะเป็นข้อความ (ผู้เรียกต้องแยก 3 กรณีนี้ออกจากกัน):
      "confirmed"    — กดยืนยันสำเร็จและป๊อบอัพปิดแล้ว = การค้นถูกสั่งให้ทำงานจริง
      "no_popup"     — ไม่พบป๊อบอัพภายในเวลาที่กำหนด (เผื่อบางกรณีระบบไม่เด้งป๊อบอัพ)
                       การค้นอาจทำงานไปแล้วตามปกติ ผู้เรียกต้องตรวจผลบนหน้าเองว่ามีจริงไหม
      "click_failed" — พบป๊อบอัพแต่กดยืนยันไม่สำเร็จ/ป๊อบอัพยังค้างอยู่
                       = การค้น "ยังไม่ถูกสั่งทำงาน" ผลใด ๆ บนหน้าจอเชื่อถือไม่ได้ทั้งสิ้น
    """
    reason = pick_search_reason() if reason is None else reason
    N = note or (lambda m: None)

    # รอป๊อบอัพเรนเดอร์ — ดูจากปุ่ม 'ยืนยันค้นหา'
    try:
        page.wait_for_selector(f'text={SEARCH_CONFIRM_TEXT}', timeout=timeout)
    except PWTimeout:
        N("ไม่พบป๊อบอัพระบุเหตุผล — ข้ามขั้นยืนยัน (ค้นต่อตามปกติ)")
        return "no_popup"
    sleep_range(0.3, 0.8)

    # 1) ติ๊ก 'ตรวจสอบทั่วไป' (เทียบชื่อกำกับของ checkbox แบบตัดช่องว่าง)
    page.evaluate(
        r"""(label) => {
          const norm = s => (s || '').replace(/\s+/g, '');
          const want = norm(label);
          for (const cb of document.querySelectorAll('input[type="checkbox"]')) {
            const host = cb.closest('nb-checkbox') || cb.closest('label') || cb.parentElement;
            if (norm(host && host.textContent).includes(want) && !cb.checked) cb.click();
          }
        }""",
        SEARCH_REASON_LABEL,
    )
    N(f"ติ๊ก '{SEARCH_REASON_LABEL}' แล้ว")
    sleep_range(0.3, 0.7)

    # 2) พิมพ์เหตุผลแบบมนุษย์ (ช่อง placeholder 'ระบุเหตุผล...')
    reason_sel = 'input[placeholder*="ระบุเหตุผล"], textarea[placeholder*="ระบุเหตุผล"]'
    try:
        if page.locator(reason_sel).count() > 0:
            human_type(page, reason_sel, reason)
            N(f"พิมพ์เหตุผล '{reason}' แล้ว")
    except Exception:
        pass
    sleep_range(0.3, 0.8)

    # 3) กด 'ยืนยันค้นหา' — ลอง locator ก่อน แล้ว fallback ผ่าน JS (เทียบข้อความตรงตัว)
    clicked = False
    for sel in (f'button:has-text("{SEARCH_CONFIRM_TEXT}")',
                f'div.color-yellow-hard:has-text("{SEARCH_CONFIRM_TEXT}")'):
        try:
            loc = page.locator(sel)
            if loc.count() > 0:
                human_move_to(page, loc.first)   # ขยับเมาส์เข้าหาปุ่มก่อนคลิก (เหมือนคนกด)
                loc.first.click()
                clicked = True
                break
        except Exception:
            pass
    if not clicked:
        clicked = bool(page.evaluate(
            r"""(txt) => {
              const els = Array.from(document.querySelectorAll('button, div, a, span'));
              const t = els.find(e => ((e.textContent || '').trim()) === txt);
              if (t) { (t.closest('button,[role=button]') || t).click(); return true; }
              return false;
            }""",
            SEARCH_CONFIRM_TEXT,
        ))
    # ตรวจว่าป๊อบอัพปิดจริงหลังกด — ถ้ายังค้างอยู่แปลว่าคลิกไม่โดน/ระบบไม่รับ
    # = การค้นยังไม่ถูกสั่งทำงาน (สำคัญ: กันการอ่านผลค้างบนหน้าแล้วเข้าใจผิดว่าค้นแล้ว)
    if clicked:
        try:
            page.wait_for_selector(f'text={SEARCH_CONFIRM_TEXT}', state="hidden", timeout=5000)
        except PWTimeout:
            clicked = False
            N("กดยืนยันแล้วแต่ป๊อบอัพยังค้างอยู่ — ถือว่ายืนยันไม่สำเร็จ")
    N("กดยืนยันค้นหา: " + ("สำเร็จ ✓" if clicked else "ไม่สำเร็จ ✗"))
    return "confirmed" if clicked else "click_failed"


def extract_year(case_no):
    m = re.search(r"/(\d{4})", case_no or "")
    return m.group(1) if m else ""


def get_result_count(page):
    """อ่านจำนวนคดีอาญาจากหัวผลการค้น
    คืนจำนวน (>=0) ถ้าอ่านได้, หรือ -1 ถ้ายังอ่านไม่ได้ (หน้าอาจยังโหลดผลไม่เสร็จ)"""
    return page.evaluate(
        r"""
        () => {
          const t = document.body.innerText || '';
          // หลัก: 'คดีอาญา (N รายการ)'
          let m = t.match(/คดีอาญา\s*\(\s*([\d,]+)\s*รายการ\s*\)/);
          if (m) return parseInt(m[1].replace(/,/g,''), 10) || 0;
          // สำรอง: '(N รายการ)' ใดๆ บนหน้าผลการค้น
          m = t.match(/\(\s*([\d,]+)\s*รายการ\s*\)/);
          if (m) return parseInt(m[1].replace(/,/g,''), 10) || 0;
          return -1;  // อ่านไม่ได้ — ให้ผู้เรียกไปนับจากตารางแทน
        }
        """
    )


def wait_for_results(page, timeout=20000):
    """รอจนผลการค้นแสดงจริง: มีข้อความ 'คดีอาญา (N รายการ)' หรือมีแถวข้อมูลในตาราง
    ป้องกันการอ่านจำนวนผลเร็วเกินไปก่อนที่หน้าเว็บ (SPA) จะเรนเดอร์เสร็จ"""
    try:
        page.wait_for_function(
            r"""() => {
              const t = document.body.innerText || '';
              if (/คดีอาญา\s*\(\s*\d+\s*รายการ\s*\)/.test(t)) return true;
              if (/\(\s*\d+\s*รายการ\s*\)/.test(t)) return true;
              const tb = document.querySelector('table tbody tr, table tr:nth-child(2)');
              return !!tb;
            }""",
            timeout=timeout,
        )
    except PWTimeout:
        pass


def read_table_rows(page):
    return page.evaluate(
        """
        () => {
          const t = document.querySelector('table');
          if (!t) return [];
          return Array.from(t.querySelectorAll('tr')).slice(1).map(r => {
            const tds = Array.from(r.querySelectorAll('td')).map(td => td.textContent.trim());
            return { id: tds[0]||'', name: tds[1]||'', sex: tds[2]||'', age: tds[3]||'', caseNo: tds[4]||'', status: tds[5]||'', station: tds[6]||'' };
          });
        }
        """
    )


def click_row(page, index):
    """เปิดคดีตามลำดับในตาราง — คลิกจริงของ Playwright (trusted) ก่อน, fallback JS ถ้าคลิกไม่ได้

    index นับเฉพาะแถวข้อมูล (ข้ามแถวหัวตาราง) ให้ตรงกับ read_table_rows()
    """
    try:
        # แถวข้อมูลลำดับที่ index = tr ตัวที่ (index+1) เพราะข้ามหัวตาราง (tr แรก)
        row = page.locator("table").first.locator("tr").nth(index + 1)
        lbl = row.locator("label")
        target = lbl.first if lbl.count() > 0 else row   # คลิก label ก่อน (เหมือนคนคลิก), ไม่งั้นทั้งแถว
        human_move_to(page, target)
        target.click()
        return
    except Exception:
        pass
    # fallback: JS click เดิม (untrusted) — ใช้เฉพาะเมื่อคลิกจริงไม่ได้
    page.evaluate(
        f"""
        () => {{
          const t = document.querySelector('table');
          const rs = Array.from(t.querySelectorAll('tr')).slice(1);
          const r = rs[{index}];
          if (!r) return;
          const target = r.querySelector('label') || r;
          target.click();
        }}
        """
    )


def get_detail_data(page):
    """ดึงข้อมูลหน้ารายละเอียดแบบทนต่อ index เลื่อน
    - caseNo : input[0] (เช่น 397/2553)
    - yearField : input[3] (ช่อง 'ปีที่คดี' = 2553) ใช้เป็นปีหลัก
    - charge : input[4] (ช่อง 'ข้อหา')
    - returnedId : หา input ที่ value เป็นเลข 13 หลักพอดี (ทนต่อ index เลื่อน)
    - status : input ถัดจาก returnedId (เช่น ผู้ต้องหา/ผู้เสียหาย)
    """
    return page.evaluate(
        r"""
        () => {
          const inputs = Array.from(document.querySelectorAll('input[type="text"], input:not([type]), textarea'));
          const vals = inputs.map(i => (i.value || '').trim());

          // หา returnedId = ช่องที่เป็นเลข 13 หลักพอดี
          let idIdx = vals.findIndex(v => /^\d{13}$/.test(v));
          const returnedId = idIdx >= 0 ? vals[idIdx] : (vals[9] || '');
          const status = idIdx >= 0 ? (vals[idIdx + 1] || '') : (vals[10] || '');

          return {
            caseNo: vals[0] || '',
            yearField: vals[3] || '',
            charge: vals[4] || '',
            returnedId: returnedId,
            status: status,
          };
        }
        """
    )


def go_to_next_page(page):
    """Return True if moved to next page, False otherwise."""
    result = page.evaluate(
        """
        () => {
          const items = Array.from(document.querySelectorAll('.pagination .page-item, ngb-pagination li'));
          if (!items.length) return false;
          const nextBtn = items.find(li => {
            const t = li.textContent.trim();
            return t === '›' || t === '>' || t.toLowerCase().includes('next');
          });
          if (!nextBtn) return false;
          if (nextBtn.classList.contains('disabled')) return false;
          const a = nextBtn.querySelector('a, button') || nextBtn;
          a.click();
          return true;
        }
        """
    )
    return bool(result)


# ---- วินิจฉัยเมื่อเว็บ CRIMES เปลี่ยน DOM (เก็บหลักฐานไว้ตรวจภายหลัง) ----
ID_INPUT_SELECTORS = ('#inputPid', 'input[placeholder="เลขบัตรประชาชน"]')


def _diag_dir():
    """โฟลเดอร์เก็บ diagnostics — ใต้ชั้นข้อมูลของ backend (data/diagnostics) ถ้าหาได้"""
    try:
        import config as _cfg
        d = Path(_cfg.DATA_DIR) / "diagnostics"
    except Exception:
        d = USER_DATA_DIR / "diagnostics"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _prune_diagnostics(d, keep_sets):
    """เก็บชุด diagnostics ล่าสุดไว้ ~keep_sets ชุด (ต่อชุด ~3 ไฟล์: png/html/url) กันดิสก์บวม"""
    try:
        files = sorted(d.glob("*"), key=lambda p: p.name)
        excess = len(files) - keep_sets * 3
        for f in files[:max(0, excess)]:
            try:
                f.unlink()
            except OSError:
                pass
    except Exception:
        pass


def capture_diagnostics(page, label="error", keep_sets=20):
    """บันทึกภาพหน้าจอ + HTML + URL ของหน้าปัจจุบัน (best-effort — ไม่ throw)

    ใช้เมื่อเกิดข้อผิดพลาดระหว่างค้น เพื่อให้ตรวจย้อนหลังได้ว่าเว็บ CRIMES
    เปลี่ยนหน้า/เปลี่ยน DOM ไปอย่างไร · คืน path ไฟล์ภาพ (หรือ None ถ้าบันทึกไม่ได้เลย)
    """
    try:
        d = _diag_dir()
        safe = re.sub(r"[^0-9A-Za-z_.-]+", "_", str(label))[:40] or "error"
        stem = f"{time.strftime('%Y%m%d-%H%M%S')}_{safe}"
        png = d / f"{stem}.png"
        html = d / f"{stem}.html"
        saved_png = None
        try:
            page.screenshot(path=str(png))
            saved_png = str(png)
        except Exception:
            pass
        saved_html = None
        try:
            html.write_text(page.content(), encoding="utf-8")
            saved_html = str(html)
        except Exception:
            pass
        try:
            (d / f"{stem}.url.txt").write_text(str(getattr(page, "url", "")), encoding="utf-8")
        except Exception:
            pass
        _prune_diagnostics(d, keep_sets)
        return saved_png or saved_html
    except Exception:
        return None


# ==================== บันทึกการทำงานโหมดทีละขั้น (manual recording) ====================
# เก็บ "สิ่งที่เกิดขึ้นจริงแต่ละสเต็ป" ตอนคนทำเอง (ทีละขั้น) เป็นข้อมูล ไว้เอาไปปรับ engine
# เมื่อเว็บ CRIMES เปลี่ยน DOM — ต่อ 1 สเต็ปเก็บ: คำอธิบาย + URL + ภาพหน้าจอ + HTML + ผล + เวลา
# 1 เซสชัน = 1 โฟลเดอร์ (recordings/manual_YYYYMMDD-HHMMSS): steps.jsonl + stepNNN.png/html + summary.json
def _recordings_dir():
    try:
        import config as _cfg
        d = Path(_cfg.DATA_DIR) / "recordings"
    except Exception:
        d = USER_DATA_DIR / "recordings"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _prune_recordings(base, keep_sessions):
    """เก็บเซสชันบันทึกล่าสุดไว้ ~keep_sessions เซสชัน (ลบเก่ากันดิสก์บวม)"""
    try:
        dirs = sorted([p for p in base.glob("manual_*") if p.is_dir()], key=lambda p: p.name)
        for d in dirs[:max(0, len(dirs) - keep_sessions)]:
            shutil.rmtree(d, ignore_errors=True)
    except Exception:
        pass


class ManualRecorder:
    """บันทึกการทำงานโหมดทีละขั้น (manual) เป็นข้อมูลไว้ปรับปรุงระบบเมื่อเว็บเปลี่ยน DOM"""

    def __init__(self, account="", keep_sessions=15):
        base = _recordings_dir()
        _prune_recordings(base, keep_sessions - 1)   # เผื่อที่ให้เซสชันใหม่
        # ชื่อชุดตามเวลา (วินาที) — ถ้าชนกัน (สร้างในวินาทีเดียวกัน) เติมลำดับกันชื่อซ้ำ
        stamp = "manual_" + time.strftime("%Y%m%d-%H%M%S")
        name, seq = stamp, 2
        while (base / name).exists():
            name = f"{stamp}-{seq}"
            seq += 1
        self.name = name
        self.dir = base / self.name
        self.dir.mkdir(parents=True, exist_ok=True)
        self.steps_path = self.dir / "steps.jsonl"
        self.n = 0
        self._cur = None
        self.account = account or ""
        self.context = ""
        self.started = time.strftime("%Y-%m-%d %H:%M:%S")

    def set_context(self, ctx):
        """บริบทของสเต็ปถัดไป เช่น เลขบัตรที่กำลังค้น (ปิดบังแล้ว)"""
        self.context = str(ctx or "")

    def step(self, page, desc):
        """เริ่มบันทึกสเต็ปใหม่ — เก็บภาพหน้าจอ + HTML ของหน้าปัจจุบัน (ก่อนลงมือทำ)"""
        self._flush()
        self.n += 1
        stem = "step%03d" % self.n
        rec = {"i": self.n, "time": time.strftime("%H:%M:%S"), "desc": str(desc),
               "context": self.context, "url": "", "shot": "", "html": "", "notes": []}
        try:
            rec["url"] = str(getattr(page, "url", "") or "")
        except Exception:
            pass
        try:
            page.screenshot(path=str(self.dir / (stem + ".png")))
            rec["shot"] = stem + ".png"
        except Exception:
            pass
        try:
            (self.dir / (stem + ".html")).write_text(page.content(), encoding="utf-8")
            rec["html"] = stem + ".html"
        except Exception:
            pass
        self._cur = rec

    def note(self, msg):
        """ผลของสเต็ปปัจจุบัน (เช่น กดปุ่มสำเร็จ / พบกี่คดี)"""
        if self._cur is not None:
            self._cur["notes"].append(str(msg))

    def _flush(self):
        if self._cur is None:
            return
        try:
            with open(self.steps_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(self._cur, ensure_ascii=False) + "\n")
        except Exception:
            pass
        self._cur = None

    def finish(self, page=None):
        """ปิดเซสชัน: เก็บสถานะสุดท้าย (ถ้ามีหน้า) + เขียน summary.json"""
        if page is not None:
            try:
                self.step(page, "สถานะสุดท้ายหลังจบการทำงาน")
            except Exception:
                pass
        self._flush()
        summary = {"name": self.name, "account": self.account, "started": self.started,
                   "finished": time.strftime("%Y-%m-%d %H:%M:%S"), "steps": self.n}
        try:
            (self.dir / "summary.json").write_text(
                json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
        return summary


def list_recordings(limit=50):
    """รายการเซสชันบันทึกโหมดทีละขั้น (ใหม่สุดก่อน)"""
    base = _recordings_dir()
    out = []
    try:
        dirs = sorted([p for p in base.glob("manual_*") if p.is_dir()],
                      key=lambda p: p.name, reverse=True)[:limit]
        for d in dirs:
            meta = {}
            sp = d / "summary.json"
            if sp.exists():
                try:
                    meta = json.loads(sp.read_text(encoding="utf-8"))
                except Exception:
                    meta = {}
            steps = meta.get("steps")
            if steps is None:
                try:
                    with open(d / "steps.jsonl", encoding="utf-8") as f:
                        steps = sum(1 for _ in f)
                except Exception:
                    steps = 0
            out.append({"name": d.name, "started": meta.get("started", ""),
                        "finished": meta.get("finished", ""),
                        "account": meta.get("account", ""), "steps": steps,
                        "done": bool(meta.get("finished"))})
    except Exception:
        pass
    return out


def recording_path(name):
    """คืน path โฟลเดอร์บันทึกถ้าชื่อถูกต้องและมีอยู่จริง (กัน path traversal)"""
    if not re.match(r"^manual_[0-9]{8}-[0-9]{6}(-[0-9]+)?$", name or ""):
        return None
    d = _recordings_dir() / name
    return d if d.is_dir() else None


def dismiss_announcement(page, note=None):
    """ปิดกล่องประกาศ/'มีอะไรใหม่' ของเว็บ CRIMES ถ้ามีเด้งอยู่ — คืน True ถ้าปิดไปจริง

    ทำงานเงียบ ๆ และต้องไม่โยน exception ออกไปเด็ดขาด: ถ้าหาไม่เจอก็แค่เดินต่อ
    เพราะกล่องนี้เด้งเฉพาะครั้งแรกหลังเว็บขึ้นเวอร์ชันใหม่เท่านั้น

    วิธีปิด เรียงตามลำดับที่ 'ปลอดภัยกับเว็บ' ที่สุดก่อน:
      1) ปุ่มยืนยันในกล่อง (เข้าใจแล้ว/รับทราบ/ตกลง) — เว็บจะจำว่าอ่านแล้ว ไม่เด้งซ้ำ
      2) ปุ่มกากบาทปิดของกล่อง
    จงใจไม่ใช้วิธีซ่อนด้วย CSS หรือลบ DOM ทิ้ง เพราะกล่องจะกลับมาเด้งใหม่ทุกครั้ง
    และอาจไปบังจังหวะอื่นระหว่างรอบค้นแทน
    """
    N = note or (lambda m: None)
    try:
        closed = page.evaluate(
            r"""(cfg) => {
              const norm = s => (s || '').replace(/\s+/g, '').toLowerCase();
              const vis = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                if (r.width < 1 || r.height < 1) return false;
                const st = getComputedStyle(el);
                return st.visibility !== 'hidden' && st.display !== 'none' && st.opacity !== '0';
              };
              // ไล่ 'จากปุ่มขึ้นไปหาหัวข้อ' ไม่ใช่หากล่องก่อนแล้วค่อยหาปุ่ม —
              // เพราะกล่องชั้นในสุดที่มีหัวข้ออยู่ มักไม่ได้มีปุ่มยืนยันอยู่ด้วย
              // (ในกล่องจริง หัวข้ออยู่บนสุด ปุ่มอยู่ล่างสุด คนละกิ่งกัน)
              const titles = cfg.titles.map(norm);
              // ปุ่มนั้นอยู่ในกล่องประกาศจริงไหม: เดินขึ้นบรรพบุรุษหาองค์ประกอบที่มีหัวข้อ
              // ไม่นับ body/html เพื่อกันไปกดปุ่มชื่อเดียวกันที่อยู่บนหน้าปกติ
              const inAnnounceBox = (btn) => {
                let p = btn.parentElement, depth = 0;
                while (p && p !== document.body && p !== document.documentElement && depth++ < 12) {
                  if (titles.some(x => norm(p.textContent).includes(x))) return true;
                  p = p.parentElement;
                }
                return false;
              };
              const btns = Array.from(document.querySelectorAll(
                  'button,[role=button],a,.btn,nb-button')).filter(vis);
              for (const want of cfg.buttons) {
                const w = norm(want);
                const hit = btns.find(b => norm(b.textContent) === w && inAnnounceBox(b));
                if (hit) { hit.click(); return want; }
              }
              // ไม่เจอปุ่มยืนยัน → ลองปุ่มปิด (กากบาท) ที่อยู่ในกล่องเดียวกัน
              const x = btns.find(b => {
                if (!inAnnounceBox(b)) return false;
                const lab = norm(b.getAttribute('aria-label')) + norm(b.title) + norm(b.className);
                return lab.includes('close') || lab.includes('ปิด')
                       || ['×', '✕', 'x'].includes(norm(b.textContent));
              });
              if (x) { x.click(); return 'ปุ่มปิด'; }
              return '';
            }""",
            {"buttons": list(ANNOUNCE_BUTTON_TEXTS), "titles": list(ANNOUNCE_TITLE_TEXTS)},
        )
    except Exception:
        return False
    if closed:
        N(f"ปิดกล่องประกาศของเว็บ CRIMES แล้ว (กด '{closed}')")
        sleep_range(0.3, 0.7)
        return True
    return False


def _find_id_input_selector(page):
    """หา selector ของช่องกรอกเลขบัตรบนหน้าค้นหา — คืน selector หรือ None ถ้าไม่พบ
    (None = หน้าเว็บ CRIMES เปลี่ยน DOM ไปแล้ว ไม่มีช่องกรอกเลขบัตรตามที่คาด)"""
    for sel in ID_INPUT_SELECTORS:
        try:
            if page.locator(sel).count() > 0:
                return sel
        except Exception:
            pass
    return None


def search_one_id(page, national_id, pause=None, note=None, reason=None):
    """ค้นเลขบัตร 1 หมายเลข

    pause(desc)->bool : เรียกก่อนแต่ละขั้น — ถ้าคืน False = ถูกสั่งหยุด (คืน None)
                        ในโหมดปกติไม่ต้องส่ง (เดินต่อทุกขั้นอัตโนมัติ)
    note(msg)         : เรียกเพื่อรายงานผลของแต่ละขั้น (เช่น กดปุ่มค้นหาสำเร็จ, พบกี่คดี)
    """
    P = pause or (lambda d: True)
    N = note or (lambda m: None)

    if not P("เปิดหน้าค้นหา CRIMES"):
        return None
    page.goto(SEARCH_URL, wait_until="networkidle")
    sleep_range(0.3, 0.8)

    # เว็บ CRIMES เด้งกล่อง 'มีอะไรใหม่' หลังขึ้นเวอร์ชันใหม่ — ครอบทับทั้งหน้าจนกดอะไรไม่ได้
    # ต้องปิดก่อนเสมอ ไม่งั้นรอบค้นค้างทั้งรอบโดยไม่มีใครรู้สาเหตุ
    dismiss_announcement(page, note=N)

    # self-check: หน้าค้นหาต้องมีช่องกรอกเลขบัตร — ถ้าไม่มี แปลว่าเว็บเปลี่ยน DOM
    id_selector = _find_id_input_selector(page)
    if not id_selector:
        # อาจเป็นเพราะกล่องประกาศแบบใหม่ยังบังอยู่ — ลองปิดอีกรอบแล้วหาใหม่ก่อนยอมแพ้
        if dismiss_announcement(page, note=N):
            id_selector = _find_id_input_selector(page)
    if not id_selector:
        shot = capture_diagnostics(page, "no-id-input")
        raise RuntimeError(
            "หน้าค้นหา CRIMES เปลี่ยนไป — ไม่พบช่องกรอกเลขบัตร (#inputPid) "
            "อาจต้องอัปเดต selector"
            + (f" · บันทึกหลักฐานไว้ที่ {shot}" if shot else ""))

    if not P(f"กรอกเลขบัตร {_mask_id(national_id)} ในช่อง ({id_selector})"):
        return None
    human_type(page, id_selector, national_id)
    N(f"กรอกเลขบัตรลงช่อง {id_selector} แล้ว")
    sleep_range(0.2, 0.5)

    # ก่อนค้นทุกครั้ง: ติ๊ก 'คดีอาญา' ช่องเดียว เอาช่องอื่นออกทั้งหมด
    if not P("ติ๊ก 'คดีอาญา' ช่องเดียว (เอาช่องอื่นออก)"):
        return None
    ensure_checkboxes(page)
    N("ติ๊ก 'คดีอาญา' ช่องเดียวแล้ว")
    sleep_range(0.2, 0.6)

    if not P("กดปุ่มค้นหา"):
        return None
    clicked = click_search(page)
    N("กดปุ่มค้นหา: " + ("สำเร็จ ✓" if clicked else "ไม่พบปุ่ม/กดไม่ได้ ✗"))
    sleep_range(0.3, 0.7)

    # ป๊อบอัพระบุเหตุผล: ติ๊ก 'ตรวจสอบทั่วไป' + เหตุผล (สุ่มข้อความ) + กดยืนยันค้นหา
    # (การกดยืนยันในป๊อบอัพนี้คือสิ่งที่สั่งให้ระบบเริ่มค้นจริง)
    # สุ่มข้อความเหตุผลไว้ก่อน เพื่อให้ข้อความที่แจ้งในสเต็ปตรงกับที่พิมพ์ลงป๊อบอัพจริง
    reason_text = reason if reason else pick_search_reason()
    if not P(f"ยืนยันเหตุผลค้นหา: ติ๊ก '{SEARCH_REASON_LABEL}' + ระบุ '{reason_text}'"):
        return None
    confirm_status = confirm_search_reason(page, reason=reason_text, note=N)
    try:
        page.wait_for_load_state("networkidle", timeout=20000)
    except PWTimeout:
        pass

    if not P("รอผลการค้นเรนเดอร์ แล้วอ่านจำนวนคดีอาญา"):
        return None
    # รอจนผลการค้นเรนเดอร์จริง (กันอ่านจำนวน 0 ทั้งที่ยังโหลดไม่เสร็จ)
    wait_for_results(page)
    sleep_range(0.4, 0.9)

    count = get_result_count(page)
    rows_preview = read_table_rows(page)
    # ถ้าอ่านจำนวนจากข้อความไม่ได้ (-1) หรือได้ 0 แต่มีแถวจริงในตาราง → ยึดตามตาราง
    if count <= 0 and rows_preview:
        count = len(rows_preview)

    # ⚠ สำคัญ: ห้ามปล่อยให้ "การค้นที่ยังไม่เคยทำงาน" ถูกบันทึกเป็น 'ไม่พบคดี'
    # เพราะผู้เรียกจะเขียน ' - ' ลง Excel + บันทึกประวัติ notfound แล้วการรันซ้ำจะกู้ผลเท็จ
    # นั้นมาใช้จนข้ามการค้นถาวร (คนมีคดีกลายเป็นไม่มีคดี) → โยน error ให้บันทึกเป็น ERROR แทน
    #
    # (ก) กดยืนยันไม่สำเร็จ/ป๊อบอัพค้าง = การค้นยังไม่ถูกสั่งทำงานแน่นอน
    #     ตัวเลขใด ๆ บนหน้าจอเป็นของเก่าที่ค้างอยู่ เชื่อไม่ได้ทั้งสิ้น "แม้จะอ่านได้เป็น 0"
    #     (หน้าค้นหาอาจมีข้อความ '(0 รายการ)' ค้างอยู่ ทำให้ get_result_count คืน 0 ไม่ใช่ -1)
    if confirm_status == "click_failed":
        shot = capture_diagnostics(page, "confirm-failed")
        raise RuntimeError(
            "กดยืนยันเหตุผลค้นหาไม่สำเร็จ (ป๊อบอัพยังค้าง/ปุ่มยืนยันเปลี่ยน) — "
            "การค้นยังไม่ถูกสั่งทำงาน จึงไม่บันทึกผลเพื่อกันข้อมูลผิดพลาด"
            + (f" · บันทึกหลักฐานไว้ที่ {shot}" if shot else ""))

    # (ข) ป๊อบอัพไม่ขึ้นเลย + อ่านผลไม่ได้ + ไม่มีแถวในตาราง = ไม่มีหลักฐานว่าค้นสำเร็จ
    if confirm_status == "no_popup" and count < 0 and not rows_preview:
        shot = capture_diagnostics(page, "no-confirm-no-result")
        raise RuntimeError(
            "ไม่พบป๊อบอัพระบุเหตุผล และอ่านผลการค้นไม่ได้ — ไม่มีหลักฐานว่าการค้นทำงานจริง "
            "จึงไม่บันทึกผลเพื่อกันข้อมูลผิดพลาด"
            + (f" · บันทึกหลักฐานไว้ที่ {shot}" if shot else ""))

    N(f"จำนวนคดีอาญาที่พบ: {max(count, 0)} รายการ")
    if count <= 0:
        return []

    cases = []
    while True:
        rows = read_table_rows(page)
        for idx, row in enumerate(rows):
            entry = {"returned_id": row["id"], "table_id": row["id"], "status": row["status"]}
            status = row["status"] or ""
            # เก็บเฉพาะสถานะ 'ผู้ต้องหา' เท่านั้น — ถ้าสถานะในตารางระบุชัดว่าไม่ใช่ ให้ข้ามทันที
            if status and "ผู้ต้องหา" not in status:
                entry["skip"] = True
                N(f"คดีลำดับ {idx+1}: สถานะ '{status}' ไม่ใช่ผู้ต้องหา → ข้าม")
                cases.append(entry)
                continue

            if P(f"เปิดคดีลำดับ {idx+1} (สถานะผู้ต้องหา) เพื่ออ่านรายละเอียด") is False:
                return None
            click_row(page, idx)
            sleep_range(0.5, 1.2)
            try:
                page.wait_for_url(lambda u: DETAIL_HASH in u, timeout=10000)
            except PWTimeout:
                pass

            data = get_detail_data(page)
            detail_status = data["status"] or row["status"] or ""
            # ยืนยันจากหน้ารายละเอียด: ต้องเป็น 'ผู้ต้องหา' เท่านั้น มิฉะนั้นข้าม
            if "ผู้ต้องหา" not in detail_status:
                entry["skip"] = True
                entry["status"] = detail_status
                N(f"คดีลำดับ {idx+1}: หน้ารายละเอียดสถานะ '{detail_status}' ไม่ใช่ผู้ต้องหา → ข้าม")
                cases.append(entry)
            else:
                # ปี: ใช้ช่อง 'ปีที่คดี' ก่อน ถ้าไม่ได้ค่อย regex จาก caseNo
                year = data.get("yearField", "").strip()
                if not re.fullmatch(r"\d{4}", year):
                    year = extract_year(data["caseNo"])
                entry["skip"] = False
                entry["charge"] = (data["charge"] or "").strip()
                entry["year"] = year
                entry["case_no"] = data["caseNo"]
                entry["table_id"] = row["id"]
                entry["returned_id"] = data["returnedId"] or row["id"]
                entry["status"] = detail_status
                N(f"คดีลำดับ {idx+1}: {entry['charge'] or '(ไม่ระบุข้อหา)'} ปี {year} (ผู้ต้องหา) → บันทึก")
                cases.append(entry)

            sleep_range(0.4, 1.0)
            page.locator('button:has-text("ย้อนกลับ")').click()
            try:
                page.wait_for_url(lambda u: CRITERIA_HASH in u, timeout=10000)
            except PWTimeout:
                pass
            sleep_range(0.3, 0.8)

        if not go_to_next_page(page):
            break
        sleep_range(0.5, 1.0)
        try:
            page.wait_for_load_state("networkidle", timeout=10000)
        except PWTimeout:
            pass

    return cases


def save_workbook_report(wb, xlsx):
    """บันทึกไฟล์ แล้วคืน (path|None, status, message)

    status:
      "ok"     = บันทึกทับไฟล์ต้นทางสำเร็จ
      "backup" = ไฟล์ต้นทางถูกเปิดค้าง — บันทึกเป็น _backup.xlsx แทน (path = ไฟล์ backup)
      "failed" = บันทึกไม่ได้เลย (path = None) — ข้อมูลที่ค้นได้ยังไม่ถูกเขียนลงไฟล์
    """
    xlsx = Path(xlsx)
    try:
        wb.save(xlsx)
        return xlsx, "ok", ""
    except PermissionError:
        backup = xlsx.with_name(xlsx.stem + "_backup.xlsx")
        try:
            wb.save(backup)
            return (backup, "backup",
                    f"ไฟล์ต้นฉบับ '{xlsx.name}' กำลังถูกเปิดอยู่ (เช่นเปิดค้างใน Excel) "
                    f"จึงบันทึกผลไว้ที่ '{backup.name}' แทน — โปรดปิดไฟล์ต้นฉบับเพื่อให้บันทึกทับได้ตามปกติ")
        except PermissionError as e:
            return (None, "failed",
                    f"บันทึกไม่ได้ — ทั้ง '{xlsx.name}' และไฟล์สำรองถูกล็อกอยู่ ({e}). "
                    f"โปรดปิดไฟล์ Excel ที่เปิดค้าง แล้วกดเริ่มค้นใหม่ (ระบบจะค้นต่อจากเดิม)")
        except Exception as e:
            return None, "failed", f"บันทึกไฟล์สำรองไม่ได้: {e}"
    except OSError as e:
        return (None, "failed",
                f"บันทึก '{xlsx.name}' ไม่ได้ (ดิสก์เต็ม/สิทธิ์ไม่พอ?): {e}")
    except Exception as e:
        return None, "failed", f"บันทึก '{xlsx.name}' ไม่ได้: {e}"


def save_workbook(wb, xlsx):
    """Try to save; on PermissionError save next to original as _backup.xlsx.
    คงพฤติกรรมเดิมสำหรับ CLI — คืน path ที่บันทึกได้ (หรือ None ถ้าล้มเหลว)."""
    path, status, message = save_workbook_report(wb, xlsx)
    if message:
        print("  [!] " + message)
    return path


def col_letter_to_num(letter):
    letter = letter.strip().upper()
    n = 0
    for c in letter:
        n = n * 26 + (ord(c) - 64)
    return n


# ---- ตรวจจับคอลัมน์อัตโนมัติ (หาเลขบัตรประชาชน 13 หลัก) ----
# คำใบ้จากหัวคอลัมน์ (แถวแรก) — ใช้ช่วยตัดสินเมื่อมีหลายคอลัมน์ที่เป็นตัวเลข
ID_HEADER_HINTS = (
    "บัตรประชาชน", "ประชาชน", "เลขบัตร", "เลขประจำตัว", "ปชช", "บัตร ปชช",
    "citizen", "national", "idcard", "id card", "id no", "nationalid",
)
def _digits_only(v):
    return re.sub(r"\D", "", str(v)) if v is not None else ""


def _mask_id(nid):
    """ปิดเลขบัตรสำหรับแสดงในบันทึก/สเต็ป (แสดง ~30% ปิด ~70%) — กันข้อมูลหลุดทางหน้าจอ"""
    d = _digits_only(nid)
    if not d:
        return str(nid or "")
    show = max(1, round(len(d) * 0.3))
    return d[:show] + "X" * (len(d) - show) if show < len(d) else d


# หัวคอลัมน์ที่แปลว่า 'ช่องเขียนผลคดี' แบบตรงตัว (เทียบเป๊ะ)
RESULT_EXACT_HEADERS = {
    "ผล", "คดี", "ผลคดี", "ผลการตรวจ", "ผลการค้น", "ผลการตรวจสอบ",
    "ประวัติ", "ประวัติคดี", "ประวัติอาชญากรรม", "result", "criminal record",
}


def _is_result_header(text):
    """หัวคอลัมน์ที่ 'สื่อถึงช่องเขียนผลคดี' อย่างชัดเจน

    ต้องเป็นหัวสั้นๆ ที่เป็นคำว่าผล/คดีจริงๆ — ไม่ใช่คำอธิบายยาวของช่องอินพุต
    เช่น 'Y - ผ่าน, ... N - ไม่ผ่านผลการตรวจสอบ' หรือ 'ไม่มีประวัติ Y=ผ่าน...'
    ซึ่งบังเอิญมีคำว่า 'ผลการตรวจสอบ'/'ประวัติ' อยู่ข้างใน
    """
    low = (text or "").strip().lower()
    if not low:
        return False
    if low in RESULT_EXACT_HEADERS:
        return True
    # หัวสั้น (<=20 ตัว) ที่ขึ้นต้นด้วยคำว่าผล/คดี/ประวัติอาชญากร เท่านั้น
    if len(low) <= 20 and (low.startswith("ผลคดี") or low.startswith("ผลการตรวจ")
                           or low.startswith("ประวัติอาชญากร") or low == "ผล" or low == "คดี"):
        return True
    return False


def _pick_out_col(id_col, max_col, header_vals, filled):
    """เลือกคอลัมน์เขียนผล: (1) หัวคอลัมน์ที่แปลว่า 'ผล' ชัดเจน
    (2) คอลัมน์แรกที่ยังไม่มีหัว (ช่องว่างที่ยังไม่ถูกใช้) ถัดจากคอลัมน์เลขบัตร
    (3) คอลัมน์ข้อมูลว่างถัดจากเลขบัตร  (4) คอลัมน์ถัดไป"""
    for col in range(1, max_col + 2):
        if col == id_col:
            continue
        if _is_result_header(header_vals.get(col, "")):
            return col
    for col in range(id_col + 1, max_col + 2):
        if not (header_vals.get(col, "") or "").strip():
            return col
    for col in range(id_col + 1, max_col + 2):
        if filled.get(col, 0) == 0:
            return col
    return id_col + 1


def _make_signature(header_vals):
    """สร้างลายเซ็นของรูปแบบไฟล์จากหัวตาราง (ใช้จดจำ/เรียนรู้รูปแบบไฟล์)
    header_vals: dict {col_index: text}. คืน (signature|None, headers_by_letter)"""
    from openpyxl.utils import get_column_letter
    headers = {get_column_letter(c): (header_vals.get(c, "") or "").strip()
               for c in header_vals}
    if not any(headers.values()):
        return None, headers
    parts = [f"{k}:{v.lower()}" for k, v in sorted(headers.items())]
    sig = hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()[:16]
    return sig, headers


def read_header_signature(path, sheet=None, max_scan_col=60):
    """อ่านเฉพาะแถวหัวตาราง เพื่อคำนวณลายเซ็นรูปแบบไฟล์ (เบา ใช้ตอน override/เช็คของที่จำไว้)"""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb[sheet] if sheet else wb.active
        mc = min(ws.max_column or 1, max_scan_col)
        header_vals = {}
        first = next(ws.iter_rows(min_row=1, max_row=1, max_col=mc), None)
        if first:
            for ci, cell in enumerate(first, start=1):
                header_vals[ci] = "" if cell.value is None else str(cell.value).strip()
    finally:
        wb.close()
    return _make_signature(header_vals)


def detect_columns(path, sheet=None, sample_rows=400):
    """สแกนไฟล์ Excel เพื่อหาคอลัมน์ที่เป็นเลขบัตรประชาชน 13 หลักโดยอัตโนมัติ

    คืน dict: {id_col, out_col, start_row, id_count, rows, header}  หรือ None ถ้าหาไม่พบ
    - id_col  : คอลัมน์ที่มีเลข 13 หลักมากที่สุด (ชนะด้วยคำใบ้หัวคอลัมน์)
    - out_col : คอลัมน์เขียนผล — เลือกจากหัวคอลัมน์ที่สื่อถึง 'ผล/คดี' ก่อน,
                ไม่งั้นใช้คอลัมน์ว่างถัดจากคอลัมน์เลขบัตร
    - start_row: 2 ถ้าแถวแรกเป็นหัวตาราง, 1 ถ้าแถวแรกเป็นข้อมูลเลย
    """
    import openpyxl
    from openpyxl.utils import get_column_letter

    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb[sheet] if sheet else wb.active
        max_col = min(ws.max_column or 1, 60)
        header_vals = {}
        exact13 = {}   # col -> จำนวนเซลล์ที่เป็นเลข 13 หลักพอดี
        idlike = {}    # col -> จำนวนเซลล์ตัวเลขยาว 9–13 หลัก (เผื่อเลขศูนย์นำหาย)
        filled = {}    # col -> จำนวนเซลล์ที่มีค่า (แถวข้อมูล)
        r_idx = 0
        for row in ws.iter_rows(min_row=1, max_row=sample_rows + 1, max_col=max_col):
            r_idx += 1
            if r_idx == 1:
                for ci, cell in enumerate(row, start=1):
                    header_vals[ci] = "" if cell.value is None else str(cell.value).strip()
                continue
            for ci, cell in enumerate(row, start=1):
                if cell.value is None or str(cell.value).strip() == "":
                    continue
                col = ci
                filled[col] = filled.get(col, 0) + 1
                d = _digits_only(cell.value)
                if len(d) == 13:
                    exact13[col] = exact13.get(col, 0) + 1
                if 9 <= len(d) <= 13:
                    idlike[col] = idlike.get(col, 0) + 1
    finally:
        wb.close()

    # เลือกคอลัมน์เลขบัตร: นับเลข 13 หลักเป็นหลัก, ไม่มีเลยค่อยใช้ 9–13 หลัก
    metric = exact13 if exact13 else idlike
    if not metric:
        return None
    best_col, best_score = None, -1
    for col, cnt in metric.items():
        score = cnt
        hv = (header_vals.get(col, "") or "").lower()
        if any(h in hv for h in ID_HEADER_HINTS):
            score += 100000
        if score > best_score:
            best_score, best_col = score, col
    if best_col is None:
        return None

    # แถวเริ่ม: ถ้าหัวคอลัมน์ (แถว 1) ของคอลัมน์นั้นไม่ใช่เลข 13 หลัก ถือว่าเป็นหัวตาราง
    hdr_digits = _digits_only(header_vals.get(best_col, ""))
    start_row = 1 if len(hdr_digits) == 13 else 2

    # คอลัมน์เขียนผล
    out_col = _pick_out_col(best_col, max_col, header_vals, filled)

    signature, headers = _make_signature(header_vals)

    return {
        "id_col": get_column_letter(best_col),
        "out_col": get_column_letter(out_col),
        "start_row": start_row,
        "id_count": exact13.get(best_col, 0),
        "rows": filled.get(best_col, 0),
        "header": header_vals.get(best_col, ""),
        "signature": signature,
        "headers": headers,
    }


def _process_row(page, ws, row, id_col, out_col, no_year):
    """Process one row. Returns ('ok'|'skip'|'error', detail_str)."""
    cell_b = ws.cell(row=row, column=id_col)
    raw = cell_b.value
    if raw is None or str(raw).strip() == "":
        return "end", ""

    cell_f = ws.cell(row=row, column=out_col)
    if cell_f.value is not None and str(cell_f.value).strip() != "":
        return "skip", ""

    normalized, padded, invalid = normalize_id(raw)
    if invalid:
        return "skip", f"ใช้ไม่ได้ {raw!r}"

    if padded:
        cell_b.fill = YELLOW
        cell_b.value = normalized

    cases = search_one_id(page, normalized)

    kept = [c for c in cases if not c.get("skip")]

    # RED: ถ้า id ที่ระบบคืนมา (ในตาราง) ต่างจากเลขที่ค้น แม้แต่แถวเดียว
    any_diff = any(
        c.get("table_id") and re.sub(r"\D", "", c["table_id"]) not in ("", normalized)
        for c in cases
    )
    if any_diff:
        cell_b.fill = RED

    if kept:
        def fmt(i, c):
            charge = c.get("charge", "").strip() or "(ไม่ระบุข้อหา)"
            if no_year:
                return f"คดีที่{i+1} {charge}"
            year = c.get("year", "").strip()
            return f"คดีที่{i+1} {charge} ปี{year}"
        parts = [fmt(i, c) for i, c in enumerate(kept)]
        ws.cell(row=row, column=out_col).value = "/ ".join(parts)
        return "ok", f"พบ {len(kept)} คดี"
    else:
        ws.cell(row=row, column=out_col).value = " - "
        return "ok", "ไม่พบคดี"


# ข้อความบ่งชี้ว่าเป็นข้อผิดพลาด 'ถาวร' — retry ไปก็ไม่หาย จึงไม่ควรเสียรอบยิงเว็บซ้ำ
_PERMANENT_ERROR_HINTS = ("เปลี่ยนไป", "อัปเดต selector", "ใช้ไม่ได้")


def is_retryable_error(msg):
    """คืน False ถ้า error เป็นชนิดถาวร (เว็บเปลี่ยน DOM / เลขบัตรใช้ไม่ได้) ที่ retry แล้วก็ไม่สำเร็จ
    คืน True สำหรับข้อผิดพลาดชั่วคราว (timeout, โหลดหน้าไม่ทัน ฯลฯ) ที่ควรลองใหม่"""
    m = str(msg or "")
    return not any(h in m for h in _PERMANENT_ERROR_HINTS)


# ---- ตรวจอาการ 'เน็ตหลุด/เข้าเว็บไม่ถึง' (ใช้ตัดสินพักอัตโนมัติ ไม่ให้เสียโควตาค้นซ้ำ) ----
# ชื่อ error ตระกูล net:: ของ Chromium ที่แปลว่าเครือข่ายมีปัญหา (ไม่ใช่เว็บเปลี่ยน DOM)
_NETWORK_ERROR_HINTS = (
    "err_internet_disconnected", "err_name_not_resolved", "err_connection_refused",
    "err_connection_reset", "err_connection_timed_out", "err_connection_closed",
    "err_connection_aborted", "err_network_changed", "err_address_unreachable",
    "err_proxy_connection_failed", "err_timed_out", "err_empty_response",
    "err_network_access_denied", "getaddrinfo failed", "net::",
)

# โฮสต์ของระบบ CRIMES — ใช้เช็คการเชื่อมต่อจริง (probe_online)
SEARCH_HOST = "bdasearch.crimespolice.com"


def is_network_error(err):
    """True ถ้า error มีลักษณะ 'เครือข่ายล่ม/เข้าเว็บไม่ถึง' (คนละอย่างกับเว็บเปลี่ยน DOM)"""
    s = str(err or "").lower()
    return any(h in s for h in _NETWORK_ERROR_HINTS)


def probe_online(timeout=4):
    """เช็คว่าเครื่องยังเชื่อมต่อถึงเซิร์ฟเวอร์ CRIMES ได้จริง (เปิด TCP 443 เฉย ๆ)
    เร็ว ไม่ผ่านหน้าค้นหา จึงไม่กินโควตาการค้น — ใช้ยืนยันก่อนพัก/ก่อนกลับมาค้นต่อ"""
    import socket
    try:
        socket.create_connection((SEARCH_HOST, 443), timeout=timeout).close()
        return True
    except OSError:
        return False


def process_file(page, job):
    xlsx = Path(job["path"]).resolve()
    if not xlsx.exists():
        print(f"[!] ข้าม: ไม่พบไฟล์ {xlsx}")
        return
    id_col = col_letter_to_num(job.get("id_col", "B"))
    out_col = col_letter_to_num(job.get("out_col", "F"))
    no_year = bool(job.get("no_year", False))
    start_row = int(job.get("start_row", 2))
    end_row = job.get("end_row")
    end_row = int(end_row) if end_row is not None else None
    sheet = job.get("sheet")

    wb = openpyxl.load_workbook(xlsx)
    ws = wb[sheet] if sheet else wb.active

    print("\n" + "=" * 60)
    print(f"ไฟล์: {xlsx.name}")
    range_str = f"start_row={start_row}" + (f"  end_row={end_row}" if end_row else "")
    print(f"  id_col={job.get('id_col','B')}  out_col={job.get('out_col','F')}  no_year={no_year}  {range_str}")
    print("=" * 60)

    retry_only = bool(job.get("retry_only", False))

    if retry_only:
        # Mode: process only rows whose F starts with "ERROR"
        target_rows = []
        r = start_row
        while True:
            if end_row is not None and r > end_row:
                break
            b = ws.cell(row=r, column=id_col).value
            if b is None or str(b).strip() == "":
                break
            f = ws.cell(row=r, column=out_col).value
            if f and str(f).strip().startswith("ERROR"):
                target_rows.append(r)
            r += 1
        print(f"[retry-only] พบ {len(target_rows)} แถวที่ต้อง retry")

        processed = 0
        still_error = []
        for r in target_rows:
            # Clear the error marker first so _process_row treats it as fresh
            ws.cell(row=r, column=out_col).value = None
            b = ws.cell(row=r, column=id_col).value
            print(f"[{r}] retry {str(b).strip()[:13]}", end=" ... ", flush=True)
            try:
                status, msg = _process_row(page, ws, r, id_col, out_col, no_year)
                print(msg if status == "ok" else f"({status}) {msg}")
                if status == "ok":
                    processed += 1
            except Exception as e:
                err_msg = f"ERROR: {str(e)[:100]}"
                ws.cell(row=r, column=out_col).value = err_msg
                print(err_msg[:90])
                still_error.append(r)
            if processed and processed % 5 == 0:
                save_workbook(wb, xlsx)
            sleep_range(1.0, 2.5)
        final = save_workbook(wb, xlsx)
        print(f"จบ retry — สำเร็จ {processed}, ยัง ERROR {len(still_error)} → {final}")
        if still_error:
            print(f"   แถว ERROR เหลือ: {still_error}")
        return

    # First pass: process all rows, collect errors
    row = start_row
    processed = 0
    skipped = 0
    error_rows = []
    while True:
        if end_row is not None and row > end_row:
            break
        cell_b = ws.cell(row=row, column=id_col)
        raw = cell_b.value
        if raw is None or str(raw).strip() == "":
            break
        cell_f = ws.cell(row=row, column=out_col)
        f_val = str(cell_f.value).strip() if cell_f.value else ""
        if f_val and not f_val.startswith("ERROR"):
            skipped += 1
            row += 1
            continue
        if f_val.startswith("ERROR"):
            cell_f.value = None  # clear so we retry

        print(f"[{row}] ค้น {str(raw).strip()[:13]}", end=" ... ", flush=True)
        try:
            status, msg = _process_row(page, ws, row, id_col, out_col, no_year)
            if status == "ok":
                print(msg)
                processed += 1
            elif status == "skip":
                print(f"ข้าม ({msg})")
            elif status == "end":
                break
        except Exception as e:
            err_msg = f"ERROR: {str(e)[:100]}"
            ws.cell(row=row, column=out_col).value = err_msg
            print(err_msg[:90])
            shot = capture_diagnostics(page, f"row{row}")
            if shot:
                print(f"  (บันทึกหน้าจอ/HTML ไว้ที่ {shot})")
            error_rows.append((row, err_msg))
            save_workbook(wb, xlsx)
            sleep_range(2, 4)

        if processed and processed % 5 == 0:
            save_workbook(wb, xlsx)
        sleep_range(1.0, 2.5)
        row += 1

    save_workbook(wb, xlsx)

    # Retry pass — เฉพาะ error ชั่วคราว (ข้าม error ถาวร เช่นเว็บเปลี่ยน DOM เพื่อไม่เสียรอบยิงเว็บ)
    if error_rows:
        retry_rows = [r for (r, m) in error_rows if is_retryable_error(m)]
        permanent = [r for (r, m) in error_rows if not is_retryable_error(m)]
        if permanent:
            print(f"[!] ข้าม retry {len(permanent)} แถวที่เป็นข้อผิดพลาดถาวร (คงผลเดิมไว้): {permanent}")
        print(f"\n--- รอบ retry — {len(retry_rows)} แถว ---")
        still_error = []
        for r in retry_rows:
            ws.cell(row=r, column=out_col).value = None
            print(f"[{r}] retry", end=" ... ", flush=True)
            try:
                status, msg = _process_row(page, ws, r, id_col, out_col, no_year)
                print(msg if status == "ok" else f"({status}) {msg}")
                if status == "ok":
                    processed += 1
            except Exception as e:
                err_msg = f"ERROR: {str(e)[:100]}"
                ws.cell(row=r, column=out_col).value = err_msg
                print(err_msg[:90])
                still_error.append(r)
            sleep_range(1.5, 3.0)
        save_workbook(wb, xlsx)
        if still_error:
            print(f"[!] ยังมี {len(still_error)} แถวที่ทำไม่สำเร็จ: {still_error}")

    final = save_workbook(wb, xlsx)
    print(f"จบไฟล์ — ประมวลผล {processed} แถว, ข้าม {skipped} แถว → {final}")


# ยึด queue.json ไว้ที่ชั้นข้อมูลของ backend เสมอ (ไม่ขึ้นกับ cwd ที่รัน)
try:
    import sys as _sys
    _sys.path.insert(0, str(Path(__file__).resolve().parent))
    from config import QUEUE_PATH as _QP
    DEFAULT_QUEUE = str(_QP)
except Exception:
    DEFAULT_QUEUE = str(Path(__file__).resolve().parent / "data" / "queue.json")


def load_queue(path=DEFAULT_QUEUE):
    p = Path(path)
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return []


def save_queue(jobs, path=DEFAULT_QUEUE):
    Path(path).write_text(
        json.dumps(jobs, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def _ask(label, default=""):
    s = input(f"{label}{' ['+default+']' if default else ''}: ").strip()
    return s or default


def make_job_from_path(path, interactive=True):
    """สร้าง job dict จาก path — ถามค่าจากผู้ใช้ถ้า interactive"""
    job = {"path": str(Path(path).resolve()).replace("\\", "/")}
    if interactive:
        print(f"\nไฟล์: {Path(path).name}")
        job["id_col"] = _ask("  คอลัมน์เลขบัตร", "B").upper()
        job["out_col"] = _ask("  คอลัมน์เขียนผล", "F").upper()
        ny = _ask("  ไม่ใส่ปี? (y/N)", "N").lower()
        job["no_year"] = ny.startswith("y")
        sr = _ask("  start_row", "2")
        try:
            job["start_row"] = int(sr)
        except ValueError:
            job["start_row"] = 2
        er = _ask("  end_row (Enter=สุดไฟล์)", "")
        if er:
            try:
                job["end_row"] = int(er)
            except ValueError:
                pass
    else:
        job["id_col"] = "B"
        job["out_col"] = "F"
        job["no_year"] = False
    return job


def _suggest_similar(missing_path):
    """แนะนำไฟล์ที่ขึ้นต้นเหมือนกันในโฟลเดอร์เดียวกัน"""
    try:
        target = Path(missing_path)
        folder = target.parent
        if not folder.exists():
            return []
        stem_prefix = target.stem[:15]  # ตัด 15 ตัวแรกของชื่อ
        cand = []
        for f in folder.iterdir():
            if f.suffix.lower() == ".xlsx" and f.stem.startswith(stem_prefix):
                cand.append(f)
        return cand[:5]
    except Exception:
        return []


def cmd_add(paths, queue_path=DEFAULT_QUEUE, interactive=True):
    """เพิ่มไฟล์เข้าคิว — ข้ามไฟล์ที่ไม่มีอยู่จริง / ไม่ใช่ .xlsx"""
    jobs = load_queue(queue_path)
    added = 0
    for p in paths:
        pp = Path(p)
        if not pp.exists():
            print(f"[!] ไม่พบไฟล์: {p}")
            sugg = _suggest_similar(p)
            if sugg:
                print("    ใกล้เคียง:")
                for s in sugg:
                    print(f"      {s}")
            continue
        if pp.suffix.lower() != ".xlsx":
            print(f"[!] ไม่ใช่ .xlsx: {p}")
            continue
        # กันซ้ำ
        norm = str(pp.resolve()).replace("\\", "/")
        if any(str(Path(j["path"]).resolve()).replace("\\", "/") == norm for j in jobs):
            print(f"[!] มีในคิวแล้ว: {pp.name}")
            continue
        jobs.append(make_job_from_path(pp, interactive=interactive))
        added += 1
    save_queue(jobs, queue_path)
    print(f"\nเพิ่ม {added} ไฟล์ — คิวรวม {len(jobs)} ไฟล์")


def cmd_list(queue_path=DEFAULT_QUEUE):
    jobs = load_queue(queue_path)
    if not jobs:
        print("คิวว่างเปล่า")
        return
    print(f"คิวมี {len(jobs)} ไฟล์:")
    for i, j in enumerate(jobs, 1):
        ny = "no-year" if j.get("no_year") else "with-year"
        rng = ""
        if j.get("start_row") or j.get("end_row"):
            rng = f" [{j.get('start_row',2)}-{j.get('end_row','end')}]"
        print(f"  {i}. {Path(j['path']).name}  ({j.get('id_col','B')}→{j.get('out_col','F')}, {ny}){rng}")


def cmd_clear(queue_path=DEFAULT_QUEUE):
    save_queue([], queue_path)
    print("ล้างคิวเรียบร้อย")


def cmd_remove(idx_list, queue_path=DEFAULT_QUEUE):
    jobs = load_queue(queue_path)
    n = len(jobs)
    keep = [j for i, j in enumerate(jobs, 1) if i not in idx_list]
    save_queue(keep, queue_path)
    print(f"ลบ {n - len(keep)} ไฟล์ — เหลือ {len(keep)} ไฟล์")


def prompt_add_files(queue_path=DEFAULT_QUEUE):
    """เมนูเพิ่มไฟล์แบบโต้ตอบ — ใช้ตอนคิวว่าง"""
    print("\nคิวว่างเปล่า — เพิ่มไฟล์ก่อน")
    paths = []
    while True:
        s = input("ลากไฟล์ .xlsx มาวางที่นี่ (หรือพิมพ์พาธ) — Enter ว่างเพื่อจบ: ").strip()
        if not s:
            break
        # ลาก-วาง บน Windows ใส่ "" ครอบ
        s = s.strip('"').strip("'")
        paths.append(s)
    if paths:
        cmd_add(paths, queue_path, interactive=True)


def parse_selection(text, n):
    """แปลงข้อความเลือก เช่น '1,3' '2-3' 'all' -> list ของ index (1-based) ที่ถูกต้อง"""
    text = (text or "").strip().lower()
    if text in ("", "all", "a", "*"):
        return list(range(1, n + 1))
    picked = []
    for part in text.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            try:
                lo, hi = part.split("-", 1)
                lo, hi = int(lo), int(hi)
                picked.extend(range(min(lo, hi), max(lo, hi) + 1))
            except ValueError:
                continue
        else:
            try:
                picked.append(int(part))
            except ValueError:
                continue
    # เก็บเฉพาะที่อยู่ในช่วง และไม่ซ้ำ เรียงลำดับ
    seen = []
    for i in picked:
        if 1 <= i <= n and i not in seen:
            seen.append(i)
    return seen


def select_jobs(jobs, select_arg):
    """แสดงเมนูเลือกไฟล์ในคิว แล้วคืน jobs เฉพาะที่เลือก"""
    n = len(jobs)
    if n <= 1:
        return jobs

    print("\n" + "=" * 60)
    print("ไฟล์ในคิว:")
    for i, j in enumerate(jobs, 1):
        rng = ""
        if j.get("start_row") or j.get("end_row"):
            rng = f"  [แถว {j.get('start_row', 2)}-{j.get('end_row', 'สุดไฟล์')}]"
        print(f"  {i}. {Path(j['path']).name}{rng}")
    print("=" * 60)

    if select_arg is not None:
        chosen = parse_selection(select_arg, n)
    else:
        print("เลือกไฟล์ที่จะรัน:  เช่น  1  |  1,3  |  2-3  |  all")
        raw = input("พิมพ์ตัวเลือก (Enter = ทั้งหมด): ").strip()
        chosen = parse_selection(raw, n)

    if not chosen:
        print("[!] ไม่ได้เลือกไฟล์ที่ถูกต้อง — ใช้ทั้งหมด")
        chosen = list(range(1, n + 1))

    print("จะรันไฟล์: " + ", ".join(str(c) for c in chosen))
    return [jobs[i - 1] for i in chosen]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("excel_path", nargs="?", default=None)
    parser.add_argument("--queue", default=None, help="path ของ queue.json")
    parser.add_argument("--start-row", type=int, default=2)
    parser.add_argument("--end-row", type=int, default=None, help="แถวสุดท้ายที่ทำ (รวม)")
    parser.add_argument("--sheet", default=None)
    parser.add_argument("--id-col", default="B")
    parser.add_argument("--out-col", default="F")
    parser.add_argument("--no-year", action="store_true")
    parser.add_argument("--retry-errors", action="store_true", help="ทำเฉพาะแถวที่ F ขึ้นต้น ERROR")
    parser.add_argument("--select", default=None,
                        help="เลือกไฟล์ในคิว เช่น 1 / 1,3 / 2-3 / all (ไม่ใส่=ถามตอนรัน)")
    parser.add_argument("--add", nargs="*", metavar="FILE", default=None,
                        help="เพิ่มไฟล์เข้าคิว (ไม่ใส่ไฟล์ = ถามทีละไฟล์)")
    parser.add_argument("--list", action="store_true", help="แสดงรายการในคิวแล้วจบ")
    parser.add_argument("--clear-queue", action="store_true", help="ล้างคิวแล้วจบ")
    parser.add_argument("--remove", default=None,
                        help="ลบไฟล์ในคิวตาม index เช่น 2 หรือ 1,3 หรือ 2-3")
    args = parser.parse_args()

    # คำสั่งจัดการคิว — ทำแล้วจบ ไม่เปิด browser
    if args.list:
        cmd_list(args.queue or DEFAULT_QUEUE)
        return
    if args.clear_queue:
        cmd_clear(args.queue or DEFAULT_QUEUE)
        return
    if args.remove:
        n = len(load_queue(args.queue or DEFAULT_QUEUE))
        idx = parse_selection(args.remove, n)
        cmd_remove(idx, args.queue or DEFAULT_QUEUE)
        return
    if args.add is not None:
        if args.add:
            cmd_add(args.add, args.queue or DEFAULT_QUEUE, interactive=True)
        else:
            prompt_add_files(args.queue or DEFAULT_QUEUE)
        return

    if args.queue:
        jobs = load_queue(args.queue)
        if not jobs:
            prompt_add_files(args.queue)
            jobs = load_queue(args.queue)
            if not jobs:
                sys.exit("คิวยังว่าง — เลิก")
        if args.retry_errors:
            for j in jobs:
                j["retry_only"] = True
        jobs = select_jobs(jobs, args.select)
    elif args.excel_path:
        jobs = [{
            "path": args.excel_path,
            "id_col": args.id_col,
            "out_col": args.out_col,
            "no_year": args.no_year,
            "start_row": args.start_row,
            "end_row": args.end_row,
            "sheet": args.sheet,
            "retry_only": args.retry_errors,
        }]
    else:
        sys.exit("ต้องระบุไฟล์ Excel หรือ --queue queue.json")

    with sync_playwright() as p:
        ctx = launch_browser(p)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(SEARCH_URL)

        print("\n" + "=" * 60)
        print("รอให้คุณ login ในเบราว์เซอร์ที่เพิ่งเปิด")
        print(f"จะประมวลผล {len(jobs)} ไฟล์:")
        for i, j in enumerate(jobs, 1):
            print(f"  {i}. {Path(j['path']).name}")
        input("เมื่อพร้อมแล้ว กด Enter เพื่อเริ่ม...")

        for i, job in enumerate(jobs, 1):
            print(f"\n>>> ไฟล์ {i}/{len(jobs)}")
            try:
                process_file(page, job)
            except KeyboardInterrupt:
                print("\n[Ctrl+C] หยุดการทำงาน")
                break
            except Exception as e:
                print(f"[!] ไฟล์นี้เกิดข้อผิดพลาด: {e}")

        print("\nเสร็จทั้งคิว")
        ctx.close()


if __name__ == "__main__":
    main()
