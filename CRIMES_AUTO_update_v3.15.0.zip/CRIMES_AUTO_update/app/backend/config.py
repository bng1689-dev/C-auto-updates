"""ศูนย์รวมการตั้งค่า path ของ backend — ผูกกับฐานข้อมูล SQLite ที่จัดเก็บเอง

ทุกโมดูลฝั่ง backend (server, db, auth, engine, worker) อ้างอิง path จากที่นี่ที่เดียว
ทำให้ backend เป็นเจ้าของชั้นข้อมูล (data/) อย่างชัดเจน และย้าย/ตั้งค่าตำแหน่งเก็บข้อมูลได้จากจุดเดียว
"""
import os
from pathlib import Path

# โครงสร้างโฟลเดอร์
BASE_DIR = Path(__file__).resolve().parent          # .../backend
PROJECT_DIR = BASE_DIR.parent                        # .../app
FRONTEND_DIR = PROJECT_DIR / "frontend"
TEMPLATE_DIR = FRONTEND_DIR / "templates"
STATIC_DIR = FRONTEND_DIR / "static"

# เบราว์เซอร์ Chromium ที่แถมมาในแพ็กเกจ (ทำงานออฟไลน์ 100% — ไม่ต้องดาวน์โหลด)
# วางไว้ที่ <รากติดตั้ง>/browsers  (ระดับเดียวกับ app/ และ runtime/)
# ตั้ง PLAYWRIGHT_BROWSERS_PATH ให้ Playwright ใช้เบราว์เซอร์ในแพ็กเกจก่อนถูกเรียกใช้จริง
BUNDLED_BROWSERS_DIR = PROJECT_DIR.parent / "browsers"
if BUNDLED_BROWSERS_DIR.exists() and not os.environ.get("PLAYWRIGHT_BROWSERS_PATH"):
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(BUNDLED_BROWSERS_DIR)

# เวอร์ชันโปรแกรม (อ่านจากไฟล์ app/VERSION) — ใช้แสดงผลและตรวจสอบอัปเดต
try:
    APP_VERSION = (PROJECT_DIR / "VERSION").read_text(encoding="utf-8").strip() or "0.0.0"
except Exception:
    APP_VERSION = "0.0.0"

# ชั้นเก็บข้อมูลที่ backend จัดเก็บเอง (override ได้ด้วย env CRIMES_DATA_DIR)
DATA_DIR = Path(os.environ.get("CRIMES_DATA_DIR", BASE_DIR / "data")).resolve()
UPLOAD_DIR = Path(os.environ.get("CRIMES_UPLOAD_DIR", BASE_DIR / "uploads")).resolve()

# v3.10.0: URL ศูนย์กลางขององค์กร ฝังไว้ในโปรแกรม (เจ้าของโปรเจกต์กำหนด) — ทุกเครื่องที่ติดตั้งชี้ไปที่นี่โดยไม่ต้องกรอก
# ศูนย์กลางตรวจลายเซ็น HMAC ด้วย HUB_TOKEN (ด้านล่าง — เจ้าของสั่งฝังเช่นกัน) · เปลี่ยนได้ที่ Setting → ศูนย์กลาง
DEFAULT_HUB_URL = "https://script.google.com/macros/s/AKfycbxvnf0_5X2ZVMMN-L-AklreK1Q-pkzS8_QXhGWjk-g_is34RVbwOAeGodLonNDcmqayJg/exec"
# v3.10.1: ย้ายศูนย์กลางไป Deployment ใหม่ (สคริปต์ 3.10.0 ของจริง) — ตัวเก่าค้างโค้ดรุ่นเก่าและอัปเดตทับไม่สำเร็จ
# เครื่องที่ config ยังชี้ URL เก่าเหล่านี้ถูกย้ายไป DEFAULT_HUB_URL ให้อัตโนมัติตอนเปิดโปรแกรม (รหัสลับเดิม ใช้ต่อได้ทันที)
OLD_HUB_URLS = (
    "https://script.google.com/macros/s/AKfycbxlp7jEOTZbZB6JdvRALAwY9vKJGRyusqWfkW3srR1VPtcFIhr4H0nlwagigRCme9lnww/exec",
    "https://script.google.com/macros/s/AKfycbxxAV0J1caSJXP4GpNlZiqHrNunTeZfYmWRrEaCrUoaVUZKMRCfQ8xq0L--IMvmK9IDow/exec",
)
# v3.10.0: รหัสลับศูนย์กลาง (HUB_TOKEN) ฝังในโปรแกรมตามคำสั่งเจ้าของโปรเจกต์ ("ฝัง HUB_TOKEN") — ทุกเครื่องที่ติดตั้ง
# เชื่อมศูนย์กลางเองทันที ไม่ต้องกรอกรหัสเชื่อมต่อ · ⚠ รีโปนี้เป็นสาธารณะ: ต้องถือว่ารหัสนี้เป็นสาธารณะด้วย —
# คนที่รู้รหัสดึงไดเรกทอรีสมาชิก (รวมแฮชรหัสผ่าน) และสมุดกองกลางจากศูนย์กลางได้ · รหัสผู้ดูแล (ADMIN_TOKEN) ไม่ได้ฝังและยังลับอยู่
# เปลี่ยนรหัสเมื่อไร: แก้ HUB_TOKEN ใน Apps Script + ค่านี้ แล้วปล่อยรุ่นใหม่ · ชุดทดสอบตั้ง env CRIMES_NO_DEFAULT_HUB=1
# เพื่อปิดค่าฝังนี้ (ห้ามชุดทดสอบยิงศูนย์กลางจริง)
DEFAULT_HUB_TOKEN = "" if os.environ.get("CRIMES_NO_DEFAULT_HUB") else "=-8a1h_5R1-xb&{Z_1I6II5.W$QM9KOU"
# v3.10.0: ไฟล์ seed รหัสลับศูนย์กลางจากชุดติดตั้ง (hub_seed.json — {"token": ...}) โปรแกรมใช้ตอนเปิดครั้งแรกแล้วลบทันที
# (ยังรองรับไว้สำหรับองค์กรที่ใช้ศูนย์กลาง/รหัสของตัวเอง — ค่าจากไฟล์ทับค่าฝัง)
HUB_SEED_FILE_NAME = "hub_seed.json"

# ฐานข้อมูล SQLite + ไฟล์ตั้งค่า/คิว (override path ฐานข้อมูลได้ด้วย env CRIMES_DB_PATH)
DB_PATH = Path(os.environ.get("CRIMES_DB_PATH", DATA_DIR / "data.db")).resolve()
CONFIG_PATH = DATA_DIR / "config.json"
QUEUE_PATH = DATA_DIR / "queue.json"

# สร้างโฟลเดอร์ข้อมูลให้พร้อมใช้เสมอ
DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
