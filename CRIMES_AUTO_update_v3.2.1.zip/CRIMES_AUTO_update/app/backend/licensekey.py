"""ตรวจ KEY อนุญาตอัปเดต — ตรวจลายเซ็นด้วยกุญแจสาธารณะ (RSA, stdlib ล้วน)

ทำไมใช้ลายเซ็นแทนรหัสลับร่วม (HMAC):
    โปรแกรมนี้ส่งเป็นไฟล์ .py ข้อความล้วนในไฟล์ zip ใครแตกไฟล์ก็อ่านโค้ดได้ทั้งหมด
    ถ้าใช้ HMAC ความลับที่ใช้ "ตรวจ" กับที่ใช้ "สร้าง" เป็นตัวเดียวกัน — อ่านโค้ดเจอ
    ก็ปลอม KEY ได้ทันที ระบบจึงกันได้แค่ความเข้าใจผิด ไม่ใช่คนที่ตั้งใจ
    ลายเซ็นแยกกุญแจเป็นสองส่วน: เครื่องผู้ใช้ถือแค่ "กุญแจสาธารณะ" ไว้ตรวจ
    ส่วน "กุญแจลับ" ที่ออก KEY ได้อยู่กับ Admin เท่านั้น อ่านโค้ดทั้งไฟล์ก็ปลอมไม่ได้

ตัวโปรแกรมมีแต่ฝั่งตรวจ ฝั่งออก KEY อยู่ในเครื่องมือแยก (tools/keygen.py)
ซึ่งไม่ถูกรวมไปกับชุดอัปเดตที่แจกจ่าย

รูปแบบ KEY (บรรทัดเดียว คัดลอกวางได้):  v1.<payload base64url>.<signature base64url>
payload เป็น JSON: {"u": ชื่อผู้ใช้, "m": รหัสติดตั้ง (ไม่บังคับ), "exp": วันหมดอายุ (ไม่บังคับ)}
"""
import base64
import binascii
import hashlib
import hmac
import json
from datetime import datetime

KEY_PREFIX = "v1."
# DER prefix ของ SHA-256 ตามมาตรฐาน PKCS#1 v1.5 (RFC 8017 ภาคผนวก A.2.4)
_SHA256_DER = binascii.unhexlify("3031300d060960864801650304020105000420")


def _b64url_decode(s):
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def b64url_encode(b):
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")


def emsa_pkcs1_v15(msg, emlen):
    """ประกอบข้อความที่ถูกเซ็นตามมาตรฐาน PKCS#1 v1.5 — ใช้ร่วมกันทั้งฝั่งเซ็นและฝั่งตรวจ"""
    t = _SHA256_DER + hashlib.sha256(msg).digest()
    if emlen < len(t) + 11:
        raise ValueError("กุญแจสั้นเกินไป")
    return b"\x00\x01" + b"\xff" * (emlen - len(t) - 3) + b"\x00" + t


def rsa_verify(n, e, msg, sig):
    """ตรวจลายเซ็น: ยกกำลังสาธารณะแล้วเทียบกับรูปแบบที่ควรจะเป็น (เทียบแบบคงเวลา)"""
    k = (n.bit_length() + 7) // 8
    if len(sig) != k:
        return False
    try:
        m = pow(int.from_bytes(sig, "big"), e, n)
        em = m.to_bytes(k, "big")
        return hmac.compare_digest(em, emsa_pkcs1_v15(msg, k))
    except (ValueError, OverflowError):
        return False


def signing_message(payload_b64):
    """ข้อความที่ถูกเซ็นคือส่วน payload ที่เข้ารหัสแล้วตรง ๆ — ฝั่งเซ็นต้องใช้สูตรเดียวกัน"""
    return payload_b64.encode("ascii")


def parse_key(key_str):
    """แยกส่วนของ KEY — คืน (payload dict, payload_b64, signature bytes) หรือ None ถ้ารูปแบบผิด"""
    s = "".join(str(key_str or "").split())      # ตัดช่องว่าง/ขึ้นบรรทัดที่ติดมาจากการคัดลอก
    if not s.startswith(KEY_PREFIX):
        return None
    parts = s[len(KEY_PREFIX):].split(".")
    if len(parts) != 2 or not all(parts):
        return None
    try:
        payload = json.loads(_b64url_decode(parts[0]).decode("utf-8"))
        sig = _b64url_decode(parts[1])
    except (ValueError, binascii.Error, UnicodeDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    return payload, parts[0], sig


def verify_key(key_str, username, install_id, pubkey):
    """ตรวจว่า KEY นี้ใช้ได้กับผู้ใช้คนนี้บนเครื่องนี้ไหม

    คืน dict: {"ok": bool, "reason": ข้อความอธิบาย, "payload": ...}
    เหตุผลที่แยกละเอียดเพื่อให้หน้าจอบอกได้ว่าติดตรงไหน — KEY ของคนอื่น หมดอายุ
    หรือคนละเครื่อง เป็นคนละปัญหาที่ผู้ใช้ต้องทำคนละอย่าง
    """
    if not pubkey or not pubkey.get("n"):
        return {"ok": False, "reason": "ยังไม่ได้ตั้งกุญแจสาธารณะสำหรับตรวจ KEY"}
    parsed = parse_key(key_str)
    if not parsed:
        return {"ok": False, "reason": "รูปแบบ KEY ไม่ถูกต้อง"}
    payload, payload_b64, sig = parsed
    try:
        n = int(pubkey["n"])
        e = int(pubkey.get("e", 65537))
    except (ValueError, TypeError):
        return {"ok": False, "reason": "กุญแจสาธารณะไม่ถูกต้อง"}
    if not rsa_verify(n, e, signing_message(payload_b64), sig):
        return {"ok": False, "reason": "ลายเซ็นไม่ถูกต้อง — KEY นี้ไม่ได้ออกโดยผู้ดูแลระบบ"}
    # ---- ลายเซ็นผ่านแล้วค่อยดูเนื้อใน ----
    want_user = str(payload.get("u") or "")
    if want_user != str(username or ""):
        return {"ok": False, "reason": f"KEY นี้ออกให้ผู้ใช้ '{want_user}' ไม่ใช่บัญชีนี้",
                "payload": payload}
    want_machine = str(payload.get("m") or "")
    if want_machine and want_machine != str(install_id or ""):
        return {"ok": False, "reason": "KEY นี้ผูกกับเครื่องอื่น", "payload": payload}
    exp = str(payload.get("exp") or "")
    if exp:
        try:
            if datetime.now() > datetime.fromisoformat(exp):
                return {"ok": False, "reason": f"KEY หมดอายุแล้ว ({exp[:10]})", "payload": payload}
        except (ValueError, TypeError):
            return {"ok": False, "reason": "วันหมดอายุใน KEY ไม่ถูกต้อง", "payload": payload}
    return {"ok": True, "reason": "ใช้งานได้", "payload": payload}
