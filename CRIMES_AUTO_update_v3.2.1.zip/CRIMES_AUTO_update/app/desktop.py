"""CRIMES AUTO — Desktop launcher (pywebview)

เปิดแอปในหน้าต่างเดสก์ท็อปของตัวเอง (ไม่ต้องเปิดเบราว์เซอร์)
รัน Flask/Waitress ในเธรดเบื้องหลัง แล้วเปิดหน้าต่าง WebView ชี้มาที่เซิร์ฟเวอร์ในเครื่อง
"""
import os
import socket
import subprocess
import sys
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent

# บันทึกเหตุขัดข้องตอนเปิดโปรแกรม — อยู่ที่โฟลเดอร์ติดตั้ง (แม่ของ app/) หาเจอง่าย
CRASH_LOG = HERE.parent / "crash.log"


def _fatal(stage, exc):
    """โปรแกรมรันด้วย pythonw ซึ่งไม่มีคอนโซล — ถ้าพังตอนเปิด ผู้ใช้จะเห็นแค่
    'ดับเบิลคลิกแล้วไม่มีอะไรขึ้นเลย' และไม่มีใครรู้สาเหตุ จึงต้อง (1) เขียนลงไฟล์
    crash.log เสมอ และ (2) เด้งกล่องข้อความบอกทันที แล้วค่อยจบโปรเซส"""
    detail = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    stamp = datetime.now().isoformat(timespec="seconds")
    try:
        with open(CRASH_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n===== {stamp} · เปิดโปรแกรมไม่สำเร็จ (ขั้นตอน: {stage}) =====\n{detail}")
    except OSError:
        pass
    msg = (f"เปิด CRIMES AUTO ไม่สำเร็จ (ขั้นตอน: {stage})\n\n"
           f"{type(exc).__name__}: {exc}\n\n"
           f"รายละเอียดถูกบันทึกไว้ที่:\n{CRASH_LOG}\n\n"
           "ส่งไฟล์นี้ให้ผู้ดูแลระบบเพื่อแก้ไข")
    try:
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, msg, "CRIMES AUTO", 0x00000010)
        else:
            print(msg, file=sys.stderr)
    except Exception:
        pass
    sys.exit(1)


sys.path.insert(0, str(HERE / "backend"))

# import คือจุดที่พังบ่อยสุดหลังอัปเดต (ไฟล์ขาด/ไม่ครบ/ฐานข้อมูล migrate ไม่ผ่าน)
# ต้องห่อไว้ ไม่งั้น pythonw ตายเงียบโดยไม่ทิ้งร่องรอยอะไรเลย
try:
    import config  # noqa: E402  (ตั้งค่า path ของ backend)
    import server  # noqa: E402  (Flask app — import จะ init_db ให้อัตโนมัติ)
except Exception as _e:  # noqa: BLE001
    _fatal("โหลดโปรแกรม (import backend)", _e)

try:
    import webview  # noqa: E402
except Exception as _e:  # noqa: BLE001
    _fatal("โหลดตัวแสดงหน้าต่าง (pywebview)", _e)

HOST = "127.0.0.1"
PORT = 8770


def _relaunch_after_exit():
    """สั่งให้เปิดโปรแกรมใหม่หลังโปรเซสนี้จบ (ใช้ตอนอัปเดตเสร็จ) — ผ่านตัวช่วย PowerShell แบบแยกอิสระ"""
    pid = os.getpid()
    exe = sys.executable                      # pythonw.exe ของ runtime
    script = str(HERE / "desktop.py")         # ตัวแอป (เวอร์ชันใหม่หลังอัปเดต)
    ps = (
        f"try{{ Wait-Process -Id {pid} -Timeout 30 -ErrorAction SilentlyContinue }}catch{{}}; "
        f"Start-Sleep -Milliseconds 600; "
        f"Start-Process -FilePath '{exe}' -ArgumentList '\"{script}\"' -WorkingDirectory '{HERE}'"
    )
    # DETACHED_PROCESS | CREATE_NO_WINDOW = แยกอิสระ ไม่มีหน้าต่าง
    flags = 0x00000008 | 0x08000000
    subprocess.Popen(
        ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
        creationflags=flags, close_fds=True,
    )


def _do_restart():
    """รีสตาร์ทแอปอัตโนมัติ: เตรียมตัวเปิดใหม่ → ปิดหน้าต่าง/จบโปรเซส → ตัวช่วยเปิดแอปใหม่"""
    try:
        _relaunch_after_exit()
    except Exception as e:  # pragma: no cover
        print("relaunch error:", e)
    try:
        for w in list(webview.windows):
            w.destroy()
    except Exception:
        pass
    # เผื่อหน้าต่างปิดแล้วโปรเซสยังไม่จบ (เช่นโหมด fallback เบราว์เซอร์) → บังคับออกหลังหน่วงสั้นๆ
    threading.Timer(2.0, lambda: os._exit(0)).start()


def _find_icon():
    """หาไฟล์ icon.ico: โฟลเดอร์ติดตั้ง (แม่ของ app/) ก่อน แล้วค่อยข้างๆ desktop.py"""
    for p in (HERE.parent / "icon.ico", HERE / "icon.ico"):
        if p.exists():
            return str(p)
    return None


def _apply_window_icon(window):
    """ตั้งไอคอนหน้าต่าง/taskbar (WinForms บน Windows) — พลาดก็ข้าม ไม่กระทบการทำงาน"""
    try:
        icon_path = _find_icon()
        if not icon_path:
            return
        import clr  # pythonnet มากับ pywebview[winforms]
        clr.AddReference("System.Drawing")
        from System.Drawing import Icon
        window.native.Icon = Icon(icon_path)
    except Exception:
        pass


_serve_error = [None]     # เก็บเหตุที่เซิร์ฟเวอร์ล้ม เพื่อรายงานให้ผู้ใช้เห็น (pythonw ไม่มีคอนโซล)


def _serve():
    try:
        from waitress import serve
        # v3.2.0: งานเบื้องหลังสองอย่างนี้เดิมถูกเรียกจาก server.run_server() เท่านั้น
        # แต่แอปเดสก์ท็อปเปิด waitress เอง ไม่ได้ผ่าน run_server() — ทั้งการเก็บกวาดหลัง
        # อัปเดตและตัวส่งข้อมูลขึ้นศูนย์กลางตามรอบเวลาจึงไม่เคยทำงานบนเครื่องผู้ใช้จริงเลย
        # เก็บกวาดทำในเธรดแยก เพื่อไม่ให้หน่วงการเปิดเซิร์ฟเวอร์ (มีเพดานรอ 25 วิที่ _wait_ready)
        threading.Thread(target=server._post_update_maintenance,
                         daemon=True, name="post-update-maint").start()
        server.start_hub_worker()
        serve(server.app, host=HOST, port=PORT, threads=8)
    except Exception as e:  # pragma: no cover
        _serve_error[0] = e
        try:
            with open(CRASH_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n===== {datetime.now().isoformat(timespec='seconds')}"
                        f" · เซิร์ฟเวอร์ภายในล้ม =====\n")
                traceback.print_exc(file=f)
        except OSError:
            pass


def _port_open(timeout=0.5):
    try:
        with socket.create_connection((HOST, PORT), timeout=timeout):
            return True
    except OSError:
        return False


def _http_ready(timeout=2):
    """เซิร์ฟเวอร์ 'ตอบจริง' ไหม — ไม่ใช่แค่พอร์ตเปิด

    waitress รับการเชื่อมต่อ TCP ทันทีที่ผูกพอร์ตสำเร็จ ต่อให้แอปข้างในค้างสนิท
    พอร์ตก็ยังเปิดอยู่ดี การเช็คแค่พอร์ตจึง 'ผ่าน' ทั้งที่เปิดหน้าเว็บไม่ได้ แล้วเราก็
    ไปเปิดหน้าต่างต่อ กลายเป็นจอขาวค้างโดยไม่มีคำอธิบายใด ๆ ให้ผู้ใช้
    """
    import urllib.error
    import urllib.request
    try:
        req = urllib.request.Request(f"http://{HOST}:{PORT}/api/auth/state",
                                     headers={"User-Agent": "CRIMES-AUTO-Boot"})
        with urllib.request.urlopen(req, timeout=timeout):
            return True
    except urllib.error.HTTPError:
        return True          # ตอบกลับมาแล้ว (แม้เป็น 4xx) = แอปข้างในยังทำงานอยู่
    except Exception:
        return False


def _wait_ready(timeout=25):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if _http_ready(2):
            return True
        time.sleep(0.3)
    return False


STUCK_HINT = ("วิธีแก้: กด Ctrl+Shift+Esc เปิด Task Manager → แท็บ Details →\n"
              "จบโปรเซส pythonw.exe และ msedgewebview2.exe ให้หมดทุกตัว\n"
              "แล้วเปิด CRIMES AUTO ใหม่อีกครั้ง")

WATCHDOG_SEC = 30


def _start_load_watchdog(win, url):
    """กันจอขาวค้างจากฝั่งหน้าต่าง

    เซิร์ฟเวอร์ตอบได้แล้ว (ผ่าน _wait_ready) แต่ WebView2 เองก็ค้างได้ — ที่พบบ่อยคือ
    โฟลเดอร์ข้อมูลของ WebView2 ยังถูกโปรเซสเก่าที่ตายไม่สนิทล็อกไว้ ผลคือหน้าต่างเปิดมา
    ขาวโพลนและ Windows ขึ้น (Not Responding) โดยไม่มีอะไรบอกผู้ใช้เลย
    ถ้าเกินเวลาแล้วหน้ายังไม่โหลด → บันทึกเหตุ แจ้งผู้ใช้ และเปิดด้วยเบราว์เซอร์แทนให้ทำงานต่อได้
    """
    loaded = [False]
    try:
        win.events.loaded += lambda: loaded.__setitem__(0, True)
    except Exception:
        return          # pywebview รุ่นที่ไม่มี event นี้ — ข้ามไป ไม่ให้กระทบการเปิดโปรแกรม

    def _watch():
        time.sleep(WATCHDOG_SEC)
        if loaded[0]:
            return
        try:
            with open(CRASH_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n===== {datetime.now().isoformat(timespec='seconds')}"
                        f" · หน้าต่างแอปไม่โหลดภายใน {WATCHDOG_SEC} วินาที"
                        f" (เซิร์ฟเวอร์ภายในตอบปกติ) → เปิดด้วยเบราว์เซอร์แทน =====\n")
        except OSError:
            pass
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:
            pass
        msg = ("หน้าต่างโปรแกรมเปิดไม่ขึ้น (ค้างเป็นจอขาว)\n\n"
               "ระบบเปิดให้ใช้งานผ่านเบราว์เซอร์แทนแล้วที่:\n" + url + "\n\n"
               "ใช้งานได้ครบทุกอย่างเหมือนกัน\n\n" + STUCK_HINT)
        try:
            if os.name == "nt":
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, msg, "CRIMES AUTO", 0x00000030)
            else:
                print(msg, file=sys.stderr)
        except Exception:
            pass

    threading.Thread(target=_watch, daemon=True, name="load-watchdog").start()


def main():
    # ถ้าพอร์ตยังว่าง = ยังไม่มีเซิร์ฟเวอร์ → สตาร์ทเอง; ถ้ามีอยู่แล้วก็เปิดหน้าต่างชี้ไปที่เดิม
    if _port_open():
        # มีอะไรถือพอร์ตอยู่ — ต้องเช็คว่ามัน "ตอบได้จริง" ก่อน ไม่งั้นเราจะไปเปิดหน้าต่าง
        # ชี้ไปที่โปรเซสเดิมที่ค้างอยู่ แล้วได้จอขาวค้างตามไปด้วยโดยไม่รู้สาเหตุ
        if not _wait_ready(8):
            _fatal("เชื่อมต่อโปรแกรมที่เปิดค้างอยู่", RuntimeError(
                f"พอร์ต {PORT} ถูกโปรแกรมที่ค้างอยู่ยึดไว้ และไม่ตอบสนอง\n\n"
                + STUCK_HINT))
    else:
        threading.Thread(target=_serve, daemon=True).start()
        if not _wait_ready():
            # เซิร์ฟเวอร์สตาร์ทไม่ขึ้น — เดิมจะเปิดหน้าต่างขาวค้างโดยไม่บอกอะไร
            err = _serve_error[0] or RuntimeError(
                f"เซิร์ฟเวอร์ภายในไม่ตอบที่พอร์ต {PORT} ภายในเวลาที่กำหนด — "
                "พอร์ตอาจถูกโปรแกรมอื่นใช้ หรือถูกไฟร์วอลล์บล็อก\n\n" + STUCK_HINT)
            _fatal("เปิดเซิร์ฟเวอร์ภายใน", err)
    # ให้เซิร์ฟเวอร์รีสตาร์ทแอปเองได้หลังอัปเดตออนไลน์
    server.RESTART_HOOK = _do_restart
    url = f"http://{HOST}:{PORT}"
    try:
        # เปิดให้ WebView2 ดาวน์โหลดไฟล์ได้ (ค่าเริ่มต้นเป็น False = กดปุ่ม Download แล้วเงียบ)
        webview.settings["ALLOW_DOWNLOADS"] = True
        win = webview.create_window(
            "CRIMES AUTO", url,
            width=1280, height=820, min_size=(960, 640),
        )
        win.events.shown += lambda: _apply_window_icon(win)
        _start_load_watchdog(win, url)
        webview.start()
    except Exception as e:
        # เครื่องปลายทางอาจไม่มี WebView2 runtime → เปิดด้วยเบราว์เซอร์เริ่มต้นแทน (ใช้งานได้ครบเหมือนกัน)
        import webbrowser
        print(f"[!] เปิดหน้าต่างแอปไม่ได้ ({e}) — เปิดด้วยเบราว์เซอร์เริ่มต้นแทน: {url}")
        webbrowser.open(url)
        try:
            while _port_open(1):
                time.sleep(1)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as _e:  # noqa: BLE001
        _fatal("เปิดหน้าต่างโปรแกรม", _e)
