"""Background automation worker — drives Playwright, reports progress, logs to DB."""
import os
import re
import shutil
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import engine  # noqa: E402  (เครื่องมือค้นอัตโนมัติ — เดิมชื่อ crimes_auto)
import db  # noqa: E402

from playwright.sync_api import sync_playwright  # noqa: E402


def downloads_dir():
    """หาโฟลเดอร์ Downloads ของผู้ใช้ (รองรับกรณีถูก redirect เช่น OneDrive)"""
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders")
        val, _ = winreg.QueryValueEx(key, "{374DE290-123F-4565-9164-39C4925E467B}")
        winreg.CloseKey(key)
        p = Path(os.path.expandvars(val))
        if p.exists():
            return p
    except Exception:
        pass
    p = Path.home() / "Downloads"
    try:
        p.mkdir(parents=True, exist_ok=True)
    except OSError:
        p = Path.home()
    return p


def _is_profile_locked(err):
    """ข้อผิดพลาดที่บอกว่าโปรไฟล์ Chrome ถูกใช้อยู่โดยหน้าต่างอื่น"""
    s = str(err).lower()
    return ("existing browser session" in s
            or "already in use" in s
            or "singletonlock" in s)


def detect_account(page):
    """อ่านชื่อ/บัญชีผู้ใช้ CRIMES จากมุมขวาบนของหน้า"""
    try:
        txt = page.evaluate(
            r"""
            () => {
              const t = document.body.innerText;
              const m = t.match(/ชื่อ\s*:\s*([^\n]+)/);
              return m ? m[1].trim().slice(0, 80) : '';
            }
            """
        )
        return txt or ""
    except Exception:
        return ""


class RunManager:
    def __init__(self):
        self.lock = threading.Lock()
        self.thread = None
        self.current_user_id = 0
        self.reset()

    def reset(self):
        self.state = "idle"          # idle|launching|awaiting_login|running|paused|done|stopped|error
        self.message = "พร้อมใช้งาน"
        self.account = ""
        self.speed = engine.DEFAULT_SPEED
        self.jobs = []
        self.file_index = 0
        self.file_total = 0
        self.current_file = ""
        self.row = 0
        self.total_rows = 0
        self.processed = 0
        self.found = 0
        self.notfound = 0
        self.errors = 0
        self.log_lines = []
        self.save_warning = ""   # บันทึกไป backup แทน (ไฟล์ต้นฉบับถูกเปิดค้าง)
        self.save_error = ""     # บันทึกลงไฟล์ไม่ได้เลย — ผลที่ค้นได้เสี่ยงหาย
        self.step_mode = False       # โหมดทีละขั้น (หยุดรอผู้ใช้กดก่อนแต่ละสเต็ป)
        self.awaiting_step = False   # กำลังรอผู้ใช้กด 'ทำขั้นต่อไป'
        self.current_step = ""       # คำอธิบายขั้นที่กำลังจะทำ
        self.browser_open = False    # เบราว์เซอร์ยังเปิดค้างอยู่ (หลังเสร็จ ไม่ปิดจนกว่าจะสั่ง)
        self.record_steps = False    # บันทึกการทำงานแต่ละสเต็ป (เปิดอัตโนมัติในโหมดทีละขั้น)
        self.last_recording = ""     # ชื่อชุดบันทึกล่าสุดที่ปิดเซสชันแล้ว
        self._page = None            # หน้าเบราว์เซอร์ปัจจุบัน (ให้ตัวบันทึกเข้าถึงได้)
        self._recorder = None        # engine.ManualRecorder ของรอบนี้ (ถ้าเปิดบันทึก)
        # ---- พัก/ค้นต่อ + บันทึกระหว่างค้น (สำหรับเน็ตหลุด/แบตใกล้หมด — ไม่เสียโควตาค้นซ้ำ) ----
        self.pause_reason = ""       # เหตุที่พัก: network|manual|errors ("" = ไม่ได้พัก)
        self.paused_at = ""          # ตำแหน่งที่พักไว้ เช่น "ไฟล์.xlsx แถว 57"
        self.restored = 0            # จำนวนแถวที่กู้ผลจากประวัติ (ไม่ต้องค้นซ้ำ)
        self.save_seq = 0            # ตัวนับ 'บันทึกตามคำขอ' สำเร็จ (หน้าเว็บรอค่านี้ขยับก่อนดาวน์โหลด)
        self.current_path = ""       # path ไฟล์ที่กำลังค้น (ให้ปุ่มดาวน์โหลดระหว่างรันใช้)
        self._wb = None              # workbook ที่กำลังเขียนผล (ให้ _service_save เข้าถึงได้)
        self._xlsx = None            # path ของ workbook ข้างบน
        self._save_request = False   # ผู้ใช้ขอบันทึกไฟล์เดี๋ยวนี้ (บันทึกที่จุดปลอดภัยถัดไป)
        self._pause_request = False  # ผู้ใช้ขอพักชั่วคราว (พักเมื่อจบแถวปัจจุบัน)
        self._resume_event = threading.Event()
        self._login_event = threading.Event()
        self._step_event = threading.Event()
        self._close_event = threading.Event()
        self._stop = False
        self.run_id = None

    # ---------- public API ----------
    def status(self):
        with self.lock:
            pct = 0
            if self.total_rows:
                pct = round(100 * self.processed / self.total_rows)
            return {
                "state": self.state,
                "message": self.message,
                "account": self.account,
                "file_index": self.file_index,
                "file_total": self.file_total,
                "current_file": self.current_file,
                "row": self.row,
                "total_rows": self.total_rows,
                "processed": self.processed,
                "found": self.found,
                "notfound": self.notfound,
                "errors": self.errors,
                "percent": pct,
                "save_warning": self.save_warning,
                "save_error": self.save_error,
                "step_mode": self.step_mode,
                "awaiting_step": self.awaiting_step,
                "current_step": self.current_step,
                "browser_open": self.browser_open,
                "recording": bool(self._recorder),
                "recording_steps": (self._recorder.n if self._recorder else 0),
                "last_recording": self.last_recording,
                "pause_reason": self.pause_reason,
                "paused_at": self.paused_at,
                "restored": self.restored,
                "save_seq": self.save_seq,
                "current_path": self.current_path,
                "log": self.log_lines[-200:],
            }

    def is_busy(self):
        return self.state in ("launching", "awaiting_login", "running", "paused")

    def start(self, jobs, account="", speed=None, step_mode=False, record=None):
        if self.is_busy():
            return False, "มีงานกำลังทำงานอยู่"
        # ปิดเบราว์เซอร์ของรอบก่อน (ถ้าเปิดค้าง) แล้วรอให้ 'ปล่อยโปรไฟล์' ก่อนเปิดใหม่
        # กันปัญหา 'profile already in use' เพราะ Chrome เก่ายังจับโปรไฟล์อยู่
        self._close_event.set()
        old = self.thread
        if old and old.is_alive():
            old.join(timeout=12)
        self.reset()
        self.jobs = jobs
        self.account = account
        if speed is not None:
            self.speed = engine.clamp_speed(speed)
        self.step_mode = bool(step_mode)
        # บันทึกสเต็ป: ถ้าไม่ระบุ ให้เปิดอัตโนมัติเมื่ออยู่โหมดทีละขั้น (การทำงานแบบเมนนวล)
        self.record_steps = bool(record) if record is not None else bool(step_mode)
        self.file_total = len(jobs)
        self.state = "launching"
        self.message = "กำลังเปิดเบราว์เซอร์..."
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        return True, "เริ่มแล้ว"

    def confirm_login(self):
        self._login_event.set()

    def next_step(self):
        """โหมดทีละขั้น: สั่งให้ทำขั้นต่อไป"""
        self._step_event.set()

    def set_auto(self):
        """สลับจากโหมดทีละขั้นเป็นอัตโนมัติ (เดินต่อเองจนจบ)"""
        self.step_mode = False
        self._step_event.set()   # ปลดล็อกขั้นที่กำลังรออยู่
        self._log("สลับเป็นโหมดอัตโนมัติ — เดินต่อเองจนจบ")

    def close_browser(self):
        """สั่งปิดเบราว์เซอร์ที่เปิดค้างอยู่หลังทำงานเสร็จ"""
        self._close_event.set()

    def reset_round(self):
        """เริ่มรอบใหม่อย่างปลอดภัย — ปิดเบราว์เซอร์ที่เปิดค้าง + รอ thread เดิมจบ + รีเซ็ตสถานะ
        เรียกซ้ำหลายครั้งได้โดยไม่เกิดข้อผิดพลาด. คืน (ok: bool, message: str)"""
        if self.is_busy():
            return False, "มีงานกำลังทำงานอยู่ — โปรดหยุดก่อนเริ่มรอบใหม่"
        # ปิดเบราว์เซอร์ของรอบก่อน (ถ้ายังเปิดค้าง) แล้วรอเธรดเดิมปล่อยทรัพยากรก่อนรีเซ็ต
        self._close_event.set()
        t = self.thread
        if t and t.is_alive():
            t.join(timeout=10)
        self.reset()
        return True, "พร้อมรับไฟล์ใหม่"

    def stop(self):
        self._stop = True
        self._step_event.set()     # ปลดล็อกถ้ากำลังรอขั้นต่อไปอยู่
        self._resume_event.set()   # ปลดล็อกถ้ากำลังพักอยู่ (ให้เธรดออกจากลูปพักแล้วจบงาน)
        self.message = "กำลังหยุด..."

    def pause(self):
        """ขอพักชั่วคราว — มีผลเมื่อจบแถวที่กำลังค้นอยู่ (ระบบบันทึกไฟล์ให้ก่อนพัก)"""
        if self.state == "running" and not self._pause_request:
            self._pause_request = True
            self._log("⏸ ขอพักชั่วคราว — จะพักเมื่อจบแถวปัจจุบัน (บันทึกไฟล์ให้อัตโนมัติ)")

    def resume(self):
        """สั่งค้นต่อจากจุดที่พักไว้ (หลังพักด้วยมือ/เน็ตหลุด/ผิดพลาดติดกัน)"""
        self._resume_event.set()

    def request_save(self):
        """ขอบันทึกผลลงไฟล์เดี๋ยวนี้ (ดาวน์โหลดระหว่างที่ยังค้นไม่ครบ เช่นก่อนแบตหมด)
        คืน save_seq ปัจจุบัน — หน้าเว็บรอจนค่านี้ขยับจึงเริ่มดาวน์โหลด"""
        self._save_request = True
        return self.save_seq

    # ---------- internal ----------
    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)
            if len(self.log_lines) > 1000:
                self.log_lines = self.log_lines[-500:]

    def _service_save(self):
        """บันทึกไฟล์ตามคำขอของผู้ใช้ (เรียกจากเธรดงานที่จุดปลอดภัยเท่านั้น)
        เสร็จแล้วขยับ save_seq เพื่อบอกหน้าเว็บว่าเริ่มดาวน์โหลดได้"""
        if not self._save_request:
            return
        self._save_request = False
        if self._wb is not None and self._xlsx is not None:
            self._save_checked(self._wb, self._xlsx)
            self._log("💾 บันทึกผลลงไฟล์ตามคำขอแล้ว — ดาวน์โหลดได้เลย (ค้นต่อได้ตามปกติ)")
        self.save_seq += 1

    def _pause_wait(self, reason):
        """พักการทำงานโดยคงเบราว์เซอร์/ตำแหน่งงานไว้ รอผู้ใช้สั่ง 'ค้นต่อ ▶'
        คืน True = ค้นต่อจากแถวเดิม, False = ถูกสั่งหยุด
        ผู้เรียกต้องบันทึกไฟล์ให้เรียบร้อยก่อนเรียก (ผลที่ค้นแล้วไม่หาย)"""
        reasons = {
            "network": "📡 เน็ตหลุด/เข้าเว็บ CRIMES ไม่ได้ — พักอัตโนมัติเพื่อไม่ให้เสียโควตาค้นซ้ำ",
            "manual": "⏸ พักชั่วคราวตามคำขอ",
            "errors": "⚠ ผิดพลาดติดต่อกันหลายแถว — พักอัตโนมัติเพื่อไม่ให้เสียโควตา "
                      "(ตรวจหน้าเว็บในเบราว์เซอร์ หรือลองโหมดทีละขั้น)",
        }
        self.state = "paused"
        self.pause_reason = reason
        self.paused_at = f"{self.current_file} แถว {self.row}"
        self.message = (reasons.get(reason, "พักชั่วคราว")
                        + f" · ค้างที่ {self.paused_at} — ผลที่ค้นแล้วถูกบันทึกไว้ ดาวน์โหลดได้ "
                          "/ กด 'ค้นต่อ ▶' เมื่อพร้อม")
        self._log(self.message)
        self._resume_event.clear()
        while True:
            while not self._resume_event.is_set():
                if self._stop:
                    return False
                self._service_save()   # ไฟล์ถูกบันทึกก่อนพักแล้ว — ยืนยันให้ดาวน์โหลดได้ทันที
                time.sleep(0.3)
            self._resume_event.clear()
            if self._stop:
                return False
            # ก่อนกลับไปค้นต่อหลังเน็ตหลุด: เช็คให้แน่ว่าติดต่อเซิร์ฟเวอร์ได้แล้วจริง
            if reason == "network" and not engine.probe_online():
                self.message = ("ยังติดต่อเซิร์ฟเวอร์ CRIMES ไม่ได้ — "
                                "รอสัญญาณอินเทอร์เน็ตกลับมา แล้วกด 'ค้นต่อ ▶' อีกครั้ง")
                self._log("📡 " + self.message)
                continue
            break
        self.state = "running"
        self.pause_reason = ""
        self.paused_at = ""
        self.message = "ค้นต่อจากจุดที่พักไว้"
        self._log("▶ ค้นต่อจากจุดที่พักไว้ (" + f"{self.current_file} แถว {self.row})")
        return True

    def _pause_step(self, desc):
        """โหมดทีละขั้น: หยุดรอผู้ใช้กด 'ทำขั้นต่อไป' ก่อนทำ desc
        คืน True = ทำต่อได้, False = ถูกสั่งหยุด. โหมดอัตโนมัติจะคืน True ทันที"""
        self.current_step = desc
        # บันทึกสถานะหน้า (ภาพ+HTML) ของสเต็ปนี้ 'ก่อนลงมือทำ' — ข้อมูลไว้ปรับปรุงระบบ
        if self.record_steps and self._recorder is not None and self._page is not None:
            try:
                self._recorder.step(self._page, desc)
            except Exception:
                pass
        if not self.step_mode:
            return True
        self._log("⏸ ขั้นต่อไป: " + desc + "  — กด 'ทำขั้นต่อไป ▶'")
        self.awaiting_step = True
        self._step_event.clear()
        while not self._step_event.is_set():
            if self._stop:
                self.awaiting_step = False
                return False
            if not self.step_mode:      # ผู้ใช้สลับเป็นอัตโนมัติกลางคัน
                break
            self._service_save()        # ขอบันทึก·ดาวน์โหลดได้แม้กำลังรอขั้นต่อไป
            time.sleep(0.2)
        self.awaiting_step = False
        if self._stop:
            return False
        self._log("▶ กำลังทำ: " + desc)
        return True

    def _step_note(self, msg):
        """รายงานผลของแต่ละขั้น (แสดงเฉพาะในโหมดทีละขั้น เพื่อไม่รกในโหมดอัตโนมัติ)"""
        if self.step_mode:
            self._log("   → " + msg)
        # เก็บผลลงสเต็ปปัจจุบันของตัวบันทึก (ไว้ทบทวนว่าแต่ละขั้นได้ผลอะไร)
        if self.record_steps and self._recorder is not None:
            try:
                self._recorder.note(msg)
            except Exception:
                pass

    def _launch_with_retry(self, p, attempts=3):
        """เปิดเบราว์เซอร์ พร้อมลองใหม่ถ้าโปรไฟล์ยังถูกจับอยู่ (Chrome เก่าเพิ่งปิด)"""
        last = None
        for i in range(attempts):
            try:
                return engine.launch_browser(p)
            except Exception as e:
                last = e
                if _is_profile_locked(e) and i < attempts - 1:
                    killed = engine.kill_profile_browsers()
                    self._log(f"โปรไฟล์ Chrome ถูกใช้อยู่ — ปิดหน้าต่างเดิมของระบบ {killed} รายการ "
                              f"แล้วลองเปิดใหม่ (ครั้งที่ {i + 2})")
                    time.sleep(2.5)
                    continue
                raise
        raise last

    def _run(self):
        close_event = self._close_event   # จับ event ของรอบนี้ไว้ (กันถูก reset ทับ)
        close_event.clear()
        try:
            with sync_playwright() as p:
                try:
                    ctx = self._launch_with_retry(p)
                except Exception as e:
                    self.state = "error"
                    self.browser_open = False
                    if _is_profile_locked(e):
                        self.message = ("เปิดเบราว์เซอร์ไม่ได้ — มีหน้าต่าง Chrome ของระบบเปิดค้างอยู่ "
                                        "(โปรไฟล์กำลังถูกใช้งาน) โปรดปิดหน้าต่าง Chrome เดิมของระบบให้หมด "
                                        "แล้วกด 'เริ่มค้นหา' ใหม่")
                    else:
                        self.message = f"เปิดเบราว์เซอร์ไม่ได้: {str(e)[:200]}"
                    self._log(self.message)
                    return
                # เตือนผู้ใช้ให้เห็นชัดถ้าตกไปใช้ Chromium สำรอง (เนียนน้อยกว่า Chrome จริง)
                if getattr(engine, "LAST_LAUNCH_USED_FALLBACK", False):
                    self._log("⚠ ใช้ Chromium สำรอง (ไม่พบ/เปิด Chrome ของเครื่องไม่ได้) — "
                              "โหมดนี้ถูกตรวจจับว่าเป็นบอทง่ายกว่า Chrome จริง · "
                              "แนะนำติดตั้ง/เปิด Google Chrome เพื่อความปลอดภัยสูงสุด")

                page = ctx.pages[0] if ctx.pages else ctx.new_page()
                page.goto(engine.SEARCH_URL)

                self.state = "awaiting_login"
                self.message = "ตรวจสอบ login ในหน้าต่าง Chrome แล้วกด 'เริ่มค้นหา'"
                self._log("เปิดเบราว์เซอร์แล้ว — รอยืนยัน login")
                # รอผู้ใช้กดยืนยัน (หรือสั่งหยุด)
                while not self._login_event.is_set():
                    if self._stop:
                        self.state = "stopped"
                        self.message = "ยกเลิกก่อนเริ่ม"
                        ctx.close()
                        return
                    time.sleep(0.3)

                # auto-detect account ถ้าไม่ได้ระบุ
                detected = detect_account(page)
                if detected and not self.account:
                    self.account = detected
                self._log(f"บัญชีผู้ค้น: {self.account or '(ไม่ทราบ)'}")

                self.run_id = db.start_run(self.account, "; ".join(
                    Path(j["path"]).name for j in self.jobs),
                    user_id=self.current_user_id)

                applied = engine.set_speed(self.speed)
                self._log(f"ความเร็วการค้น: {engine.SPEED_LABELS.get(self.speed, '?')} "
                          f"(หน่วงเวลา ×{applied:g})")
                if self.step_mode:
                    self._log("🔎 โหมดทีละขั้น (Step-by-step) — ระบบจะหยุดรอให้กด 'ทำขั้นต่อไป ▶' "
                              "ในแต่ละสเต็ป เพื่อดูจุดที่ผิดพลาด")

                self.state = "running"
                for fi, job in enumerate(self.jobs, 1):
                    if self._stop:
                        break
                    self.file_index = fi
                    self._process_file(page, job)

                db.finish_run(self.run_id, self.processed, self.found,
                              self.notfound, self.errors,
                              "stopped" if self._stop else "done")

                # ปิดเซสชันบันทึกโหมดทีละขั้น (ถ้ามี) — ได้ชุดข้อมูลไว้ปรับปรุงระบบ
                if self._recorder is not None:
                    try:
                        summ = self._recorder.finish(page)
                        self.last_recording = self._recorder.name
                        self._log(f"📄 บันทึกโหมดทีละขั้นเสร็จ: {summ['steps']} สเต็ป "
                                  f"(ชุด {self._recorder.name}) — ดาวน์โหลดได้ในหน้าตั้งค่า")
                    except Exception:
                        pass
                    self._recorder = None

                self.state = "stopped" if self._stop else "done"
                self.pause_reason = ""
                self.message = ("หยุดแล้ว" if self._stop else "เสร็จสมบูรณ์") + \
                    f" — ค้น {self.processed}, พบ {self.found}, ไม่พบ {self.notfound}, ผิดพลาด {self.errors}"
                if self.restored:
                    self.message += f" (กู้จากประวัติ {self.restored} — ไม่เสียโควตา)"
                if self.save_error:
                    self.message += " · ⚠ บันทึกไฟล์ไม่สำเร็จ (ดูคำเตือนด้านบน)"
                elif self.save_warning:
                    self.message += " · ⚠ บันทึกไว้ที่ไฟล์สำรอง (ดูคำเตือนด้านบน)"
                self._log(self.message)

                # ไม่ปิดเบราว์เซอร์ทันที — เปิดค้างไว้ให้ผู้ใช้ตรวจสอบ
                # จนกว่าจะกด 'ปิดเบราว์เซอร์' หรือเริ่มงานใหม่
                self.browser_open = True
                self.current_step = ""
                self.awaiting_step = False
                self._log("เบราว์เซอร์ยังเปิดค้างไว้ — กด 'ปิดเบราว์เซอร์' เมื่อต้องการปิด")
                while not close_event.is_set():
                    time.sleep(0.3)
                self.browser_open = False
                self._log("ปิดเบราว์เซอร์แล้ว")
                try:
                    ctx.close()
                except Exception:
                    pass
        except Exception as e:
            self.state = "error"
            self.message = f"ผิดพลาด: {e}"
            self.browser_open = False
            self._log(self.message)

    def _save_checked(self, wb, xlsx, found_pending=0):
        """บันทึกไฟล์ พร้อมตรวจว่าบันทึกสำเร็จจริงหรือไม่ แล้วแจ้งเตือนถ้ามีปัญหา

        found_pending = จำนวน 'พบคดี' ที่กำลังจะถูกเขียนลงไฟล์รอบนี้ (ใช้ในข้อความเตือน)
        คืน True ถ้าเขียนทับไฟล์ต้นฉบับสำเร็จ, False ถ้าไป backup หรือบันทึกไม่ได้
        """
        path, status, message = engine.save_workbook_report(wb, xlsx)
        if status == "ok":
            # บันทึกทับต้นฉบับได้ — เคลียร์คำเตือนเดิม (ผู้ใช้อาจปิดไฟล์แล้ว)
            if self.save_warning or self.save_error:
                self._log("บันทึกไฟล์ต้นฉบับได้ตามปกติแล้ว")
            self.save_warning = ""
            self.save_error = ""
            return True
        if status == "backup":
            # ข้อมูลถูกเขียนลงไฟล์สำรองแล้ว (ถือว่าบันทึกสำเร็จ แต่เตือนให้ปิดไฟล์ต้นฉบับ)
            self.save_warning = message
            self.save_error = ""
            self._log(f"[!] {message}")
            return True
        # failed — ข้อมูลที่ค้นได้ยังไม่ถูกเขียนลงไฟล์
        extra = f" (มีผล 'พบคดี' {found_pending} รายการที่ยังไม่ถูกบันทึก)" if found_pending else ""
        self.save_error = message + extra
        self._log(f"[!!] {message}{extra}")
        return False

    def _save_to_downloads(self, xlsx):
        """ก๊อปไฟล์ผลลัพธ์ไปที่โฟลเดอร์ Downloads อัตโนมัติเมื่อค้นครบทุกแถว
        ตั้งชื่อไฟล์ตามจำนวนรายชื่อที่ค้น เช่น  ชื่อไฟล์(120ชื่อ).xlsx"""
        try:
            xlsx = Path(xlsx)
            # เลือกไฟล์ที่มีข้อมูลล่าสุด (เผื่อกรณีบันทึกไปไฟล์สำรอง _backup เพราะไฟล์ต้นฉบับถูกล็อก)
            backup = xlsx.with_name(xlsx.stem + "_backup.xlsx")
            src = xlsx
            if backup.exists() and (not xlsx.exists()
                                    or backup.stat().st_mtime > xlsx.stat().st_mtime):
                src = backup
            if not src.exists():
                return None
            count = db.count_searched_ids(xlsx.name)
            name = f"{xlsx.stem}({count}ชื่อ){xlsx.suffix}" if count > 0 else xlsx.name
            dest = downloads_dir() / name
            shutil.copy2(src, dest)
            self._log(f"💾 บันทึกผลอัตโนมัติไปที่ Downloads: {dest.name}")
            return dest
        except Exception as e:
            self._log(f"[!] บันทึกไป Downloads ไม่ได้: {e}")
            return None

    def _count_rows(self, ws, id_col, start_row, end_row):
        n = 0
        r = start_row
        while True:
            if end_row is not None and r > end_row:
                break
            v = ws.cell(row=r, column=id_col).value
            if v is None or str(v).strip() == "":
                break
            n += 1
            r += 1
        return n

    def _process_file(self, page, job):
        import openpyxl
        self._page = page
        # เปิดตัวบันทึกโหมดทีละขั้นครั้งแรกที่เริ่มประมวลผล (1 ตัวต่อ 1 รอบการทำงาน)
        if self.record_steps and self._recorder is None:
            try:
                self._recorder = engine.ManualRecorder(account=self.account)
                self._log("🔴 เริ่มบันทึกการทำงานโหมดทีละขั้น (เก็บภาพ/HTML แต่ละสเต็ป "
                          "ไว้เป็นข้อมูลปรับปรุงระบบเมื่อเว็บเปลี่ยน)")
            except Exception:
                self._recorder = None
        xlsx = Path(job["path"]).resolve()
        if not xlsx.exists():
            self._log(f"[!] ไม่พบไฟล์ {xlsx.name}")
            return
        id_col = engine.col_letter_to_num(job.get("id_col", "B"))
        out_col = engine.col_letter_to_num(job.get("out_col", "F"))
        no_year = bool(job.get("no_year", False))
        start_row = int(job.get("start_row", 2))
        end_row = job.get("end_row")
        end_row = int(end_row) if end_row else None
        sheet = job.get("sheet")

        wb = openpyxl.load_workbook(xlsx)
        ws = wb[sheet] if sheet else wb.active

        self.current_file = xlsx.name
        self.current_path = str(xlsx)
        # ให้ปุ่ม 'บันทึก·ดาวน์โหลด' ระหว่างค้นเข้าถึง workbook ได้ (บันทึกจากเธรดงานเท่านั้น)
        self._wb, self._xlsx = wb, xlsx
        self.total_rows = self._count_rows(ws, id_col, start_row, end_row)
        self.row = start_row
        self._log(f"=== {xlsx.name} ({self.total_rows} แถว) ===")

        row = start_row
        since_save = 0
        found_since_save = 0
        consec_err = 0      # นับ error ติดกัน — เกินเกณฑ์ = พักอัตโนมัติกันเสียโควตา
        while True:
            if self._stop:
                break
            # จุดปลอดภัยระหว่างแถว: บริการคำขอ 'บันทึกเดี๋ยวนี้' และ 'พักชั่วคราว'
            self._service_save()
            if self._pause_request:
                self._pause_request = False
                if self._save_checked(wb, xlsx, found_since_save):
                    found_since_save = 0
                since_save = 0
                if not self._pause_wait("manual"):
                    break
            if end_row is not None and row > end_row:
                break
            cell_b = ws.cell(row=row, column=id_col)
            raw = cell_b.value
            if raw is None or str(raw).strip() == "":
                break
            self.row = row

            cell_f = ws.cell(row=row, column=out_col)
            f_val = str(cell_f.value).strip() if cell_f.value else ""
            if f_val and not f_val.startswith("ERROR"):
                row += 1
                continue
            if f_val.startswith("ERROR"):
                cell_f.value = None

            normalized, padded, invalid = engine.normalize_id(raw)
            if invalid:
                self._log(f"[{row}] ข้าม (เลขไม่ถูกต้อง: {raw!r})")
                row += 1
                continue
            if padded:
                cell_b.fill = engine.YELLOW
                cell_b.value = normalized

            # ♻ เคยค้นเลขนี้ในไฟล์นี้สำเร็จแล้ว (เช่นเครื่องดับ/แบตหมดก่อนไฟล์ถูกบันทึก)
            #   → กู้ผลจากประวัติในฐานข้อมูลลงช่องผลได้เลย ไม่ต้องค้นซ้ำ = ไม่เสียโควตา
            #   (ยกเว้นผล 'พบคดี' ที่ยาวจนใกล้เพดานที่เก็บไว้ — อาจถูกตัด ให้ค้นใหม่เพื่อความครบถ้วน)
            prev = db.find_prev_result(xlsx.name, normalized, row=row)
            if prev and not (prev["outcome"] == "found"
                             and len(prev.get("detail") or "") >= 490):
                if prev["outcome"] == "found":
                    cell_f.value = prev["detail"]
                    self.found += 1
                    found_since_save += 1
                    what = f"พบ {prev['case_count']} คดี"
                else:
                    cell_f.value = " - "
                    self.notfound += 1
                    what = "ไม่พบคดี"
                self.processed += 1
                self.restored += 1
                self._log(f"[{row}] {db.mask_id(normalized)} → ♻ กู้ผลจากประวัติ ({what}) "
                          "— ไม่เสียโควตาค้นซ้ำ")
                since_save += 1
                if since_save >= 3:
                    if self._save_checked(wb, xlsx, found_since_save):
                        found_since_save = 0
                    since_save = 0
                row += 1
                continue

            if self._recorder is not None:
                self._recorder.set_context(f"แถว {row} · เลขบัตร {db.mask_id(normalized)}")

            try:
                cases = engine.search_one_id(page, normalized,
                                             pause=self._pause_step, note=self._step_note)
                if cases is None:
                    # ถูกสั่งหยุดกลางขั้น (โหมดทีละขั้น)
                    break
                kept = [c for c in cases if not c.get("skip")]
                any_diff = any(
                    c.get("table_id") and re.sub(r"\D", "", c["table_id"]) not in ("", normalized)
                    for c in cases
                )
                if any_diff:
                    cell_b.fill = engine.RED

                if kept:
                    def fmt(i, c):
                        charge = c.get("charge", "").strip() or "(ไม่ระบุข้อหา)"
                        if no_year:
                            return f"คดีที่{i+1} {charge}"
                        return f"คดีที่{i+1} {charge} ปี{c.get('year','').strip()}"
                    text = "/ ".join(fmt(i, c) for i, c in enumerate(kept))
                    cell_f.value = text
                    self.found += 1
                    found_since_save += 1
                    db.log_search(self.account, xlsx.name, row, normalized,
                                  "found", len(kept), text, user_id=self.current_user_id)
                    self._log(f"[{row}] {db.mask_id(normalized)} → พบ {len(kept)} คดี")
                else:
                    cell_f.value = " - "
                    self.notfound += 1
                    db.log_search(self.account, xlsx.name, row, normalized,
                                  "notfound", 0, "-", user_id=self.current_user_id)
                    self._log(f"[{row}] {db.mask_id(normalized)} → ไม่พบคดี")
                self.processed += 1
                consec_err = 0
            except Exception as e:
                err_text = str(e)
                # 📡 เน็ตหลุด/เข้าเว็บไม่ถึง → 'ไม่' เขียน ERROR ลงช่องผล (เว้นไว้ค้นใหม่ตอนกลับมา)
                # บันทึกไฟล์แล้วพักอัตโนมัติทันที — กันการไล่ค้นทุกแถวที่เหลือทั้งที่ไม่มีเน็ต
                # ซึ่งทำให้เสียเวลาและเสี่ยงเสียโควตาการค้นโดยเปล่าประโยชน์
                if engine.is_network_error(err_text) or not engine.probe_online():
                    self._log(f"[{row}] 📡 เชื่อมต่อไม่ได้: {err_text[:80]}")
                    if self._save_checked(wb, xlsx, found_since_save):
                        found_since_save = 0
                    since_save = 0
                    if not self._pause_wait("network"):
                        break
                    continue     # กลับมาค้นแถวเดิมซ้ำ (row ยังไม่ขยับ)
                msg = f"ERROR: {err_text[:100]}"
                cell_f.value = msg
                self.errors += 1
                consec_err += 1
                db.log_search(self.account, xlsx.name, row, normalized, "error", 0, msg, user_id=self.current_user_id)
                self._log(f"[{row}] {db.mask_id(normalized)} → {msg[:60]}")
                # เก็บหลักฐาน (ภาพ+HTML) ไว้ตรวจว่าเว็บ CRIMES เปลี่ยน DOM หรือไม่
                shot = engine.capture_diagnostics(page, f"row{row}")
                if shot:
                    self._log(f"    (บันทึกหน้าจอ/HTML ไว้ที่ {shot})")
                # ⚠ ผิดพลาดติดกันหลายแถว = น่าจะมีปัญหาที่เว็บ/ระบบ ไม่ใช่ข้อมูลแถวเดียว
                #   → พักอัตโนมัติกันเสียโควตา (ค้นต่อจะลองแถวเดิมใหม่ เพราะ ERROR ถูกล้างก่อนค้น)
                if consec_err >= 3:
                    if self._save_checked(wb, xlsx, found_since_save):
                        found_since_save = 0
                    since_save = 0
                    if not self._pause_wait("errors"):
                        break
                    consec_err = 0
                    continue     # ลองแถวเดิมอีกครั้งหลังกลับมา

            since_save += 1
            if since_save >= 3:
                if self._save_checked(wb, xlsx, found_since_save):
                    found_since_save = 0
                since_save = 0
            engine.sleep_range(1.0, 2.5)
            row += 1

        if self._save_checked(wb, xlsx, found_since_save):
            found_since_save = 0
            self._log(f"บันทึก {xlsx.name} แล้ว")

        # จบไฟล์นี้แล้ว — ตัดช่องทาง 'บันทึกตามคำขอ' ไม่ให้ชี้ workbook เก่า
        self._wb = None
        self._xlsx = None

        # ค้นครบทุกแถวแล้ว (ไม่ได้ถูกสั่งหยุดกลางคัน) → เซฟผลอัตโนมัติไปที่ Downloads
        if not self._stop:
            self._save_to_downloads(xlsx)


# singleton
manager = RunManager()
