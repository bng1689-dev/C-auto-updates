"""CRIMES Search — เว็บแอปควบคุมการค้นอัตโนมัติ (รันบนเครื่องผู้ใช้)
ระบบสมาชิก Super Admin + Member พร้อมระบบคิดค่าใช้จ่าย
"""
import hashlib
import json
import re
import shutil
import sys
import tempfile
import threading
import urllib.request
import uuid
import zipfile
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path

from flask import Flask, g, jsonify, redirect, request, send_file, session
from werkzeug.utils import secure_filename

# ให้ backend/ อยู่บน import path เสมอ (รองรับทั้ง `python backend/server.py` และ `python -m backend.server`)
sys.path.insert(0, str(Path(__file__).resolve().parent))

import config  # noqa: E402
import auth  # noqa: E402
import db  # noqa: E402
import engine  # noqa: E402  (เครื่องมือค้นอัตโนมัติ — เดิมชื่อ crimes_auto)
from worker import manager  # noqa: E402

UPLOAD_DIR = config.UPLOAD_DIR

# ล็อกกันการ "เริ่มรอบใหม่" ทำงานซ้อนกัน (กดปุ่มซ้ำเร็ว ๆ)
_reset_lock = threading.Lock()
# ล็อกกันการอัปเดตออนไลน์ทำงานซ้อนกัน (กันไฟล์เสียหายจากการก๊อปทับพร้อมกัน)
_update_lock = threading.Lock()

# ตัวเรียกรีสตาร์ทแอป — desktop.py จะตั้งค่าให้เมื่อรันเป็นโปรแกรมเดสก์ท็อป
# (รันแบบเซิร์ฟเวอร์เปล่าจะเป็น None → ไม่รีสตาร์ทอัตโนมัติ ให้ผู้ใช้เปิดใหม่เอง)
RESTART_HOOK = None


def _trigger_restart():
    try:
        if callable(RESTART_HOOK):
            RESTART_HOOK()
    except Exception as e:
        print("restart hook error:", e)

# frontend แยกโฟลเดอร์ — ชี้ Flask ไปที่ ../frontend
app = Flask(
    __name__,
    template_folder=str(config.TEMPLATE_DIR),
    static_folder=str(config.STATIC_DIR),
)
app.secret_key = auth.get_secret_key()
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024  # 64MB
# อายุของ session แบบ "จดจำการเข้าใช้งาน" (เมื่อผู้ใช้เลือกจดจำรหัส CRIMES AUTO)
app.permanent_session_lifetime = timedelta(days=30)

db.init_db()

# ตั้งความเร็วเริ่มต้นจากค่าที่ผู้ใช้บันทึกไว้ ตั้งแต่ตอนเปิดโปรแกรม
# (ไม่งั้นหน้าเว็บจะโชว์ระดับของเอนจินซึ่งยังไม่ได้อ่านค่าจาก config)
_cfg_init = auth.load_config()
engine.set_speed(_cfg_init.get("search_speed", engine.DEFAULT_SPEED))
engine.set_search_reasons(_cfg_init.get("search_reasons"))


# ---------------- auth helpers ----------------
# อายุ session ที่เข้ามาด้วย PASSCODE — สั้นกว่าการล็อกอินด้วยรหัสผ่านโดยตั้งใจ
# เพราะเป็นแค่ทางลัดปลดล็อกเครื่อง ไม่ใช่การพิสูจน์ตัวตนเต็มรูปแบบ
PASSCODE_SESSION_HOURS = 12


def _session_expired():
    exp = session.get("auth_exp")
    if not exp:
        return False
    try:
        return datetime.now() > datetime.fromisoformat(exp)
    except (ValueError, TypeError):
        return False


def _live_user():
    """แถวผู้ใช้ปัจจุบัน อ่านสดจากฐานข้อมูล แคชไว้ 1 คำขอ (flask.g)
    ค่าที่อยู่ใน session เป็นภาพ ณ ตอนล็อกอิน — ถ้าเชื่อค่านั้น การลบบัญชี ปิดใช้งาน
    หรือลดบทบาทจะไม่มีผลจนกว่าเจ้าตัวจะล็อกอินใหม่ ซึ่งเท่ากับเพิกถอนสิทธิ์ไม่ได้จริง"""
    if not hasattr(g, "_live_user"):
        uid = session.get("user_id")
        g._live_user = db.get_user(uid) if uid else None
    return g._live_user


def login_required(f):
    """จุดเดียวที่ตัดสินว่า session ยังใช้ได้ — ทุก decorator อื่นห่อทับตัวนี้เสมอ
    ตรวจ 3 อย่าง: หมดอายุ · บัญชียังอยู่ไหม · ยังเปิดใช้งานอยู่ไหม
    แล้วรีเฟรช role ใน session ให้ตรงกับฐานข้อมูล เพื่อไม่ให้บทบาทเก่าค้าง"""
    @wraps(f)
    def wrap(*a, **k):
        def _deny():
            session.clear()
            if request.path.startswith("/api/"):
                return jsonify({"error": "unauthorized"}), 401
            return redirect("/")

        if not session.get("user_id"):
            return _deny()
        if _session_expired():
            return _deny()
        user = _live_user()
        if not user or not user.get("active"):
            return _deny()
        # บทบาทอาจถูกเปลี่ยนหลังล็อกอิน — ให้ session ตามฐานข้อมูลเสมอ
        session["role"] = user["role"]
        return f(*a, **k)
    return wrap


def _is_loopback():
    """คำขอมาจากเครื่องนี้เองหรือไม่ — ไม่เชื่อ X-Forwarded-For (แอปรันเองในเครื่อง ไม่มี proxy)"""
    return (request.remote_addr or "") in ("127.0.0.1", "::1", "::ffff:127.0.0.1")


def _host_is_local():
    """ชื่อโฮสต์ที่เบราว์เซอร์ใช้เรียกเป็นชื่อของเครื่องนี้เองหรือไม่

    กัน DNS rebinding: เว็บภายนอกตั้งโดเมนให้ชี้กลับมาที่ 127.0.0.1 ได้ ทำให้ remote_addr
    เป็น loopback ทั้งที่คำขอถูกสั่งจากหน้าเว็บของคนอื่น — ตรวจ Host เพิ่มอีกชั้น
    ใช้ได้เฉพาะกับ endpoint ปลดล็อกเร็ว ซึ่งตามการใช้งานจริงเรียกผ่าน localhost เสมอ
    """
    host = (request.host or "").split(":")[0].strip("[]").lower()
    return host in ("127.0.0.1", "localhost", "::1")


def loopback_only(f):
    """ทางลัดปลดล็อกต้องมาจากเครื่องนี้เท่านั้น — โปรแกรมตั้งให้เปิดวง LAN ได้ (bind 0.0.0.0)
    ถ้าไม่กั้น PASSCODE จะกลายเป็นช่องล็อกอินจากเครื่องอื่นที่ไม่ต้องรู้ชื่อผู้ใช้ด้วยซ้ำ"""
    @wraps(f)
    def wrap(*a, **k):
        if not _is_loopback() or not _host_is_local():
            return jsonify({"error": "ใช้ได้เฉพาะจากเครื่องที่ติดตั้งโปรแกรมเท่านั้น"}), 403
        return f(*a, **k)
    return wrap


def _fresh_auth_ok():
    """เข้ามาด้วยรหัสผ่านจริงไหม — session ที่ปลดล็อกด้วย PASSCODE ยังไม่นับ
    จนกว่าจะยืนยันรหัสผ่านซ้ำ (แล้วจะอัปเกรดเป็น password ตลอด session นั้น)"""
    return session.get("auth_method", "password") == "password"


def fresh_auth_required(f):
    """งานอ่อนไหว: ต้องพิสูจน์ว่ารู้รหัสผ่านจริง ไม่ใช่แค่ถือเครื่องที่ปลดล็อกไว้"""
    @wraps(f)
    def wrap(*a, **k):
        if not _fresh_auth_ok():
            return jsonify({"error": "ต้องยืนยันรหัสผ่านก่อนทำรายการนี้",
                            "need_password": True}), 403
        return f(*a, **k)
    return login_required(wrap)


def admin_required(f):
    """ต้องเป็น Super Admin — ห่อ login_required เสมอ (ไม่เช็ค session ซ้ำเอง)
    เพื่อให้กติกาใดก็ตามที่เพิ่มเข้า login_required ในอนาคต (อายุ session,
    การตรวจว่า user ยัง active) มีผลกับ endpoint ระดับแอดมินโดยอัตโนมัติ"""
    @wraps(f)
    def _role_check(*a, **k):
        if session.get("role") != "super_admin":
            return jsonify({"error": "ไม่มีสิทธิ์ (ต้องเป็น Super Admin)"}), 403
        return f(*a, **k)
    return login_required(_role_check)


def _perms():
    """สิทธิ์ที่ใช้จริงของผู้ที่ล็อกอินอยู่ — อ่านสดจากฐานข้อมูลทุกครั้ง เพื่อให้การถอนสิทธิ์
    มีผลทันที ไม่ต้องรอให้ผู้ใช้ล็อกอินใหม่ (ค่าใน session อาจเก่าไปแล้ว)"""
    return db.get_permissions(session.get("user_id"))


def _can(key):
    return bool(_perms().get(key))


def perm_required(key):
    """ต้องมีสิทธิ์ข้อนี้ (Super Admin ผ่านเสมอ) — ห่อ login_required เหมือน admin_required
    ใช้กับงานที่มอบหมายให้สมาชิกได้ ส่วนงานที่อันตราย/กระทบทั้งระบบยังคงใช้ admin_required"""
    def deco(f):
        @wraps(f)
        def _check(*a, **k):
            if not _can(key):
                return jsonify({"error": f"ไม่มีสิทธิ์ ({db.PERMISSION_KEYS.get(key, key)})"}), 403
            return f(*a, **k)
        return login_required(_check)
    return deco


# ---------------- helpers: ขอบเขตการมองเห็น/เจ้าของงาน ----------------
def _is_admin():
    return session.get("role") == "super_admin"


def _scope_uid():
    """user_id สำหรับกรองข้อมูล — แอดมินเห็นทั้งระบบ (None), สมาชิกที่มีสิทธิ์
    'ดูข้อมูลทีม' เห็นทั้งทีมของตัวเอง (ลิสต์ user_id), ที่เหลือเห็นเฉพาะของตัวเอง"""
    if _is_admin():
        return None
    uid = session.get("user_id")
    if uid and _can("view_team"):
        return db.team_member_ids(uid)
    return uid


def _owns_job(j):
    """งานในคิวเป็นของผู้เรียกไหม — งานเก่าที่ยังไม่มีเจ้าของ (ก่อน v2.2.2)
    ถือเป็นงานกลาง มองเห็น/จัดการได้ทุกคน เพื่อไม่ทำงานที่ค้างอยู่ระหว่างอัปเดตพัง"""
    if _is_admin():
        return True
    owner = j.get("user_id")
    return owner is None or owner == session.get("user_id")


def _visible_jobs(jobs):
    return [j for j in jobs if _owns_job(j)]


def _run_owner_guard():
    """กันผู้ใช้อื่นสั่งควบคุมรอบทำงานที่ตัวเองไม่ได้เริ่ม (แอดมินสั่งได้เสมอ)
    คืน None ถ้าผ่าน หรือ (response, status) ถ้าไม่ใช่เจ้าของรอบ"""
    if _is_admin():
        return None
    owner = getattr(manager, "current_user_id", 0) or 0
    if manager.is_busy() and owner not in (0, session.get("user_id")):
        return jsonify({"error": "รอบทำงานนี้เริ่มโดยผู้ใช้อื่น — ให้เจ้าของรอบหรือ Super Admin เป็นผู้สั่ง"}), 403
    return None


def current_user():
    uid = session.get("user_id")
    if uid:
        return db.get_user(uid)
    return None


def _client_ip():
    """IP ที่บันทึกลง audit — ใช้ remote_addr เท่านั้น
    เดิมเชื่อ X-Forwarded-For ซึ่งผู้เรียกปลอมได้เอง (ไม่มี proxy หน้าแอปนี้)
    ทำให้ปลอมที่มาของเหตุการณ์ในบันทึกตรวจสอบได้"""
    return request.remote_addr or ""


def _audit(action, detail="", username=None):
    """บันทึก audit — ใช้ผู้ใช้ปัจจุบันใน session เว้นแต่ส่ง username มาเอง (เช่น login ล้มเหลว)"""
    db.log_audit(
        action, detail,
        user_id=session.get("user_id") or 0,
        username=username if username is not None else (session.get("username") or ""),
        ip=_client_ip(),
    )


@app.after_request
def no_cache(resp):
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    return resp


# ---------------- pages ----------------
@app.route("/")
def index():
    # เสิร์ฟ Single-Page HTML ไฟล์เดียว — การ login/setup จัดการฝั่ง client ผ่าน JSON API
    return send_file(config.FRONTEND_DIR / "index.html")


# ---------------- API: auth (สำหรับ Single-Page HTML) ----------------
# หมายเหตุ: การ setup/login/logout ทำผ่าน JSON API ด้านล่างทั้งหมด
# (SPA เรียก /api/setup, /api/login, /api/logout) — ไม่มีหน้า HTML ฝั่งเซิร์ฟเวอร์แล้ว
@app.route("/api/auth/state")
def api_auth_state():
    return jsonify({
        "configured": auth.is_configured(),
        "authed": bool(session.get("user_id")),
    })


@app.route("/api/login", methods=["POST"])
def api_login():
    if not auth.is_configured():
        return jsonify({"error": "ยังไม่ได้ตั้งค่าระบบ"}), 400
    data = request.json or {}
    username = (data.get("username") or "").strip()
    pw = data.get("password", "")
    # ล็อกอินด้วยรหัสผ่านเข้าถึงได้จากวง LAN ด้วย (เมื่อตั้ง bind 0.0.0.0) จึงต้องหน่วง
    # การเดารหัสเหมือนกัน — แยก scope รายชื่อผู้ใช้ เพื่อไม่ให้คนเดียวล็อกทั้งระบบ
    scope = f"login:{username.lower()}"
    wait = db.auth_lock_remaining(scope)
    if wait:
        _audit("login_locked", f"username={username}", username=username)
        return jsonify({"error": f"กรอกผิดหลายครั้ง — รออีก {wait} วินาที",
                        "locked_seconds": wait}), 429
    user = db.verify_user(username, pw)
    if not user:
        wait = db.record_auth_fail(scope)
        _audit("login_failed", f"username={username}", username=username)
        return jsonify({"error": "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง",
                        "locked_seconds": wait}), 401
    db.reset_auth_fails(scope)
    session["user_id"] = user["id"]
    session["username"] = user["username"]
    session["role"] = user["role"]
    session["display_name"] = user["display_name"]
    session["auth_method"] = "password"
    session.pop("auth_exp", None)
    # จดจำการเข้าใช้งาน CRIMES AUTO ถ้าผู้ใช้เลือก (คงล็อกอินได้นานตาม permanent_session_lifetime)
    session.permanent = bool(data.get("remember"))
    # จำว่าใครใช้เครื่องนี้ล่าสุด เพื่อให้หน้าล็อกอินเสนอปลดล็อกเร็วได้ "คนเดียว"
    # (ไม่แสดงรายชื่อผู้ใช้ทั้งหมด — กันการสำรวจว่ามีบัญชีอะไรบ้าง)
    db.set_meta("quick_user_id", user["id"])
    _audit("login", f"role={user['role']} method=password")
    return jsonify({"ok": True})


# ---------------- API: ปลดล็อกเร็วด้วย PASSCODE ----------------
def _quick_user():
    """ผู้ใช้ที่เสนอให้ปลดล็อกเร็วบนเครื่องนี้ — คนที่ล็อกอินล่าสุดเท่านั้น"""
    raw = db.get_meta("quick_user_id")
    if not raw:
        return None
    try:
        user = db.get_user(int(raw))
    except (ValueError, TypeError):
        return None
    if not user or not user.get("active") or not user.get("passcode_hash"):
        return None
    return user


@app.route("/api/auth/quick")
@loopback_only
def api_auth_quick():
    """หน้าล็อกอินถามว่ามีทางลัดปลดล็อกไหม — ไม่บอกชื่อผู้ใช้ถ้ายังไม่ได้ตั้ง PASSCODE"""
    user = _quick_user()
    wait = db.auth_lock_remaining("passcode")
    if not user:
        return jsonify({"available": False, "locked_seconds": wait})
    return jsonify({
        "available": True,
        "display_name": user["display_name"] or user["username"],
        "digits": db.PASSCODE_LEN,
        "locked_seconds": wait,
    })


@app.route("/api/auth/passcode", methods=["POST"])
@loopback_only
def api_auth_passcode():
    user = _quick_user()
    if not user:
        return jsonify({"error": "เครื่องนี้ยังไม่ได้ตั้ง PASSCODE — เข้าด้วยรหัสผ่าน"}), 400
    wait = db.auth_lock_remaining("passcode")
    if wait:
        return jsonify({"error": f"กรอกผิดหลายครั้ง — รออีก {wait} วินาที",
                        "locked_seconds": wait}), 429
    code = (request.json or {}).get("passcode", "")
    ok = db.verify_passcode(user["id"], code)
    if not ok:
        wait = db.record_auth_fail("passcode")
        _audit("login_failed", "method=passcode", username=user["username"])
        msg = (f"PASSCODE ไม่ถูกต้อง — กรอกผิดหลายครั้ง ล็อก {wait} วินาที" if wait
               else "PASSCODE ไม่ถูกต้อง")
        return jsonify({"error": msg, "locked_seconds": wait}), 401
    db.reset_auth_fails("passcode")
    session["user_id"] = ok["id"]
    session["username"] = ok["username"]
    session["role"] = ok["role"]
    session["display_name"] = ok["display_name"]
    # ทำเครื่องหมายว่าเข้ามาด้วยทางลัด — งานอ่อนไหวจะขอรหัสผ่านซ้ำ
    session["auth_method"] = "passcode"
    session["auth_exp"] = (datetime.now()
                           + timedelta(hours=PASSCODE_SESSION_HOURS)).isoformat()
    session.permanent = True
    _audit("login", f"role={ok['role']} method=passcode")
    return jsonify({"ok": True})


@app.route("/api/auth/confirm-password", methods=["POST"])
@login_required
def api_auth_confirm_password():
    """ยืนยันรหัสผ่านเพื่อปลดงานอ่อนไหวใน session ที่เข้ามาด้วย PASSCODE"""
    scope = f"confirm_pw:{session.get('user_id')}"
    wait = db.auth_lock_remaining(scope)
    if wait:
        return jsonify({"error": f"กรอกผิดหลายครั้ง — รออีก {wait} วินาที",
                        "locked_seconds": wait}), 429
    pw = (request.json or {}).get("password", "")
    if not db.verify_user(session.get("username", ""), pw):
        wait = db.record_auth_fail(scope)
        _audit("confirm_password_failed")
        return jsonify({"error": "รหัสผ่านไม่ถูกต้อง", "locked_seconds": wait}), 401
    db.reset_auth_fails(scope)
    session["auth_method"] = "password"
    session.pop("auth_exp", None)
    _audit("confirm_password")
    return jsonify({"ok": True})


@app.route("/api/auth/passcode/state")
@login_required
def api_passcode_state():
    return jsonify({
        "has_passcode": db.has_passcode(session.get("user_id")),
        "digits": db.PASSCODE_LEN,
        "auth_method": session.get("auth_method", "password"),
        "session_hours": PASSCODE_SESSION_HOURS,
    })


@app.route("/api/auth/passcode/set", methods=["POST"])
@fresh_auth_required
def api_passcode_set():
    """ตั้ง/เปลี่ยน PASSCODE ของตัวเอง — ต้องยืนยันรหัสผ่านปัจจุบันเสมอ"""
    data = request.json or {}
    if not db.verify_user(session.get("username", ""), data.get("password", "")):
        return jsonify({"error": "รหัสผ่านไม่ถูกต้อง"}), 401
    code = db.normalize_passcode(data.get("passcode", ""))
    if not code:
        return jsonify({"error": f"PASSCODE ต้องเป็นตัวเลข {db.PASSCODE_LEN} หลัก"}), 400
    if code != db.normalize_passcode(data.get("passcode2", "")):
        return jsonify({"error": "PASSCODE ทั้งสองช่องไม่ตรงกัน"}), 400
    if len(set(code)) == 1 or code in ("12345678", "87654321"):
        return jsonify({"error": "PASSCODE นี้เดาง่ายเกินไป"}), 400
    db.set_passcode(session["user_id"], code)
    db.set_meta("quick_user_id", session["user_id"])
    db.reset_auth_fails("passcode")
    _audit("passcode_set")
    return jsonify({"ok": True})


@app.route("/api/auth/passcode", methods=["DELETE"])
@login_required
def api_passcode_clear():
    uid = session["user_id"]
    # ล้างตัวนับกันเดารหัสได้เฉพาะเมื่อผู้เรียก "มี PASSCODE อยู่จริง" และเป็นเจ้าของ
    # ช่องปลดล็อกของเครื่องนี้ — ไม่งั้นใครที่ล็อกอินอยู่ก็กดลบ PASSCODE ที่ตัวเองไม่มี
    # เพื่อปลดตัวนับที่กำลังกันคนเดารหัสของคนอื่นได้
    had = db.has_passcode(uid)
    owns_slot = str(db.get_meta("quick_user_id") or "") == str(uid)
    db.clear_passcode(uid)
    if had and owns_slot:
        db.reset_auth_fails("passcode")
        db.set_meta("quick_user_id", "")
    _audit("passcode_cleared", f"had={int(had)}")
    return jsonify({"ok": True})


@app.route("/api/setup", methods=["POST"])
def api_setup():
    if auth.is_configured():
        return jsonify({"error": "ระบบถูกตั้งค่าแล้ว"}), 400
    data = request.json or {}
    username = (data.get("username") or "").strip()
    pw = data.get("password", "")
    pw2 = data.get("password2", "")
    display = (data.get("display_name") or "").strip()
    if not username or len(username) < 3:
        return jsonify({"error": "ชื่อผู้ใช้อย่างน้อย 3 ตัวอักษร"}), 400
    if len(pw) < 6:
        return jsonify({"error": "รหัสผ่านอย่างน้อย 6 ตัว"}), 400
    if pw != pw2:
        return jsonify({"error": "รหัสผ่านไม่ตรงกัน"}), 400
    uid = db.create_user(username, pw, display_name=display, role="super_admin")
    session["user_id"] = uid
    session["username"] = username
    session["role"] = "super_admin"
    session["display_name"] = display
    session.permanent = False
    _audit("setup_superadmin", f"username={username}")
    return jsonify({"ok": True})


@app.route("/api/logout", methods=["POST"])
def api_logout():
    _audit("logout")
    session.clear()
    return jsonify({"ok": True})


# ---------------- helper: ตรวจรหัสยืนยัน ----------------
def _check_action_code(data):
    """คืน None ถ้าผ่าน, หรือ (response, status) ถ้าไม่ผ่าน"""
    if not db.has_action_code():
        return jsonify({"error": "Super Admin ยังไม่ได้ตั้งรหัสยืนยัน (ตั้งที่หน้าตั้งค่า)"}), 400
    if not db.verify_action_code((data or {}).get("code", "")):
        return jsonify({"error": "รหัสยืนยันไม่ถูกต้อง"}), 403
    return None


# ---------------- API: รหัสยืนยัน ----------------
@app.route("/api/action-code/state")
@login_required
def api_action_code_state():
    return jsonify({"has_code": db.has_action_code()})


@app.route("/api/admin/action-code", methods=["POST"])
@admin_required
@fresh_auth_required
def api_set_action_code():
    data = request.json or {}
    code = (data.get("code") or "").strip()
    if code and len(code) < 4:
        return jsonify({"error": "รหัสอย่างน้อย 4 ตัว"}), 400
    db.set_action_code(code)
    _audit("set_action_code", "cleared" if not code else "updated")
    return jsonify({"ok": True, "has_code": db.has_action_code()})


# ---------------- API: ล้างข้อมูล ----------------
@app.route("/api/clear/searches", methods=["POST"])
@login_required
def api_clear_searches():
    """ล้างประวัติการค้น — สมาชิก: ของตัวเอง / Super Admin: ทั้งระบบ (ต้องใส่รหัสยืนยัน)

    การล้างทั้งระบบลบฐานคิดเงิน+ประวัติของทุกคนและทำลายหน้าต่างกู้ผล 24 ชม.
    ของทุกคนพร้อมกัน — จึงต้องยืนยันด้วยรหัสเดียวกับ 'ล้างข้อมูลทั้งหมด'"""
    if _is_admin():
        err = _check_action_code(request.json or {})
        if err:
            return err
        db.clear_search_history(user_id=None)
        scope = "all"
    else:
        db.clear_search_history(user_id=session.get("user_id"))
        scope = "self"
    _audit("clear_searches", f"scope={scope}")
    return jsonify({"ok": True, "scope": scope})


@app.route("/api/clear/all", methods=["POST"])
@admin_required
@fresh_auth_required
def api_clear_all():
    """ล้างทุกอย่าง (ประวัติ+คิว+ไฟล์อัปโหลด) — เฉพาะ Super Admin + รหัสยืนยัน"""
    data = request.json or {}
    err = _check_action_code(data)
    if err:
        return err
    db.clear_all_data()
    engine.save_queue([])
    removed = 0
    # rglob: ไฟล์อัปโหลดอยู่ในโฟลเดอร์ย่อยรายผู้ใช้ (UPLOAD_DIR/<user_id>/) ตั้งแต่ v2.2.2
    for f in config.UPLOAD_DIR.rglob("*.xlsx"):
        try:
            f.unlink()
            removed += 1
        except OSError:
            pass
    _audit("clear_all", f"uploads_removed={removed}")
    return jsonify({"ok": True, "uploads_removed": removed})


# ---------------- API: queue & upload ----------------
@app.route("/api/queue")
@login_required
def api_queue():
    # สมาชิกเห็นเฉพาะงานของตัวเอง (+งานเก่าที่ยังไม่มีเจ้าของ) — แอดมินเห็นทั้งหมด
    jobs = _visible_jobs(engine.load_queue())
    for j in jobs:
        p = Path(j["path"])
        total = _file_info(p, j.get("id_col", "B"),
                           start_row=int(j.get("start_row", 2) or 2),
                           end_row=j.get("end_row"))
        searched = db.count_searched_ids(p.name, user_id=j.get("user_id"))
        j["total_rows"] = total or 0
        j["searched"] = searched
        j["done"] = (total is not None and total > 0 and searched >= total)
    return jsonify(jobs)


@app.route("/api/upload", methods=["POST"])
@login_required
def api_upload():
    if "file" not in request.files:
        return jsonify({"error": "ไม่มีไฟล์"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "ไม่มีไฟล์"}), 400
    if not f.filename.lower().endswith(".xlsx"):
        return jsonify({"error": "ต้องเป็นไฟล์ .xlsx"}), 400
    safe = secure_filename(f.filename) or "upload.xlsx"
    if not safe.lower().endswith(".xlsx"):
        safe += ".xlsx"
    # แยกโฟลเดอร์รายผู้ใช้ — ไฟล์ชื่อเดียวกันจากคนละคนจะไม่ทับกันบนดิสก์อีก
    # และความเป็นเจ้าของบังคับได้ที่ระดับ path จริง ไม่ใช่แค่ป้ายใน job
    udir = UPLOAD_DIR / str(session.get("user_id", 0))
    udir.mkdir(parents=True, exist_ok=True)
    dest = udir / f.filename.replace("/", "_").replace("\\", "_")
    try:
        f.save(dest)
    except Exception:
        dest = udir / safe
        f.save(dest)

    # ── นำเข้าไฟล์แบบอัจฉริยะ: จำรูปแบบไฟล์ที่เคยเจอ + ตรวจจับคอลัมน์เลขบัตร 13 หลักอัตโนมัติ ──
    # ลำดับความสำคัญของคอลัมน์:  ระบุเอง(manual) > รูปแบบที่จำไว้(learned) > ตรวจจับ(detected)
    manual_id = (request.form.get("id_col") or "").strip().upper()
    manual_out = (request.form.get("out_col") or "").strip().upper()
    sr_form = request.form.get("start_row")
    er = request.form.get("end_row")

    # ลายเซ็นรูปแบบไฟล์จากหัวตาราง + สิ่งที่เคยเรียนรู้ไว้
    signature, headers = None, {}
    try:
        signature, headers = engine.read_header_signature(dest)
    except Exception:
        signature, headers = None, {}
    learned = db.get_file_format(signature) if signature else None

    detected = None
    source = "manual"          # manual | learned | detected
    id_col = manual_id
    out_col = manual_out
    start_row = None
    if sr_form:
        try:
            start_row = int(sr_form)
        except ValueError:
            start_row = None

    # เติมจากรูปแบบที่จำไว้ก่อน (ถ้าผู้ใช้ไม่ได้ระบุเอง)
    if learned and (not id_col or not out_col or start_row is None):
        if not manual_id:
            source = "learned"
        id_col = id_col or (learned.get("id_col") or "")
        out_col = out_col or (learned.get("out_col") or "")
        if start_row is None and learned.get("start_row"):
            start_row = learned["start_row"]

    # ยังไม่มีคอลัมน์เลขบัตร → ตรวจจับอัตโนมัติ (หาเลข 13 หลัก)
    if not id_col:
        try:
            detected = engine.detect_columns(dest)
        except Exception:
            detected = None
        if detected:
            source = "detected"
            id_col = detected["id_col"]
            out_col = out_col or detected["out_col"]
            if start_row is None:
                start_row = detected.get("start_row")

    if not id_col:
        # ตรวจไม่พบและไม่เคยจำ — ลบไฟล์ที่เพิ่งอัปโหลด แล้วแจ้งผู้ใช้
        try:
            dest.unlink()
        except OSError:
            pass
        return jsonify({"error": (
            "ตรวจไม่พบคอลัมน์เลขบัตรประชาชน 13 หลักในไฟล์นี้ — "
            "โปรดตรวจสอบว่ามีคอลัมน์เลขบัตร 13 หลัก หรือระบุคอลัมน์เองในตัวเลือกขั้นสูง")}), 400

    out_col = out_col or "F"
    if start_row is None:
        start_row = 2

    job = {
        # id สำหรับอ้างงานชิ้นนี้แทนดัชนีในคิว (ดัชนีเพี้ยนทันทีที่คิวถูกกรองตามผู้ใช้)
        "id": uuid.uuid4().hex[:12],
        "user_id": session.get("user_id", 0),
        "path": str(dest).replace("\\", "/"),
        "id_col": id_col,
        "out_col": out_col,
        "no_year": request.form.get("no_year") == "true",
        "start_row": start_row,
    }
    reason_val = (request.form.get("reason") or "").strip()
    if reason_val and reason_val != "random":
        job["reason"] = reason_val
    if er:
        try:
            job["end_row"] = int(er)
        except ValueError:
            pass

    # เรียนรู้/จดจำรูปแบบไฟล์นี้ไว้ (ทั้งจากการตรวจจับอัตโนมัติและการที่ผู้ใช้ระบุเอง)
    if signature:
        try:
            headers_txt = json.dumps(headers, ensure_ascii=False)
        except Exception:
            headers_txt = ""
        db.save_file_format(signature, id_col, out_col, start_row, headers_txt)

    jobs = engine.load_queue()
    norm = str(dest.resolve()).replace("\\", "/")
    jobs = [j for j in jobs
            if str(Path(j["path"]).resolve()).replace("\\", "/") != norm]
    jobs.append(job)
    engine.save_queue(jobs)
    info = _file_info(dest, job["id_col"])
    return jsonify({"ok": True, "job": job, "rows": info,
                    "detected": detected, "source": source,
                    "remembered": bool(learned)})


def _file_info(path, id_col, start_row=2, end_row=None):
    # นับจำนวนเลขบัตรในไฟล์แบบเดียวกับที่ worker ค้นจริง (worker._count_rows):
    # เริ่มที่ start_row (1 ถ้าไฟล์ไม่มีหัวตาราง, 2 ถ้ามี) และหยุดที่ช่องว่างแรก/end_row
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True)
        ws = wb.active
        col = engine.col_letter_to_num(id_col)
        n = 0
        r = int(start_row or 2)
        while True:
            if end_row is not None and r > end_row:
                break
            v = ws.cell(r, col).value
            if v is None or str(v).strip() == "":
                break
            n += 1
            r += 1
        wb.close()
        return n
    except Exception:
        return None


@app.route("/api/queue/remove", methods=["POST"])
@login_required
def api_queue_remove():
    """ลบงานออกจากคิว — อ้างด้วย id ของงาน (ลบได้เฉพาะงานที่ตัวเองเห็น)

    ยังรับ index แบบเก่าไว้เพื่อความเข้ากันได้ แต่ตีความกับ 'รายการที่ผู้เรียกมองเห็น'
    ไม่ใช่คิวเต็ม — กันการลบผิดไฟล์เมื่อคิวถูกกรองตามผู้ใช้"""
    data = request.json or {}
    jobs = engine.load_queue()
    vis = _visible_jobs(jobs)
    target = None
    jid = data.get("id")
    if jid:
        target = next((j for j in vis if j.get("id") == jid), None)
    else:
        idx = data.get("index")
        if isinstance(idx, int) and 1 <= idx <= len(vis):
            target = vis[idx - 1]
    if target is not None:
        jobs = [j for j in jobs if j is not target]
        engine.save_queue(jobs)
    return jsonify({"ok": True, "queue": _visible_jobs(jobs)})


@app.route("/api/queue/clear", methods=["POST"])
@login_required
def api_queue_clear():
    """ล้างคิว — สมาชิกล้างเฉพาะงานของตัวเอง (+งานกลาง), แอดมินล้างทั้งหมด"""
    if _is_admin():
        engine.save_queue([])
    else:
        jobs = engine.load_queue()
        engine.save_queue([j for j in jobs if not _owns_job(j)])
    return jsonify({"ok": True})


# ---------------- API: run control ----------------
@app.route("/api/run/start", methods=["POST"])
@login_required
def api_run_start():
    data = request.json or {}
    select = data.get("select")
    account = (data.get("account") or auth.load_config().get("account") or "").strip()

    # ⚠ ตรวจว่าไม่มีรอบกำลังรัน 'ก่อน' แตะสถานะใด ๆ ของ manager —
    # เดิมตั้ง current_user_id ก่อนตรวจ ทำให้คนที่สองที่กดระหว่างรอบแรกทำงาน
    # เปลี่ยนเจ้าของรอบ (และการคิดเงิน) ของแถวที่เหลือทั้งหมดโดยไม่ตั้งใจ
    if manager.is_busy():
        return jsonify({"ok": False, "message": "มีงานกำลังทำงานอยู่"}), 409

    # รันเฉพาะงานของผู้กด (+งานเก่าที่ไม่มีเจ้าของ) — ไม่ลากไฟล์ของคนอื่นทั้งคิวมารัน
    jobs = _visible_jobs(engine.load_queue())
    if not jobs:
        return jsonify({"error": "คิวว่าง"}), 400
    if select:
        picked = []
        for s in select:
            if isinstance(s, str):          # อ้างด้วย id ของงาน (ทางที่แนะนำ)
                m = next((j for j in jobs if j.get("id") == s), None)
                if m and m not in picked:
                    picked.append(m)
            elif isinstance(s, int) and 1 <= s <= len(jobs):   # ดัชนีในรายการที่มองเห็น
                if jobs[s - 1] not in picked:
                    picked.append(jobs[s - 1])
        jobs = picked
    if not jobs:
        return jsonify({"error": "ไม่ได้เลือกไฟล์"}), 400
    speed = auth.load_config().get("search_speed", engine.DEFAULT_SPEED)
    step_mode = bool(data.get("step_mode"))
    # บันทึกสเต็ป: ถ้าไม่ส่ง record มา ให้ตามค่า step_mode (โหมดทีละขั้น=บันทึกอัตโนมัติ)
    record = data.get("record")
    record = bool(record) if record is not None else None
    ok, msg = manager.start(jobs, account, speed=speed, step_mode=step_mode,
                            record=record, user_id=session.get("user_id", 0))
    return jsonify({"ok": ok, "message": msg}), (200 if ok else 409)


@app.route("/api/run/confirm-login", methods=["POST"])
@login_required
def api_confirm_login():
    guard = _run_owner_guard()
    if guard:
        return guard
    manager.confirm_login()
    return jsonify({"ok": True})


@app.route("/api/run/step", methods=["POST"])
@login_required
def api_run_step():
    """โหมดทีละขั้น: สั่งทำขั้นต่อไป"""
    guard = _run_owner_guard()
    if guard:
        return guard
    manager.next_step()
    return jsonify({"ok": True})


@app.route("/api/run/auto", methods=["POST"])
@login_required
def api_run_auto():
    """สลับจากโหมดทีละขั้นเป็นอัตโนมัติ (เดินต่อเองจนจบ)"""
    guard = _run_owner_guard()
    if guard:
        return guard
    manager.set_auto()
    return jsonify({"ok": True})


@app.route("/api/run/close-browser", methods=["POST"])
@login_required
def api_run_close_browser():
    """ปิดเบราว์เซอร์ที่เปิดค้างอยู่หลังทำงานเสร็จ"""
    guard = _run_owner_guard()
    if guard:
        return guard
    manager.close_browser()
    return jsonify({"ok": True})


@app.route("/api/run/stop", methods=["POST"])
@login_required
def api_run_stop():
    guard = _run_owner_guard()
    if guard:
        return guard
    manager.stop()
    return jsonify({"ok": True})


@app.route("/api/run/pause", methods=["POST"])
@login_required
def api_run_pause():
    """พักชั่วคราว — มีผลเมื่อจบแถวปัจจุบัน (ระบบบันทึกไฟล์ให้ก่อนพัก)
    ใช้คู่กับ 'ค้นต่อ' สำหรับกรณีแบตใกล้หมด/ต้องย้ายที่/เน็ตไม่เสถียร"""
    guard = _run_owner_guard()
    if guard:
        return guard
    manager.pause()
    return jsonify({"ok": True})


@app.route("/api/run/resume", methods=["POST"])
@login_required
def api_run_resume():
    """ค้นต่อจากแถวที่พักไว้ (หลังพักด้วยมือ / เน็ตหลุด / ผิดพลาดติดกัน)"""
    guard = _run_owner_guard()
    if guard:
        return guard
    manager.resume()
    return jsonify({"ok": True})


@app.route("/api/run/speed", methods=["POST"])
@login_required
def api_run_speed():
    """ปรับความเร็วการค้น 1(ช้าสุด)–5(เร็วสุด) — ใช้ได้ทั้งตอนว่างและระหว่างค้น
    body: {"delta": +1|-1} หรือ {"level": 1..5}
    ระหว่างรอบทำงาน = มีผลกับรอบปัจจุบันตั้งแต่จังหวะหน่วงถัดไป
    ตอนว่าง = ตั้งค่าเริ่มต้นของรอบถัดไป"""
    guard = _run_owner_guard()
    if guard:
        return guard
    data = request.json or {}
    level, delta = data.get("level"), data.get("delta")
    if level is None and delta is None:
        return jsonify({"error": "ต้องระบุ level หรือ delta"}), 400
    try:                      # แปลงเองเพื่อให้ค่าพัง ๆ เป็น 400 ไม่ใช่ตกไปใช้ค่าเริ่มต้นเงียบ ๆ
        level = int(level) if level is not None else None
        delta = int(delta) if delta is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "level/delta ต้องเป็นตัวเลข"}), 400
    res = manager.set_speed(level=level, delta=delta)
    if res.get("changed"):
        # จำค่าไว้เป็นค่าเริ่มต้นของรอบถัดไป (เขียนผ่าน update_config: ล็อก+atomic)
        auth.update_config(search_speed=res["speed"])
        _audit("speed_change", f"{res['prev']} -> {res['speed']}")
    return jsonify({"ok": True, **res})


@app.route("/api/run/save-now", methods=["POST"])
@login_required
def api_run_save_now():
    """ขอบันทึกผลลงไฟล์เดี๋ยวนี้ระหว่างค้น (ยังค้นไม่ครบก็ดาวน์โหลดได้)
    คืน save_seq ปัจจุบัน — หน้าเว็บรอจนค่าใน /api/status ขยับ แล้วจึงเริ่มดาวน์โหลด"""
    guard = _run_owner_guard()
    if guard:
        return guard
    seq = manager.request_save()
    return jsonify({"ok": True, "save_seq": seq})


@app.route("/api/run/retry-errors", methods=["POST"])
@login_required
def api_run_retry_errors():
    """สั่งลองค้นแถวที่ผิดพลาดอีกครั้งด้วยตนเอง — รวมแถวที่ระบบเลิกลองเองแล้ว
    (ERROR ถาวร / ครบเพดานจำนวนครั้ง) จึงเป็นทางออกเดียวของแถวที่ถูกข้ามถาวร"""
    if manager.is_busy():
        return jsonify({"error": "มีงานกำลังทำงานอยู่ — โปรดรอให้จบก่อน"}), 409
    jobs = _visible_jobs(engine.load_queue())
    if not jobs:
        return jsonify({"error": "คิวว่าง"}), 400
    account = (request.json or {}).get("account") or auth.load_config().get("account", "")
    speed = auth.load_config().get("search_speed", engine.DEFAULT_SPEED)
    ok, msg = manager.start(jobs, str(account).strip(), speed=speed,
                            user_id=session.get("user_id", 0), retry_only=True)
    if ok:
        _audit("run_retry_errors", f"files={len(jobs)}")
    return jsonify({"ok": ok, "message": msg}), (200 if ok else 409)


@app.route("/api/run/reset", methods=["POST"])
@login_required
def api_run_reset():
    """เริ่มรอบใหม่ — ล้างคิว + ลบไฟล์อัปโหลดที่ค้างอยู่ + รีเซ็ตสถานะให้พร้อมรับไฟล์ใหม่

    ประวัติการค้นทั้งหมด (ในฐานข้อมูล) ยังถูกเก็บไว้เหมือนเดิม ไม่ถูกลบ
    ปลอดภัยต่อการกดซ้ำหลายครั้ง (serialize ด้วย _reset_lock + ไม่โยน 500)
    """
    with _reset_lock:
        if manager.is_busy():
            return jsonify({"error": "มีงานกำลังทำงานอยู่ — โปรดหยุดก่อนเริ่มรอบใหม่"}), 409
        removed = 0
        try:
            jobs = engine.load_queue()
            # สมาชิกลบได้เฉพาะงาน (และไฟล์) ของตัวเอง+งานกลาง — แอดมินลบทั้งหมด
            mine = _visible_jobs(jobs)
            up_dir = str(config.UPLOAD_DIR.resolve())
            for j in mine:
                try:
                    p = Path(j["path"]).resolve()
                    # ลบเฉพาะไฟล์สำเนาในโฟลเดอร์ uploads เท่านั้น (ไม่แตะไฟล์ต้นฉบับของผู้ใช้)
                    if str(p).startswith(up_dir) and p.exists():
                        p.unlink()
                        removed += 1
                except OSError:
                    pass
            engine.save_queue([j for j in jobs if j not in mine])
        except Exception:
            # กันไม่ให้เกิด 500 หากคิว/ไฟล์ถูกแตะพร้อมกัน — คิวถูกล้างด้วย reset_round อยู่ดี
            pass
        ok, msg = manager.reset_round()
        if not ok:
            return jsonify({"error": msg}), 409
    return jsonify({"ok": True, "uploads_removed": removed})


@app.route("/api/status")
@login_required
def api_status():
    """สถานะรอบทำงาน — ผู้ที่ไม่ใช่เจ้าของรอบเห็นเฉพาะตัวเลขภาพรวม
    (log สด/ชื่อไฟล์/บัญชีผู้ค้น เป็นข้อมูลของงานคนอื่น — ปิดไว้)"""
    st = manager.status()
    owner = getattr(manager, "current_user_id", 0) or 0
    mine = _is_admin() or owner in (0, session.get("user_id"))
    st["run_owner"] = bool(mine)
    if not mine:
        st = {**st, "log": [], "current_file": "", "current_path": "",
              "account": "", "last_recording": "", "current_step": ""}
    return jsonify(st)


# ---------------- API: analytics ----------------
@app.route("/api/summary")
@login_required
def api_summary():
    # สมาชิกเห็นเฉพาะสถิติของตัวเอง — แอดมินเห็นภาพรวมทั้งระบบ (uid=None)
    uid = _scope_uid()
    months = db.available_months(uid)
    ym = request.args.get("ym") or (months[0] if months else "")
    return jsonify({
        "ym": ym,
        "months": months,
        "totals": db.month_totals(ym, uid) if ym else {},
        "by_account": db.month_by_account(ym, uid) if ym else [],
        "daily": db.daily_series(ym, uid) if ym else [],
        "overall": db.overall_stats(uid),
        "can_adjust": _is_admin(),
        # ตัวปรับยอดเป็นค่าระดับทั้งระบบ — แสดงเฉพาะมุมมองแอดมิน
        "adjust": (db.get_summary_adjust(ym) if (ym and _is_admin()) else None),
    })


@app.route("/api/admin/summary/adjust", methods=["POST"])
@admin_required
def api_summary_adjust():
    """แก้ไขจำนวนสรุปบนแดชบอร์ด (ค้นทั้งหมด/พบ/ไม่พบ/ผิดพลาด/จำนวนคดี) รายเดือน
    เฉพาะ Super Admin + ต้องใส่รหัสยืนยัน (รหัสเดียวกับล้างข้อมูลทั้งหมด)
    """
    data = request.json or {}
    err = _check_action_code(data)
    if err:
        return err
    ym = (data.get("ym") or "").strip()
    if not ym:
        return jsonify({"error": "ไม่ระบุเดือน"}), 400

    def _num(v):
        if v is None or v == "":
            return None
        try:
            n = int(v)
            return n if n >= 0 else None
        except (ValueError, TypeError):
            return None

    fields = {k: _num(data.get(k)) for k in ("total", "found", "notfound", "error", "cases")}
    note = (data.get("note") or "").strip()
    db.set_summary_adjust(ym, note=note, **fields)
    return jsonify({"ok": True, "totals": db.month_totals(ym)})


@app.route("/api/recent")
@login_required
def api_recent():
    # ประวัติการค้นมีเลขบัตร (ปิดบังบางส่วน) + ชื่อไฟล์งาน — สมาชิกเห็นเฉพาะของตัวเอง
    uid = _scope_uid()
    return jsonify({
        "searches": db.recent_searches(60, user_id=uid),
        "runs": db.recent_runs(15, user_id=uid),
    })


# ---------------- API: settings ----------------
@app.route("/api/settings", methods=["GET", "POST"])
@login_required
def api_settings():
    cfg = auth.load_config()
    if request.method == "POST":
        data = request.json or {}
        changes = {}
        # ---- ตรวจสิทธิ์ให้ครบก่อนแตะข้อมูลใด ๆ ----
        # เดิมตรวจ fresh-auth ไว้ท้ายสุด ทำให้ตอบ 403 ทั้งที่ชื่อที่แสดง/เหตุผล/ความเร็ว
        # ถูกเขียนลงไปแล้ว (ปฏิเสธครึ่งเดียว)
        sensitive = [k for k in ("bind_host", "port", "update_url") if k in data]
        if sensitive and not _is_admin():
            return jsonify({"error": "เฉพาะ Super Admin เท่านั้นที่แก้ค่าระดับระบบได้"}), 403
        if sensitive and not _fresh_auth_ok():
            return jsonify({"error": "ต้องยืนยันรหัสผ่านก่อนแก้ค่าเครือข่าย/URL อัปเดต",
                            "need_password": True}), 403
        # รายการเหตุผลการค้นเป็นค่าที่ใช้ร่วมกันทั้งเครื่อง ไม่ใช่ค่าส่วนตัว —
        # เดิมอยู่นอกด่านแอดมิน สมาชิกคนใดก็เขียนทับของทุกคนได้
        if "search_reasons" in data and not _is_admin():
            return jsonify({"error": "เฉพาะ Super Admin เท่านั้นที่แก้รายการเหตุผลการค้นได้"}), 403
        if "display_name" in data:
            new_dn = str(data["display_name"]).strip()
            changes["display_name"] = new_dn
            uid = session.get("user_id")
            if uid:
                db.update_user(uid, display_name=new_dn)
                session["display_name"] = new_dn
        if "search_reasons" in data:
            raw = data["search_reasons"]
            if isinstance(raw, list):
                clean = [s.strip() for s in raw if isinstance(s, str) and s.strip()]
                changes["search_reasons"] = clean
                engine.set_search_reasons(clean)
        if "search_speed" in data:
            lv = engine.clamp_speed(data["search_speed"])
            changes["search_speed"] = lv
            # ต้องปรับผ่าน manager.set_speed เท่านั้น (ห้ามเรียก engine.set_speed ตรง ๆ):
            #  (1) manager ตั้งทั้ง engine และ self.speed — ถ้าตั้งแต่ engine อย่างเดียว
            #      worker._run() จะเขียนทับด้วย self.speed เดิมตอน login เสร็จ (ค่าที่ตั้ง
            #      ระหว่าง launching/awaiting_login หายเงียบ ๆ)
            #  (2) ผ่านด่านเจ้าของรอบเหมือน /api/run/speed — คนอื่นต้องเปลี่ยนจังหวะของ
            #      รอบที่กำลังทำงานอยู่ไม่ได้
            # ถ้าเป็นรอบของผู้อื่น: ยังบันทึกเป็นค่าเริ่มต้นของรอบถัดไปได้ แต่ไม่แตะรอบที่รันอยู่
            if _run_owner_guard() is None:
                manager.set_speed(level=lv)
        # ค่าระดับระบบ (ชื่อหน่วยงาน / การผูกเครือข่าย / URL อัปเดต) — เฉพาะ Super Admin ตั้งได้
        # กันไม่ให้สมาชิกทั่วไปเปลี่ยน bind_host เป็น 0.0.0.0 (เปิดเซิร์ฟเวอร์ออกสู่เครือข่าย)
        if _is_admin():
            if "account" in data:
                changes["account"] = str(data["account"]).strip()
            if "bind_host" in data and data["bind_host"] in ("127.0.0.1", "0.0.0.0"):
                changes["bind_host"] = data["bind_host"]
            if "port" in data:
                try:
                    changes["port"] = int(data["port"])
                except (ValueError, TypeError):
                    pass
            if "update_url" in data:
                new_url = str(data["update_url"]).strip()
                changes["update_url"] = new_url
                # URL อัปเดตคือจุดที่ระบบดาวน์โหลดโค้ดมาติดตั้งทับ — บันทึกทุกการเปลี่ยน
                if new_url != cfg.get("update_url", ""):
                    _audit("update_url_changed", new_url[:200])
        if changes:
            # เขียนผ่าน update_config เท่านั้น (ล็อก + atomic) — ห้าม save_config ตรง ๆ
            cfg = auth.update_config(**changes)
    user = current_user()
    return jsonify({
        "display_name": user["display_name"] if user else cfg.get("display_name", ""),
        "account": cfg.get("account", ""),
        "bind_host": cfg.get("bind_host", "127.0.0.1"),
        "port": cfg.get("port", 8770),
        "search_speed": engine.clamp_speed(cfg.get("search_speed", engine.DEFAULT_SPEED)),
        "search_reasons": engine.get_search_reasons(),
        "update_url": cfg.get("update_url", ""),
        "version": config.APP_VERSION,
    })


@app.route("/api/password", methods=["POST"])
@login_required
def api_password():
    data = request.json or {}
    uid = session.get("user_id")
    user = db.get_user(uid)
    if not user:
        return jsonify({"error": "ผู้ใช้ไม่พบ"}), 400
    scope = f"chpw:{uid}"
    wait = db.auth_lock_remaining(scope)
    if wait:
        return jsonify({"error": f"กรอกผิดหลายครั้ง — รออีก {wait} วินาที",
                        "locked_seconds": wait}), 429
    check = db.verify_user(user["username"], data.get("current", ""))
    if not check:
        wait = db.record_auth_fail(scope)
        _audit("password_change_failed")
        return jsonify({"error": "รหัสผ่านเดิมไม่ถูกต้อง", "locked_seconds": wait}), 400
    new = data.get("new", "")
    if len(new) < 6:
        return jsonify({"error": "รหัสใหม่อย่างน้อย 6 ตัว"}), 400
    db.reset_auth_fails(scope)
    db.change_user_password(uid, new)
    _audit("password_changed")
    return jsonify({"ok": True})


@app.route("/api/download")
@login_required
def api_download():
    path = request.args.get("path", "")
    target = str(Path(path).resolve())
    # ไฟล์ผลลัพธ์มีเลขบัตรเต็ม — ดาวน์โหลดได้เฉพาะเจ้าของงาน (หรือแอดมิน)
    job = next((j for j in engine.load_queue()
                if str(Path(j["path"]).resolve()) == target), None)
    if job is None or not _owns_job(job):
        return jsonify({"error": "ไม่อนุญาต"}), 403
    p = Path(target)
    # ถ้าไฟล์ต้นฉบับถูกเปิดค้างจนระบบต้องบันทึกไว้ที่ _backup.xlsx → ส่งไฟล์ที่มีผลใหม่ล่าสุด
    # (ชื่อไฟล์ที่ดาวน์โหลดยังใช้ชื่อต้นฉบับตามเดิม)
    backup = p.with_name(p.stem + "_backup.xlsx")
    src = p
    if backup.exists() and (not p.exists()
                            or backup.stat().st_mtime > p.stat().st_mtime):
        src = backup
    if not src.exists():
        return jsonify({"error": "ไม่พบไฟล์"}), 404
    count = db.count_searched_ids(p.name, user_id=_scope_uid())
    if count > 0:
        dl_name = f"{p.stem}({count}ชื่อ){p.suffix}"
    else:
        dl_name = p.name
    return send_file(src, as_attachment=True, download_name=dl_name)


# ---------------- API: version / update check ----------------
def _version_tuple(v):
    nums = [int(x) for x in re.findall(r"\d+", v or "")]
    return tuple(nums) if nums else (0,)


def _version_gt(a, b):
    """คืน True ถ้าเวอร์ชัน a ใหม่กว่า b (เทียบตัวเลขทีละส่วน)"""
    ta, tb = list(_version_tuple(a)), list(_version_tuple(b))
    n = max(len(ta), len(tb))
    ta += [0] * (n - len(ta))
    tb += [0] * (n - len(tb))
    return ta > tb


@app.route("/api/version")
@login_required
def api_version():
    """คืนเวอร์ชันปัจจุบัน + ตรวจสอบเวอร์ชันล่าสุดจาก manifest URL (ถ้าตั้งไว้)"""
    cfg = auth.load_config()
    url = (cfg.get("update_url") or "").strip()
    out = {
        "version": config.APP_VERSION,
        "latest": None,
        "update_available": False,
        "notes": "",
        "download_url": "",
        "checked": False,
        "error": "",
    }
    if url:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "CRIMES-AUTO-Updater"})
            with urllib.request.urlopen(req, timeout=5) as r:
                data = json.loads(r.read().decode("utf-8"))
            latest = str(data.get("version", "")).strip()
            out["latest"] = latest
            out["notes"] = str(data.get("notes", ""))[:500]
            out["download_url"] = str(data.get("url", ""))[:500]
            out["checked"] = True
            out["update_available"] = bool(latest) and _version_gt(latest, config.APP_VERSION)
        except Exception as e:
            out["error"] = str(e)[:150]
    return jsonify(out)


def _sha256_file(path, chunk=1 << 20):
    """คำนวณ SHA-256 ของไฟล์ (อ่านทีละบล็อก รองรับไฟล์ใหญ่)"""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(chunk), b""):
            h.update(blk)
    return h.hexdigest()


def _apply_update_from_zip(zippath, dest_app, expected_sha256=None):
    """แตกไฟล์ชุดอัปเดต แล้วก๊อปโฟลเดอร์ app ทับของเดิม (เก็บ data/uploads เดิมไว้)
    คืนเลขเวอร์ชันใหม่ที่ติดตั้ง

    expected_sha256: ถ้าระบุ (มาจากช่อง sha256 ใน manifest) จะตรวจ integrity ของไฟล์
    ก่อนแตก — ไม่ตรงจะยกเลิกทันที กันไฟล์อัปเดตถูกแก้ไข/สลับ/ดาวน์โหลดไม่ครบ
    """
    zippath = Path(zippath)
    # ตรวจ integrity ก่อนแตกไฟล์ (สำคัญ: กันการติดตั้งโค้ดที่ถูกดัดแปลง)
    if expected_sha256:
        actual = _sha256_file(zippath)
        if actual.lower() != str(expected_sha256).strip().lower():
            raise ValueError(
                "checksum (SHA-256) ของไฟล์อัปเดตไม่ตรงกับที่ประกาศใน manifest — "
                "ไฟล์อาจถูกแก้ไขหรือดาวน์โหลดไม่สมบูรณ์ · ยกเลิกการติดตั้งเพื่อความปลอดภัย")
    else:
        print("[update][!] manifest ไม่มีช่อง sha256 — ข้ามการตรวจ integrity "
              "(แนะนำให้ใส่ sha256 ของไฟล์ .zip ใน manifest เพื่อความปลอดภัย)")
    if not zipfile.is_zipfile(zippath):
        raise ValueError("ไฟล์ที่ดาวน์โหลดไม่ใช่ .zip (ตรวจลิงก์ดาวน์โหลดใน manifest)")
    exdir = zippath.parent / "ex"
    with zipfile.ZipFile(zippath) as z:
        z.extractall(exdir)
    # หาโฟลเดอร์ app ที่ถูกต้อง (มี VERSION + backend/server.py)
    app_src = None
    for cand in exdir.rglob("VERSION"):
        if (cand.parent / "backend" / "server.py").exists():
            app_src = cand.parent
            break
    if not app_src:
        raise ValueError("ไม่พบโฟลเดอร์ app ที่ถูกต้องในชุดอัปเดต")
    dest_app = Path(dest_app)
    for item in sorted(app_src.rglob("*")):
        rel = item.relative_to(app_src)
        parts = rel.parts
        if "__pycache__" in parts:
            continue
        # เก็บข้อมูลเดิมของเครื่อง (บัญชี/ประวัติ/ไฟล์อัปโหลด)
        if len(parts) >= 2 and parts[0] == "backend" and parts[1] in ("data", "uploads"):
            continue
        target = dest_app / rel
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)
    return (app_src / "VERSION").read_text(encoding="utf-8").strip()


@app.route("/api/update/apply", methods=["POST"])
@admin_required
@fresh_auth_required
def api_update_apply():
    """อัปเดตออนไลน์ในตัว: ดาวน์โหลดชุดอัปเดตจาก manifest แล้วติดตั้งทับ (เก็บข้อมูลเดิม)
    ต้องปิด-เปิดโปรแกรมใหม่หลังอัปเดตเพื่อโหลดโค้ดใหม่
    """
    if manager.is_busy():
        return jsonify({"error": "มีงานค้นกำลังทำงานอยู่ — โปรดหยุดก่อนอัปเดต"}), 409
    # กันอัปเดตซ้อนกัน (กดปุ่มรัว/หลายแท็บ) — ไม่บล็อกรอ ถ้ามีตัวกำลังอัปเดตอยู่ให้แจ้งเลย
    if not _update_lock.acquire(blocking=False):
        return jsonify({"error": "กำลังอัปเดตอยู่แล้ว — โปรดรอสักครู่"}), 409
    try:
        cfg = auth.load_config()
        url = (cfg.get("update_url") or "").strip()
        if not url:
            return jsonify({"error": "ยังไม่ได้ตั้ง URL ตรวจสอบอัปเดต (ตั้งได้ที่หน้าตั้งค่า)"}), 400
        # ดึง manifest ล่าสุด
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "CRIMES-AUTO-Updater"})
            with urllib.request.urlopen(req, timeout=10) as r:
                manifest = json.loads(r.read().decode("utf-8"))
        except Exception as e:
            return jsonify({"error": f"ตรวจสอบอัปเดตออนไลน์ไม่ได้: {str(e)[:120]}"}), 502
        latest = str(manifest.get("version", "")).strip()
        dl = str(manifest.get("url", "")).strip()
        sha = str(manifest.get("sha256", "")).strip()
        if not latest or not _version_gt(latest, config.APP_VERSION):
            return jsonify({"error": "ใช้เวอร์ชันล่าสุดอยู่แล้ว"}), 400
        if not dl:
            return jsonify({"error": "manifest ไม่มีลิงก์ดาวน์โหลด (ช่อง url)"}), 400
        # ดาวน์โหลด + ติดตั้ง (ตรวจ SHA-256 ก่อนติดตั้งถ้า manifest ระบุ sha256)
        tmpdir = Path(tempfile.mkdtemp(prefix="crimes_upd_"))
        try:
            zp = tmpdir / "update.zip"
            req = urllib.request.Request(dl, headers={"User-Agent": "CRIMES-AUTO-Updater"})
            with urllib.request.urlopen(req, timeout=90) as r, open(zp, "wb") as f:
                shutil.copyfileobj(r, f)
            new_ver = _apply_update_from_zip(zp, config.PROJECT_DIR, expected_sha256=sha or None)
        except Exception as e:
            return jsonify({"error": f"อัปเดตไม่สำเร็จ: {str(e)[:180]}"}), 500
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
        _audit("update_apply", f"{config.APP_VERSION} -> {new_ver}")
        # รีสตาร์ทอัตโนมัติ (ถ้ารันเป็นแอปเดสก์ท็อป) — หน่วง 1.5 วิให้ response ส่งถึงเบราว์เซอร์ก่อน
        restarting = callable(RESTART_HOOK)
        if restarting:
            threading.Timer(1.5, _trigger_restart).start()
        return jsonify({"ok": True, "version": new_ver, "restarting": restarting})
    finally:
        _update_lock.release()


# ---------------- API: user/session info ----------------
@app.route("/api/me")
@login_required
def api_me():
    user = current_user()
    if not user:
        return jsonify({"error": "unauthorized"}), 401
    return jsonify({
        "id": user["id"],
        "username": user["username"],
        "display_name": user["display_name"],
        "role": user["role"],
        "permissions": db.get_permissions(user["id"]),
        "permission_labels": db.PERMISSION_KEYS,
        "version": config.APP_VERSION,
    })


# ---------------- API: my billing (สมาชิกเห็นเฉพาะของตัวเอง + ทีมตัวเอง) ----------------
@app.route("/api/my/billing")
@login_required
def api_my_billing():
    uid = session.get("user_id")
    ym = request.args.get("ym", "")
    # รายชื่อเดือนต้องอยู่ในขอบเขตของผู้เรียก — เดิมดึงทั้งระบบ ทำให้สมาชิกเห็นว่ามีการ
    # ใช้งานเดือนไหนบ้างทั้งองค์กร (และเดือนที่ตัวเองไม่มีข้อมูลเลย)
    months = db.available_months(_scope_uid())
    if not ym and months:
        ym = months[0]
    mine = db.billing_user_monthly(ym, uid) if ym else {"daily": [], "total_count": 0, "total_amount": 0, "rate": db.get_billing_rate()}
    teams = []
    for tid in db.teams_for_user(uid):
        if not ym:
            continue
        tb = db.team_billing(tid, ym)
        team = db.get_team(tid)
        # เผยเฉพาะข้อมูลรวมของทีม + ส่วนของผู้ใช้คนนี้ (ไม่เปิดยอดรายคนของเพื่อนร่วมทีม)
        me_row = next((m for m in tb["members"] if m["user_id"] == uid), None)
        teams.append({
            "id": tid,
            "name": team["name"] if team else "",
            "member_count": tb["member_count"],
            "total_count": tb["total_count"],
            "total_amount": tb["total_amount"],
            "per_person": tb["per_person"],
            "my_count": me_row["count"] if me_row else 0,
            "my_amount": me_row["amount"] if me_row else 0,
            "my_rate": me_row["rate"] if me_row else tb.get("team_rate") or tb["rate"],
        })
    return jsonify({"ym": ym, "months": months, "mine": mine, "teams": teams})


# ---------------- API: admin — member management ----------------
@app.route("/api/admin/members")
@perm_required("manage_members")
def api_admin_members():
    return jsonify(db.list_users())


@app.route("/api/admin/members", methods=["POST"])
@perm_required("manage_members")
@fresh_auth_required
def api_admin_member_create():
    data = request.json or {}
    username = (data.get("username") or "").strip()
    password = data.get("password", "")
    display_name = (data.get("display_name") or "").strip()
    role = data.get("role", "member")
    if not username or len(username) < 3:
        return jsonify({"error": "ชื่อผู้ใช้อย่างน้อย 3 ตัวอักษร"}), 400
    if len(password) < 6:
        return jsonify({"error": "รหัสผ่านอย่างน้อย 6 ตัว"}), 400
    if role not in ("super_admin", "member"):
        role = "member"
    # กันยกระดับสิทธิ์ตัวเอง: ผู้ที่ได้รับมอบหมายให้ 'จัดการสมาชิก' สร้างได้แค่สมาชิกธรรมดา
    # และตั้งสิทธิ์ให้คนอื่นไม่ได้ — มีแต่ Super Admin เท่านั้นที่แจกสิทธิ์/ตั้ง Super Admin ได้
    if not _is_admin() and (role == "super_admin" or data.get("permissions")):
        return jsonify({"error": "เฉพาะ Super Admin เท่านั้นที่กำหนดบทบาทและสิทธิ์ได้"}), 403
    try:
        uid = db.create_user(username, password, display_name=display_name, role=role)
        if isinstance(data.get("permissions"), dict):
            db.set_permissions(uid, data["permissions"])
        _audit("member_create", f"username={username} role={role} id={uid}")
        return jsonify({"ok": True, "id": uid})
    except Exception as e:
        if "UNIQUE" in str(e):
            return jsonify({"error": "ชื่อผู้ใช้นี้มีอยู่แล้ว"}), 400
        return jsonify({"error": str(e)}), 400


@app.route("/api/admin/members/<int:uid>", methods=["PUT"])
@perm_required("manage_members")
@fresh_auth_required
def api_admin_member_update(uid):
    data = request.json or {}
    target = db.get_user(uid)
    if not target:
        return jsonify({"error": "ไม่พบสมาชิก"}), 404
    # กันยกระดับสิทธิ์ตัวเอง — ผู้ที่ได้รับมอบหมายให้ 'จัดการสมาชิก' แก้ชื่อ/เปิดปิดบัญชี
    # และรีเซ็ตรหัสผ่านของสมาชิกธรรมดาได้ แต่แตะบัญชี Super Admin ไม่ได้ และเปลี่ยน
    # บทบาท/สิทธิ์ไม่ได้ (ไม่งั้นตั้งตัวเองเป็น Super Admin ได้ทันที)
    if not _is_admin():
        if target["role"] == "super_admin":
            return jsonify({"error": "เฉพาะ Super Admin เท่านั้นที่แก้ไขบัญชี Super Admin ได้"}), 403
        if "role" in data or "permissions" in data:
            return jsonify({"error": "เฉพาะ Super Admin เท่านั้นที่กำหนดบทบาทและสิทธิ์ได้"}), 403
        # ตั้งรหัสผ่านให้คนอื่น = เข้าบัญชีนั้นได้ทันที ผู้ที่ได้รับมอบหมายให้จัดการสมาชิก
        # จึงรีเซ็ตได้เฉพาะบัญชีที่ไม่มีสิทธิ์พิเศษ ไม่งั้นยืมสิทธิ์ของคนที่สูงกว่าตัวเองได้
        if data.get("password") and any(db.get_permissions(uid).values()):
            return jsonify({"error": "เฉพาะ Super Admin เท่านั้นที่รีเซ็ตรหัสผ่านของผู้มีสิทธิ์พิเศษได้"}), 403
    # กัน Super Admin คนสุดท้ายถูกลดสิทธิ์/ปิดใช้งาน
    demote = ("role" in data and data["role"] == "member" and target["role"] == "super_admin")
    deactivate = ("active" in data and not data["active"] and target["active"])
    if (demote or deactivate) and db.count_super_admins(exclude_id=uid) == 0:
        return jsonify({"error": "ต้องมี Super Admin ที่ใช้งานได้อย่างน้อย 1 คน"}), 400
    fields = {}
    if "display_name" in data:
        fields["display_name"] = str(data["display_name"]).strip()
    if "role" in data and data["role"] in ("super_admin", "member"):
        fields["role"] = data["role"]
    if "active" in data:
        fields["active"] = 1 if data["active"] else 0
    if "rate_per_name" in data:
        # อัตราค่าบริการเป็นเรื่องของฝั่งการเงิน — แยกสิทธิ์จากการจัดการสมาชิก
        if not _can("manage_billing"):
            return jsonify({"error": "ไม่มีสิทธิ์ (ตั้งอัตราค่าบริการและปรับยอด)"}), 403
        v = data["rate_per_name"]
        fields["rate_per_name"] = float(v) if v is not None and v != "" else None
    if fields:
        db.update_user(uid, **fields)
    if isinstance(data.get("permissions"), dict):
        db.set_permissions(uid, data["permissions"])
        fields["permissions"] = "set"
    pw_changed = False
    if "password" in data and data["password"]:
        pw = data["password"]
        if len(pw) < 6:
            return jsonify({"error": "รหัสผ่านอย่างน้อย 6 ตัว"}), 400
        db.change_user_password(uid, pw)
        pw_changed = True
    changed = sorted(set(fields.keys()) | ({"password"} if pw_changed else set()))
    _audit("member_update", f"id={uid} fields={','.join(changed) or 'none'}")
    return jsonify({"ok": True})


@app.route("/api/admin/members/<int:uid>", methods=["DELETE"])
@perm_required("manage_members")
@fresh_auth_required
def api_admin_member_delete(uid):
    if uid == session.get("user_id"):
        return jsonify({"error": "ไม่สามารถลบบัญชีตัวเองได้"}), 400
    target = db.get_user(uid)
    if not target:
        return jsonify({"error": "ไม่พบสมาชิก"}), 404
    if target["role"] == "super_admin" and not _is_admin():
        return jsonify({"error": "เฉพาะ Super Admin เท่านั้นที่ลบบัญชี Super Admin ได้"}), 403
    if target["role"] == "super_admin" and db.count_super_admins(exclude_id=uid) == 0:
        return jsonify({"error": "ลบไม่ได้ — ต้องมี Super Admin อย่างน้อย 1 คน"}), 400
    db.delete_user(uid)
    _audit("member_delete", f"id={uid} username={target['username']}")
    return jsonify({"ok": True})


@app.route("/api/admin/audit")
@perm_required("view_audit")
def api_admin_audit():
    """บันทึกการตรวจสอบ (audit log) — เหตุการณ์สำคัญด้านความปลอดภัย/การจัดการ (Super Admin)"""
    try:
        limit = min(max(int(request.args.get("limit", 200)), 1), 1000)
    except (TypeError, ValueError):
        limit = 200
    try:
        offset = max(int(request.args.get("offset", 0)), 0)
    except (TypeError, ValueError):
        offset = 0
    return jsonify({"entries": db.get_audit_log(limit=limit, offset=offset)})


# ---------------- API: admin — บันทึกโหมดทีละขั้น (ข้อมูลไว้ปรับปรุงระบบ) ----------------
@app.route("/api/admin/recordings")
@admin_required
def api_recordings_list():
    """รายการชุดบันทึกการทำงานโหมดทีละขั้น (ภาพ/HTML แต่ละสเต็ป) — Super Admin"""
    return jsonify({"recordings": engine.list_recordings()})


@app.route("/api/admin/recordings/<name>/download")
@admin_required
def api_recordings_download(name):
    """ดาวน์โหลดชุดบันทึกเป็นไฟล์ .zip (steps.jsonl + ภาพ/HTML แต่ละสเต็ป) — Super Admin"""
    d = engine.recording_path(name)
    if not d:
        return jsonify({"error": "ไม่พบชุดบันทึก"}), 404
    tmp = Path(tempfile.mkdtemp(prefix="crimes_rec_")) / (name + ".zip")
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(d.glob("*")):
                if f.is_file():
                    zf.write(f, arcname=f"{name}/{f.name}")
    except Exception as e:
        return jsonify({"error": f"สร้างไฟล์ zip ไม่สำเร็จ: {str(e)[:120]}"}), 500
    _audit("download_recording", f"name={name}")
    return send_file(tmp, as_attachment=True, download_name=name + ".zip")


# ---------------- API: admin — billing ----------------
@app.route("/api/admin/billing/config", methods=["GET", "POST"])
@perm_required("manage_billing")
def api_billing_config():
    if request.method == "POST":
        data = request.json or {}
        rate = data.get("rate_per_name")
        if rate is not None:
            try:
                rate = float(rate)
                if rate >= 0:
                    db.set_billing_rate(rate)
            except (ValueError, TypeError):
                pass
    return jsonify({"rate_per_name": db.get_billing_rate()})


@app.route("/api/admin/billing/summary")
@perm_required("manage_billing")
def api_billing_summary():
    ym = request.args.get("ym", "")
    months = db.available_months()
    if not ym and months:
        ym = months[0]
    summary = db.billing_monthly_summary(ym) if ym else []
    total_amount = sum(s["amount"] for s in summary)
    total_count = sum(s["count"] for s in summary)
    return jsonify({
        "ym": ym,
        "months": months,
        "members": summary,
        "total_count": total_count,
        "total_amount": round(total_amount, 2),
        "rate": db.get_billing_rate(),
    })


@app.route("/api/admin/billing/export")
@perm_required("manage_billing")
def api_billing_export():
    """ส่งออกสรุปการเงินรายเดือนเป็นไฟล์ Excel (.xlsx) ให้ดาวน์โหลด (Super Admin)"""
    import io

    import openpyxl
    from openpyxl.styles import Alignment, Font

    ym = request.args.get("ym", "")
    months = db.available_months()
    if not ym and months:
        ym = months[0]
    summary = db.billing_monthly_summary(ym) if ym else []

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "สรุปการเงิน"
    ws.append([f"สรุปการเงินประจำเดือน {ym or '(ทั้งหมด)'}"])
    ws["A1"].font = Font(bold=True, size=14)
    ws.append([])
    headers = ["ลำดับ", "ชื่อผู้ใช้", "ชื่อที่แสดง", "จำนวนค้น",
               "อัตรา/ชื่อ (บาท)", "ยอดเงิน (บาท)", "หมายเหตุ"]
    ws.append(headers)
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    for i, s in enumerate(summary, 1):
        note = (s.get("note") or "")
        if s.get("adjusted"):
            note = (note + " (ปรับยอด)").strip()
        ws.append([i, s["username"], s.get("display_name", ""), s["count"],
                   s["rate"], round(s["amount"], 2), note])
    total_count = sum(s["count"] for s in summary)
    total_amount = round(sum(s["amount"] for s in summary), 2)
    ws.append([])
    ws.append(["", "", "รวมทั้งหมด", total_count, "", total_amount, ""])
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    ws["F1"].alignment = Alignment(horizontal="right")
    widths = [8, 18, 22, 12, 16, 16, 30]
    for idx, w in enumerate(widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(idx)].width = w

    bio = io.BytesIO()
    wb.save(bio)
    bio.seek(0)
    _audit("billing_export", f"ym={ym or 'all'} members={len(summary)}")
    return send_file(
        bio, as_attachment=True,
        download_name=f"สรุปการเงิน_{ym or 'all'}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/api/admin/billing/adjust/<int:uid>", methods=["POST"])
@perm_required("manage_billing")
def api_billing_adjust(uid):
    """แก้ไขจำนวนค้น/ยอดเงิน รายคนต่อเดือน (เฉพาะ Super Admin + ต้องมีรหัสยืนยัน; ว่าง=กลับไปใช้ค่าจริง)"""
    data = request.json or {}
    err = _check_action_code(data)
    if err:
        return err
    ym = (data.get("ym") or "").strip()
    if not ym:
        return jsonify({"error": "ไม่ระบุเดือน"}), 400

    def _num(v, cast):
        if v is None or v == "":
            return None
        try:
            return cast(v)
        except (ValueError, TypeError):
            return None

    adj_count = _num(data.get("adj_count"), int)
    adj_amount = _num(data.get("adj_amount"), float)
    note = (data.get("note") or "").strip()
    if adj_count is not None and adj_count < 0:
        return jsonify({"error": "จำนวนค้นต้องไม่ติดลบ"}), 400
    if adj_amount is not None and adj_amount < 0:
        return jsonify({"error": "ยอดเงินต้องไม่ติดลบ"}), 400
    db.set_adjust(uid, ym, adj_count=adj_count, adj_amount=adj_amount, note=note)
    return jsonify({"ok": True, "billing": db.billing_user_monthly(ym, uid)})


@app.route("/api/admin/billing/detail/<int:uid>")
@perm_required("manage_billing")
def api_billing_detail(uid):
    ym = request.args.get("ym", "")
    months = db.available_months()
    if not ym and months:
        ym = months[0]
    data = db.billing_user_monthly(ym, uid) if ym else {"daily": [], "total_count": 0, "total_amount": 0, "rate": db.get_billing_rate()}
    user = db.get_user(uid)
    data["username"] = user["username"] if user else ""
    data["display_name"] = user["display_name"] if user else ""
    data["ym"] = ym
    data["adjust"] = db.get_adjust(uid, ym) if ym else None
    return jsonify(data)


# ---------------- API: admin — teams ----------------
def _check_team_members(member_ids):
    """ตรวจรายชื่อสมาชิกที่จะใส่ในทีม — คืน (ids, error_response)

    สมาชิกในทีมกำหนดขอบเขตการมองเห็นของสิทธิ์ 'ดูข้อมูลทีม' การแก้รายชื่อจึงเท่ากับ
    แก้ว่าใครเห็นข้อมูลของใคร ผู้ที่ไม่ใช่ Super Admin จึงห้ามใส่ตัวเองหรือใส่บัญชี
    Super Admin เข้าไป ไม่งั้นสร้างทีมแล้วดึงคนทั้งระบบเข้ามาเพื่ออ่านข้อมูลได้
    """
    if not isinstance(member_ids, (list, tuple)):
        return None, (jsonify({"error": "รูปแบบรายชื่อสมาชิกไม่ถูกต้อง"}), 400)
    ids = []
    for raw in member_ids:
        try:
            ids.append(int(raw))
        except (ValueError, TypeError):
            return None, (jsonify({"error": "รหัสสมาชิกต้องเป็นตัวเลข"}), 400)
    ids = sorted(set(ids))
    known = {u["id"]: u for u in db.list_users()}
    missing = [i for i in ids if i not in known]
    if missing:
        return None, (jsonify({"error": f"ไม่พบสมาชิก: {missing}"}), 400)
    if not _is_admin():
        if session.get("user_id") in ids:
            return None, (jsonify({"error": "เพิ่มตัวเองเข้าทีมไม่ได้ — ให้ Super Admin เป็นผู้จัด"}), 403)
        admins = [i for i in ids if known[i]["role"] == "super_admin"]
        if admins:
            return None, (jsonify({"error": "เฉพาะ Super Admin เท่านั้นที่จัดบัญชี Super Admin เข้าทีมได้"}), 403)
    return ids, None


def _guard_own_team(tid):
    """ผู้ที่ไม่ใช่ Super Admin ห้ามแก้ทีมที่ตัวเองอยู่ — กันขยายขอบเขตให้ตัวเอง"""
    if _is_admin():
        return None
    if tid in db.teams_for_user(session.get("user_id")):
        return jsonify({"error": "แก้ทีมที่ตัวเองสังกัดไม่ได้ — ให้ Super Admin เป็นผู้จัด"}), 403
    return None


@app.route("/api/admin/teams")
@perm_required("manage_teams")
def api_admin_teams():
    return jsonify(db.list_teams())


@app.route("/api/admin/teams", methods=["POST"])
@perm_required("manage_teams")
def api_admin_team_create():
    data = request.json or {}
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "กรุณาตั้งชื่อทีม"}), 400
    rate = data.get("rate_per_name")
    rate = float(rate) if rate is not None and rate != "" else None
    ids, err = _check_team_members(data.get("member_ids") or [])
    if err:
        return err
    tid = db.create_team(name, rate_per_name=rate)
    if ids:
        db.set_team_members(tid, ids)
    _audit("team_create", f"id={tid} name={name} members={ids}")
    return jsonify({"ok": True, "id": tid})


@app.route("/api/admin/teams/<int:tid>", methods=["PUT"])
@perm_required("manage_teams")
def api_admin_team_update(tid):
    data = request.json or {}
    err = _guard_own_team(tid)
    if err:
        return err
    name = data.get("name")
    if name is not None:
        name = name.strip()
    rate = "__skip__"
    if "rate_per_name" in data:
        v = data["rate_per_name"]
        rate = float(v) if v is not None and v != "" else None
    ids = None
    if "member_ids" in data:
        ids, err = _check_team_members(data["member_ids"])
        if err:
            return err
    db.update_team(tid, name=name, rate_per_name=rate)
    if ids is not None:
        db.set_team_members(tid, ids)
    _audit("team_update", f"id={tid} name={name} rate={rate} members={ids}")
    return jsonify({"ok": True})


@app.route("/api/admin/teams/<int:tid>", methods=["DELETE"])
@perm_required("manage_teams")
def api_admin_team_delete(tid):
    err = _guard_own_team(tid)
    if err:
        return err
    team = db.get_team(tid)
    db.delete_team(tid)
    _audit("team_delete", f"id={tid} name={(team or {}).get('name', '')}")
    return jsonify({"ok": True})


@app.route("/api/admin/teams/<int:tid>/billing")
@perm_required("manage_billing")
def api_admin_team_billing(tid):
    """ยอดรายคนในทีมเป็นข้อมูลการเงินของบุคคล — ต้องมีสิทธิ์การเงิน ไม่ใช่แค่จัดทีม"""
    ym = request.args.get("ym", "")
    months = db.available_months()
    if not ym and months:
        ym = months[0]
    data = db.team_billing(tid, ym) if ym else {"members": [], "total_count": 0, "total_amount": 0, "per_person": 0, "rate": db.get_billing_rate()}
    data["ym"] = ym
    return jsonify(data)


def run_server(open_browser=True):
    cfg = auth.load_config()
    host = cfg.get("bind_host", "127.0.0.1")
    port = int(cfg.get("port", 8770))
    url = f"http://127.0.0.1:{port}"
    print(f"\n  CRIMES Web เปิดที่:  {url}")
    if host == "0.0.0.0":
        print("  [!] เปิดให้เครื่องอื่นในวง LAN เข้าถึงได้ — ระวังความปลอดภัย")
    print("  ปิดหน้าต่างนี้เพื่อหยุดเซิร์ฟเวอร์\n")
    if open_browser:
        import threading
        import webbrowser
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    try:
        from waitress import serve
        serve(app, host=host, port=port, threads=8)
    except ImportError:
        app.run(host=host, port=port, debug=False)


if __name__ == "__main__":
    run_server()
